import os

import secrets

import time

from dataclasses import dataclass

from collections.abc import Callable
from typing import Any



import httpx



AYCD_API_URL = "https://inbox-api.aycd.io/api/v1"

DEFAULT_TEMPLATE_ID = "Default"
SEND_TIME_GRACE_SECONDS = 1
MAX_TASK_TIMEOUT = 3600





@dataclass

class MailTaskResult:

    code: str | None = None

    link: str | None = None

    raw: dict[str, Any] | None = None



@dataclass

class CreatedMailTask:

    task_id: str

    group: str

    immediate: MailTaskResult | None = None





class AycdInboxClient:

    def __init__(
        self,
        api_key: str,
        template_id: str | None = None,
    ) -> None:

        if not api_key:

            raise ValueError("AYCD_API_KEY is required")



        self.api_key = api_key.strip()

        configured_template = (template_id or os.getenv("AYCD_TEMPLATE_ID", DEFAULT_TEMPLATE_ID)).strip()

        self.template_id = configured_template or None

        # Avoid broken HTTP_PROXY / VPN env vars breaking DNS (Windows getaddrinfo 11001).
        trust_env = os.getenv("AYCD_HTTP_TRUST_ENV", "").strip().lower() in {
            "1",
            "true",
            "yes",
        }
        self._client = httpx.Client(
            timeout=httpx.Timeout(30.0, connect=20.0),
            trust_env=trust_env,
        )



    def _headers(self) -> dict[str, str]:

        return {

            "Authorization": f"Token {self.api_key}",

            "Content-Type": "application/json",

        }



    def ensure_connected(self, max_attempts: int = 5, retry_delay_seconds: float = 3.0) -> None:

        """Verify the AYCD API key is valid (retries transient DNS/network errors)."""

        last_error: Exception | None = None
        url = f"{AYCD_API_URL}/tasks/completed"

        for attempt in range(1, max_attempts + 1):
            try:
                response = self._client.get(
                    url,
                    headers=self._headers(),
                    params={"group": "health-check"},
                )
            except (httpx.ConnectError, httpx.TimeoutException, OSError) as exc:
                last_error = exc
                if attempt < max_attempts:
                    wait = retry_delay_seconds * attempt
                    print(
                        f"AYCD API unreachable ({exc!s}) — "
                        f"retrying in {wait:.0f}s ({attempt}/{max_attempts})..."
                    )
                    time.sleep(wait)
                    continue
                raise ConnectionError(
                    f"Cannot reach AYCD Inbox API ({AYCD_API_URL}). "
                    "Check internet, DNS, and VPN (Astrill/etc.), or set "
                    "AYCD_HTTP_TRUST_ENV=true if you need a system HTTP proxy. "
                    f"Last error: {exc}"
                ) from exc

            if response.status_code == 401:
                raise ValueError("AYCD API key is invalid or unauthorized")
            if response.status_code >= 500:
                last_error = ConnectionError("AYCD Inbox API is temporarily unavailable")
                if attempt < max_attempts:
                    wait = retry_delay_seconds * attempt
                    print(
                        f"AYCD API returned {response.status_code} — "
                        f"retrying in {wait:.0f}s ({attempt}/{max_attempts})..."
                    )
                    time.sleep(wait)
                    continue
                raise last_error
            return

        if last_error is not None:
            raise ConnectionError(
                f"Cannot reach AYCD Inbox API ({AYCD_API_URL}): {last_error}"
            ) from last_error



    def create_mail_task(

        self,

        email: str,

        timeout_seconds: int = 180,

        subject: str | None = None,

        sender: str | None = None,

        received_at: int | None = None,

        otp_regex: str | None = None,

    ) -> CreatedMailTask:

        group = secrets.token_hex(16)

        mail_filters: list[dict[str, str]] = []



        if sender:

            mail_filters.append({

                "target": "from",

                "comparator": "includes",

                "value": sender,

            })

        if subject:

            mail_filters.append({

                "target": "subject",

                "comparator": "includes",

                "value": subject,

            })



        if received_at is None:

            received_at = int(time.time()) - SEND_TIME_GRACE_SECONDS



        payload: dict[str, Any] = {

            "group": group,

            "email": email,

            "receivedAt": received_at,

            "mailFilters": mail_filters,

            "mailElements": [{

                "name": "otp",

                "target": "body",

                "regex": otp_regex or r"\b\d{6}\b",

                "formatter": "numeric",

            }],

            "timeout": min(max(timeout_seconds, 1), MAX_TASK_TIMEOUT),

        }

        if self.template_id:

            payload["templateId"] = self.template_id



        response = self._client.post(

            f"{AYCD_API_URL}/tasks/mail/create",

            headers=self._headers(),

            json=payload,

        )

        if response.status_code == 401:

            raise ValueError("AYCD API key is invalid or unauthorized")

        response.raise_for_status()



        data = response.json()

        task_id = data.get("id") or data.get("taskId")

        if not task_id:

            raise RuntimeError(f"AYCD did not return a task id: {data}")



        status = str(data.get("status", "")).lower()

        if status in {"failed", "error", "timeout", "expired"}:

            raise RuntimeError(f"AYCD mail task failed on create: {data}")

        immediate = None

        if status in {"completed", "success", "done"}:

            immediate = self._parse_task_result(data)



        return CreatedMailTask(task_id=str(task_id), group=group, immediate=immediate)



    def wait_for_mail_task(

        self,

        task_id: str,

        group: str,

        timeout_seconds: int = 180,

        poll_interval: float = 3.0,

        on_poll: Callable[[], None] | None = None,

    ) -> MailTaskResult:

        deadline = time.time() + timeout_seconds

        last_log = 0.0



        while time.time() < deadline:

            if on_poll is not None:

                on_poll()

            response = self._client.get(

                f"{AYCD_API_URL}/tasks/completed",

                headers=self._headers(),

                params={"group": group},

            )

            if response.status_code == 401:

                raise ValueError("AYCD API key is invalid or unauthorized")

            response.raise_for_status()



            tasks = self._parse_completed_tasks(response.json())

            for task in tasks:

                if str(task.get("id", "")) != task_id:

                    continue



                status = str(task.get("status", "")).lower()

                if status in {"completed", "success", "done"}:

                    return self._parse_task_result(task)

                if status in {"failed", "error", "timeout", "expired"}:

                    raise RuntimeError(f"AYCD mail task failed: {task}")

                if status in {"queued", "pending", "processing", "running", ""}:

                    break



            now = time.time()

            if now - last_log >= 15:

                remaining = max(0, int(deadline - now))

                print(f"  Still waiting for AYCD OTP ({remaining}s left, group={group})...")

                last_log = now



            time.sleep(poll_interval)



        raise TimeoutError(f"Timed out waiting for AYCD mail task {task_id}")



    def wait_for_mail(

        self,

        email: str,

        timeout_seconds: int = 180,

        poll_interval: float = 3.0,

        subject: str | None = None,

        sender: str | None = None,

    ) -> MailTaskResult:

        created = self.create_mail_task(

            email=email,

            timeout_seconds=timeout_seconds,

            subject=subject,

            sender=sender,

        )

        if created.immediate is not None:

            return created.immediate

        return self.wait_for_mail_task(

            created.task_id,

            created.group,

            timeout_seconds=timeout_seconds,

            poll_interval=poll_interval,

        )



    def _parse_completed_tasks(self, payload: Any) -> list[dict[str, Any]]:

        if isinstance(payload, dict):

            tasks = payload.get("tasks")

            if isinstance(tasks, list):

                return [task for task in tasks if isinstance(task, dict)]

            if payload.get("id") or payload.get("status"):

                return [payload]

        if isinstance(payload, list):

            return [task for task in payload if isinstance(task, dict)]

        return []



    def _parse_task_result(self, task: dict[str, Any]) -> MailTaskResult:

        results = task.get("results") or {}

        if not isinstance(results, dict):

            results = {}



        code = None

        for key in ("otp", "otpCode", "code", "Code", "1", "2", "3"):

            value = results.get(key)

            if value:

                code = str(value).strip()

                break



        if not code:

            for value in results.values():

                candidate = str(value).strip()

                if candidate.isdigit() and len(candidate) == 6:

                    code = candidate

                    break



        if not code:

            raise RuntimeError(f"AYCD task completed without OTP: {task}")



        link = None

        for key in ("link", "links", "url"):

            value = results.get(key)

            if isinstance(value, str) and value:

                link = value

                break



        return MailTaskResult(code=code, link=link, raw=task)



    def close(self) -> None:

        self._client.close()





def create_aycd_client() -> AycdInboxClient:

    api_key = os.getenv("AYCD_API_KEY", "").strip()

    return AycdInboxClient(api_key=api_key)


