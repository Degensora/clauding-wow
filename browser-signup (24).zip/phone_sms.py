"""Virtual number providers for Ticketmaster phone verification."""

import json
import os
import random
import re
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol

import httpx

from sms_countries import COUNTRIES, get_country, normalize_country_id

DEFAULT_SERVICE = "gp"  # Ticketmaster on SMS-Activate-style catalogs
DEFAULT_COUNTRY = "187"  # US on handler_api country tables
DEFAULT_MAX_PRICE = "0.5"
DEFAULT_MIN_PRICE = "0.001"
DEFAULT_NUMBER_MAX_ATTEMPTS = 20
DEFAULT_NUMBER_RETRY_SECONDS = 10.0
DEFAULT_NUMBER_MAX_WAIT_SECONDS = 120.0
RETRYABLE_GET_NUMBER_ERRORS = frozenset({"NO_NUMBERS", "NO_NUMBER"})
_GRIZZLY_MIN_PRICE_RE = re.compile(
    r"(?:WRONG_MIN_PRICE|WRONG_MAX_PRICE|MIN_PRICE)\s*[:=]\s*\$?\s*([0-9]+(?:[.,][0-9]+)?)",
    re.I,
)
_GRIZZLY_MIN_PRICE_PHRASE_RE = re.compile(
    r"min(?:imum)?\.?\s*price(?:\s+is)?\s*[:=]?\s*\$?\s*([0-9]+(?:[.,][0-9]+)?)",
    re.I,
)
DEFAULT_PHONE_NUMBER_MAX_ROTATIONS = 5
_POOL_PROVIDER_NAMES = frozenset({"SMSBower", "GrizzlySMS"})
_SMSBOWER_PROVIDER_SLUGS = frozenset({"smsbower", "sms_bower", "bower"})
_GRIZZLY_PROVIDER_SLUGS = frozenset(
    {"grizzly", "grizzlysms", "grizzly_sms", "grizzly-sms"}
)

# SMS-Activate-style handler `country` param — same numeric ids on SMSBower,
# GrizzlySMS, Hero SMS, and SMSPool handler mode.
HANDLER_COUNTRY_PROFILES: dict[str, dict[str, str | int]] = {}
for _country_id, _country in COUNTRIES.items():
    _row: dict[str, str | int] = {
        "iso": _country.iso,
        "dial": _country.dial,
        "tm_country": _country.name,
        "national_length": _country.national_max,
        "national_min": _country.national_min,
        "national_max": _country.national_max,
    }
    if _country.fivesim:
        _row["fivesim"] = _country.fivesim
    HANDLER_COUNTRY_PROFILES[_country_id] = _row


@dataclass(frozen=True)
class PhoneCountryProfile:
    smsbower_country: str
    iso: str
    dial_code: str
    tm_country_name: str
    national_length: int
    national_min: int = 0
    national_max: int = 0

    def length_bounds(self) -> tuple[int, int]:
        low = self.national_min or self.national_length
        high = self.national_max or self.national_length
        return low, high


def profile_from_country_id(country_id: str) -> PhoneCountryProfile:
    country = get_country(country_id)
    if country is None:
        raise ValueError(
            f"Unknown SMS country id {country_id}. "
            "Use an SMS-Activate id such as 187 (US), 16 (UK), or 151 (Chile)."
        )
    return PhoneCountryProfile(
        smsbower_country=country.country_id,
        iso=country.iso,
        dial_code=country.dial,
        tm_country_name=country.name,
        national_length=country.national_max,
        national_min=country.national_min,
        national_max=country.national_max,
    )


def profile_for_iso(iso: str) -> PhoneCountryProfile:
    iso_code = (iso or "").strip().upper()
    preferred = {"US": "187", "CA": "36", "GB": "16", "CL": "151"}
    preferred_id = preferred.get(iso_code)
    preferred_country = get_country(preferred_id) if preferred_id else None
    if preferred_country is not None and preferred_country.iso == iso_code:
        return profile_from_country_id(preferred_country.country_id)
    for country in COUNTRIES.values():
        if country.iso == iso_code:
            return profile_from_country_id(country.country_id)
    raise ValueError(f"Unknown SMS country ISO {iso!r}.")


def _phone_exception_prefix(profile: PhoneCountryProfile, phone_number: str) -> str:
    """SMSBower phoneException is the calling code plus 3 mask digits.

    SMSBower rejects the whole getNumber when any prefix is 8 digits or
    longer. Chile's calling code is 56, so calling-code + 6 mask digits
    (56967023) is WRONG_EXCEPTION_PHONE and no number is bought.
    """

    digits = re.sub(r"\D", "", phone_number)
    dial = re.sub(r"\D", "", profile.dial_code)
    if not digits or not dial:
        return ""
    national = digits[len(dial) :] if digits.startswith(dial) else digits
    if national.startswith("0"):
        national = national[1:]
    if len(national) < 3:
        return ""
    prefix = f"{dial}{national[:3]}"
    mask_len = len(prefix) - len(dial)
    if mask_len != 3 or not prefix.isdigit():
        return ""
    return prefix


def _append_phone_exceptions(
    bucket: list[str],
    profile: PhoneCountryProfile,
    phone_number: str,
) -> None:
    prefix = _phone_exception_prefix(profile, phone_number)
    if prefix and prefix not in bucket:
        bucket.append(prefix)


@dataclass
class PhoneActivation:
    activation_id: str
    phone_number: str
    country: str = ""
    expires_at: float = 0.0


class SmsActivationLowTime(RuntimeError):
    """The provider activation has under 5 minutes left, so it should be replaced."""


def sms_activation_lifetime_seconds() -> float:
    """SMSBower / GrizzlySMS activations count down from 20 minutes."""

    raw = os.getenv("SMS_ACTIVATION_LIFETIME_SECONDS", "1200").strip()
    try:
        return max(60.0, float(raw))
    except ValueError:
        return 1200.0


def sms_min_remaining_seconds() -> float:
    raw = os.getenv("SMS_MIN_REMAINING_SECONDS", "300").strip()
    try:
        return max(0.0, float(raw))
    except ValueError:
        return 300.0


def stamp_activation_expiry(activation: PhoneActivation) -> PhoneActivation:
    if activation.expires_at <= 0:
        activation.expires_at = time.time() + sms_activation_lifetime_seconds()
    return activation


def activation_seconds_left(expires_at: float, now: float | None = None) -> float:
    if expires_at <= 0:
        return 0.0
    current = time.time() if now is None else now
    return expires_at - current


def format_activation_time_left(seconds: float) -> str:
    remaining = max(0, int(seconds))
    return f"{remaining // 60}:{remaining % 60:02d}"


class _SmsClientBase:
    provider_name: str
    _phone_exceptions: list[str]
    _last_country_profile: PhoneCountryProfile | None

    def country_profile(self) -> PhoneCountryProfile: ...

    def country_profile_for(self, country_id: str) -> PhoneCountryProfile:
        cid = (country_id or "").strip()
        if not cid:
            return self.country_profile()
        return profile_from_country_id(cid)

    def last_country_profile(self) -> PhoneCountryProfile:
        saved = getattr(self, "_last_country_profile", None)
        if saved is not None:
            return saved
        return self.country_profile()

    def _remember(self, activation: PhoneActivation) -> PhoneActivation:
        try:
            self._last_country_profile = self.country_profile_for(activation.country)
        except Exception:
            self._last_country_profile = self.country_profile()
        return activation

    def add_phone_exception(self, phone_number: str, country_id: str = "") -> None:
        profile = self.country_profile_for(country_id) if country_id else self.country_profile()
        before = len(self._phone_exceptions)
        _append_phone_exceptions(self._phone_exceptions, profile, phone_number)
        added = self._phone_exceptions[before:]
        if not added or self.provider_name not in _POOL_PROVIDER_NAMES:
            return
        from sms_number_pool import note_phone_exceptions

        note_phone_exceptions(self.provider_name, profile.smsbower_country, added)


class PhoneSmsClient(Protocol):
    provider_ids: tuple[str, ...]
    provider_name: str

    def country_profile(self) -> PhoneCountryProfile: ...
    def country_profile_for(self, country_id: str) -> PhoneCountryProfile: ...
    def last_country_profile(self) -> PhoneCountryProfile: ...
    def add_phone_exception(self, phone_number: str, country_id: str = "") -> None: ...
    def buy_number(
        self,
        *,
        max_attempts: int | None = None,
        retry_delay_seconds: float | None = None,
        max_wait_seconds: float | None = None,
        on_poll: Callable[[], None] | None = None,
    ) -> PhoneActivation: ...
    def wait_for_sms(
        self,
        activation_id: str,
        timeout_seconds: int = ...,
        poll_interval: float = ...,
        on_poll: Callable[[], None] | None = ...,
        expires_at: float = ...,
    ) -> str: ...
    def cancel(self, activation_id: str) -> None: ...
    def complete(self, activation_id: str) -> None: ...
    def close(self) -> None: ...


def _http_trust_env(env_var: str) -> bool:
    return os.getenv(env_var, "").strip().lower() in {"1", "true", "yes"}


def _parse_float_env(name: str, default: float) -> float:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _price_amount(token: str) -> float | None:
    try:
        return float(token.replace(",", "."))
    except ValueError:
        return None


def grizzly_required_min_price(text: str) -> str | None:
    """Price Grizzly returns when the requested minPrice is below that country.

    Chile can be 0.045 while the US answer is WRONG_MAX_PRICE:0.183 (the
    country's minimum). The next getNumber for that country uses this value.
    """

    token_matches = list(_GRIZZLY_MIN_PRICE_RE.finditer(text))
    phrase_matches = list(_GRIZZLY_MIN_PRICE_PHRASE_RE.finditer(text))
    match = token_matches[-1] if token_matches else (phrase_matches[-1] if phrase_matches else None)
    if match:
        amount = _price_amount(match.group(1))
        if amount is not None and amount > 0:
            return match.group(1).replace(",", ".")

    stripped = text.strip()
    marker = stripped.lower()
    if not any(
        token in marker
        for token in (
            "wrong_min_price",
            "wrong_max_price",
            "minprice",
            "minimum",
            "min price",
            "min. price",
        )
    ):
        return None
    if not stripped.startswith(("{", "[")):
        return None
    try:
        body = json.loads(stripped)
    except json.JSONDecodeError:
        return None

    blobs: list[dict] = []
    if isinstance(body, dict):
        blobs.append(body)
        for key in ("info", "data", "error", "details"):
            nested = body.get(key)
            if isinstance(nested, dict):
                blobs.append(nested)
    for blob in blobs:
        for key in ("minPrice", "min_price", "minimumPrice", "min"):
            raw = blob.get(key)
            if raw is None:
                continue
            token = str(raw).strip().lstrip("$")
            amount = _price_amount(token)
            if amount is not None and amount > 0:
                return token.replace(",", ".")
    return None


def _get_number_poll_sleep_seconds(retry_delay_seconds: float) -> float:
    base = max(0.5, float(retry_delay_seconds))
    return base * random.uniform(0.85, 1.15)


def sms_wait_until_number() -> bool:
    """True when a browser that has reached the phone step should not give up on NO_NUMBERS."""

    return os.getenv("SMS_WAIT_UNTIL_NUMBER", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _wait_until_number(max_wait_seconds: float | None) -> bool:
    # Callers that pass an explicit wait (the number-pool maintainer) stay bounded
    # so one empty country cannot block the others.
    if max_wait_seconds is not None:
        return False
    return sms_wait_until_number()


def _poll_while_waiting(on_poll: Callable[[], None] | None) -> None:
    if on_poll is not None:
        on_poll()


def _pick_rotating_country(countries: tuple[str, ...], fallback_index: int) -> tuple[str, int]:
    if len(countries) <= 1:
        return countries[0] if countries else DEFAULT_COUNTRY, fallback_index
    from sms_number_pool import rotate_country

    try:
        return rotate_country(countries), fallback_index
    except Exception:
        chosen = countries[fallback_index % len(countries)]
        return chosen, fallback_index + 1


class HandlerApiSmsClient(_SmsClientBase):
    """SMS-Activate-compatible handler API (SMSBower, GrizzlySMS, Hero SMS, SMSPool)."""

    def __init__(
        self,
        *,
        api_key: str,
        api_url: str,
        provider_name: str,
        service: str = DEFAULT_SERVICE,
        country: str = DEFAULT_COUNTRY,
        max_price: str = DEFAULT_MAX_PRICE,
        min_price: str = DEFAULT_MIN_PRICE,
        provider_ids: tuple[str, ...] = (),
        extra_params: dict[str, str] | None = None,
        trust_env_var: str = "SMS_HTTP_TRUST_ENV",
        countries: tuple[str, ...] | None = None,
        pool_enabled: bool | None = None,
    ) -> None:
        if not api_key:
            raise ValueError(f"{provider_name} API key is required")

        self.api_key = api_key
        self.api_url = api_url
        self.provider_name = provider_name
        self.service = service
        self.countries = tuple(countries) if countries else (country,)
        if not self.countries:
            self.countries = (country,)
        self.country = self.countries[0]
        self._rr = 0
        self._last_country_profile = None
        if pool_enabled is None:
            from sms_number_pool import sms_number_pool_enabled, sms_numbers_per_country

            pool_enabled = (
                provider_name in _POOL_PROVIDER_NAMES
                and sms_number_pool_enabled()
                and sms_numbers_per_country() > 0
            )
        self.pool_enabled = bool(pool_enabled)
        self.max_price = max_price
        self.min_price = min_price
        self.provider_ids = tuple(p.strip() for p in provider_ids if str(p).strip())
        self._extra_params = dict(extra_params or {})
        if self.provider_ids and provider_name == "SMSPool":
            self._extra_params.setdefault("pool", ",".join(self.provider_ids))
        elif self.provider_ids:
            self._extra_params.setdefault("providerIds", ",".join(self.provider_ids))

        if self.provider_ids:
            print(
                f"{provider_name} provider filter: "
                f"{','.join(self.provider_ids)}"
            )
        elif provider_name in _POOL_PROVIDER_NAMES:
            print(
                f"{provider_name} provider filter: any "
                "(set provider ids in .env or sms_provider_ids to restrict price/providers)"
            )
        print(
            f"{provider_name} getNumber price window: "
            f"minPrice={self.min_price} maxPrice={self.max_price}"
        )

        self.get_number_retry_seconds = _parse_float_env(
            "SMS_GET_NUMBER_RETRY_SECONDS",
            DEFAULT_NUMBER_RETRY_SECONDS,
        )
        self.get_number_max_wait_seconds = _parse_float_env(
            "SMS_GET_NUMBER_MAX_WAIT_SECONDS",
            DEFAULT_NUMBER_MAX_WAIT_SECONDS,
        )

        self._client = httpx.Client(
            timeout=httpx.Timeout(30.0, connect=20.0),
            trust_env=_http_trust_env(trust_env_var),
        )
        self._phone_exceptions: list[str] = []
        self._phone_exception_blocked: set[str] = set()
        self._country_min_prices: dict[str, str] = {}
        self._country_max_prices: dict[str, str] = {}

    def _request(self, **params: str) -> str:
        merged = {**self._extra_params, **params}
        response = self._client.get(
            self.api_url,
            params={"api_key": self.api_key, **merged},
        )
        text = response.text.strip()
        if (
            response.status_code >= 400
            and self.provider_name == "GrizzlySMS"
            and grizzly_required_min_price(text)
        ):
            return text
        response.raise_for_status()
        return text

    def country_profile(self) -> PhoneCountryProfile:
        return profile_from_country_id(self.country)

    def _next_country(self) -> str:
        if len(self.countries) <= 1:
            return self.country
        chosen = self.countries[self._rr % len(self.countries)]
        self._rr += 1
        return chosen

    def _phone_exception_param(self, country_id: str) -> str:
        if str(country_id) in self._phone_exception_blocked:
            return ""
        try:
            dial = re.sub(r"\D", "", profile_from_country_id(country_id).dial_code)
        except Exception:
            dial = ""
        prefixes: list[str] = []

        def add(prefix: str) -> None:
            cleaned = re.sub(r"\D", "", prefix)
            if not dial or not cleaned.startswith(dial):
                return
            if len(cleaned) - len(dial) != 3:
                return
            # 7918 and 7900111 are the documented bounds. 8+ digits fail closed.
            if not 4 <= len(cleaned) <= 7:
                return
            if cleaned not in prefixes:
                prefixes.append(cleaned)

        for prefix in self._phone_exceptions:
            add(prefix)
        if self.provider_name in _POOL_PROVIDER_NAMES:
            from sms_number_pool import pooled_phone_exceptions

            for prefix in pooled_phone_exceptions(self.provider_name, country_id):
                add(prefix)
        return ",".join(prefixes[-10:])

    def _get_number_action(self) -> str:
        # SMSBower getNumberV2 does not accept phoneException. getNumber does.
        if self.provider_name == "SMSBower":
            return "getNumber"
        if self.provider_name != "GrizzlySMS":
            return "getNumber"
        if os.getenv("GRIZZLY_USE_GET_NUMBER_V2", "1").strip().lower() in {"1", "true", "yes"}:
            return "getNumberV2"
        return "getNumber"

    def _parse_get_number_success(self, text: str, country_id: str) -> PhoneActivation | None:
        if text.startswith("ACCESS_NUMBER:"):
            _, activation_id, phone_number = text.split(":", 2)
            return stamp_activation_expiry(
                PhoneActivation(
                    activation_id=activation_id,
                    phone_number=phone_number,
                    country=country_id,
                )
            )

        if not text.startswith("{"):
            return None

        try:
            body = json.loads(text)
        except json.JSONDecodeError:
            return None
        if not isinstance(body, dict):
            return None

        activation_id = str(body.get("activationId") or body.get("id") or "")
        phone_number = str(body.get("phoneNumber") or body.get("number") or "")
        if not activation_id or not phone_number:
            return None

        cost_raw = body.get("activationCost")
        if cost_raw is not None:
            try:
                cost = float(cost_raw)
                print(f"{self.provider_name} number cost: ${cost:.4f}")
                max_allowed = float(self.max_price)
                if cost > max_allowed + 1e-9:
                    print(
                        f"{self.provider_name} rejecting activation {activation_id}: "
                        f"cost ${cost:.4f} exceeds maxPrice {self.max_price}"
                    )
                    try:
                        self.cancel(activation_id)
                    except Exception:
                        pass
                    raise RuntimeError(
                        f"{self.provider_name} returned ${cost:.4f} number but "
                        f"maxPrice is {self.max_price}. "
                        "Lower maxPrice (e.g. 0.065) and set providerIds "
                        "(SMSBOWER_PROVIDER_IDS=3451,3419)."
                    )
            except ValueError:
                pass

        operator = body.get("activationOperator")
        if operator is not None and self.provider_ids:
            op_str = str(operator).strip()
            allowed = {p.strip() for p in self.provider_ids}
            if op_str and op_str not in allowed:
                print(
                    f"{self.provider_name} warning: activation operator/provider "
                    f"{op_str} not in filter {','.join(self.provider_ids)}"
                )

        return stamp_activation_expiry(
            PhoneActivation(
                activation_id=activation_id,
                phone_number=phone_number,
                country=country_id,
            )
        )

    def buy_number(
        self,
        *,
        country: str | None = None,
        max_attempts: int | None = None,
        retry_delay_seconds: float | None = None,
        max_wait_seconds: float | None = None,
        on_poll: Callable[[], None] | None = None,
    ) -> PhoneActivation:
        last_error = "unknown error"
        retry_delay = (
            self.get_number_retry_seconds
            if retry_delay_seconds is None
            else retry_delay_seconds
        )
        max_wait = (
            self.get_number_max_wait_seconds
            if max_wait_seconds is None
            else max_wait_seconds
        )
        wait_until = _wait_until_number(max_wait_seconds)
        if max_attempts is None:
            max_attempts = max(
                1,
                int(max_wait / max(retry_delay, 0.5)) + 2,
            )
        deadline = time.monotonic() + max(max_wait, retry_delay)
        attempt = 0
        queued_once = False
        rotate_index = self._rr

        if self.pool_enabled and country is None:
            from sms_number_pool import claim_pooled_activation, sms_pool_claim_wait_seconds

            claim_wait = None if wait_until else min(sms_pool_claim_wait_seconds(), max_wait)
            claimed = claim_pooled_activation(
                self.provider_name,
                self.service,
                self.countries,
                wait_seconds=claim_wait,
                on_poll=on_poll,
            )
            if claimed is not None:
                left = activation_seconds_left(claimed.expires_at)
                print(
                    f"{self.provider_name} claimed pooled number "
                    f"{claimed.phone_number} (country {claimed.country}, "
                    f"{format_activation_time_left(left)} left)"
                )
                return self._remember(claimed)
            if not wait_until:
                print(f"{self.provider_name} number pool is empty — buying a number directly")

        while True:
            if not wait_until and (attempt >= max_attempts or time.monotonic() >= deadline):
                break
            attempt += 1
            if country is not None:
                chosen_country = country
            elif len(self.countries) > 1:
                chosen_country, rotate_index = _pick_rotating_country(self.countries, rotate_index)
            else:
                chosen_country = self.country
            country_key = str(chosen_country)
            params: dict[str, str] = {
                "action": self._get_number_action(),
                "service": self.service,
                "country": chosen_country,
                "maxPrice": self._country_max_prices.get(country_key, self.max_price),
                "minPrice": self._country_min_prices.get(country_key, self.min_price),
            }
            phone_exception = self._phone_exception_param(chosen_country)
            if self.provider_name == "SMSBower":
                # An omitted phoneException reapplies the masks saved on the
                # SMSBower account. Those masks are often another country's
                # or 8 digits long, and Chile then fails with
                # WRONG_EXCEPTION_PHONE. An empty value buys with no exclusions.
                params["phoneException"] = phone_exception
            elif phone_exception:
                params["phoneException"] = phone_exception
            if self.provider_ids and self.provider_name != "SMSPool":
                params["providerIds"] = ",".join(self.provider_ids)
            if self.provider_ids and self.provider_name == "SMSPool":
                params["pool"] = ",".join(self.provider_ids)

            _poll_while_waiting(on_poll)
            text = self._request(**params)

            try:
                activation = self._parse_get_number_success(text, chosen_country)
            except RuntimeError:
                raise
            if activation is not None:
                if attempt > 1:
                    print(f"{self.provider_name} number acquired on attempt {attempt}")
                return self._remember(activation)

            last_error = text
            required_min = (
                grizzly_required_min_price(text)
                if self.provider_name == "GrizzlySMS"
                else None
            )
            if required_min is not None:
                required_amount = _price_amount(required_min)
                sent_min = _price_amount(params["minPrice"]) or 0.0
                sent_max = _price_amount(params["maxPrice"]) or 0.0
                raised_min = (
                    required_amount is not None
                    and required_amount > sent_min + 1e-9
                    and self._country_min_prices.get(country_key) != required_min
                )
                raised_max = (
                    required_amount is not None
                    and required_amount > sent_max + 1e-9
                    and self._country_max_prices.get(country_key) != required_min
                )
                if raised_min or raised_max:
                    if raised_min:
                        self._country_min_prices[country_key] = required_min
                    if raised_max:
                        self._country_max_prices[country_key] = required_min
                    print(
                        f"GrizzlySMS country {country_key} minimum is ${required_min} "
                        f"— requesting again with minPrice={required_min}"
                    )
                    continue
            if text == "WRONG_EXCEPTION_PHONE" or text.startswith("WRONG_EXCEPTION_PHONE"):
                sent_exception = params.get("phoneException")
                if sent_exception:
                    print(
                        f"{self.provider_name} rejected phoneException "
                        f"{sent_exception} for country {chosen_country} — "
                        "clearing it and requesting again with no exclusions"
                    )
                    self._phone_exception_blocked.add(str(chosen_country))
                    try:
                        dial = re.sub(
                            r"\D", "", profile_from_country_id(chosen_country).dial_code
                        )
                    except Exception:
                        dial = ""
                    if dial:
                        self._phone_exceptions = [
                            prefix
                            for prefix in self._phone_exceptions
                            if not re.sub(r"\D", "", prefix).startswith(dial)
                        ]
                    try:
                        from sms_number_pool import clear_pooled_phone_exceptions

                        clear_pooled_phone_exceptions(str(chosen_country))
                    except Exception as exc:
                        print(f"Could not clear stored phone exceptions: {exc}")
                    continue
                break
            if text not in RETRYABLE_GET_NUMBER_ERRORS:
                break

            remaining = deadline - time.monotonic()
            if not wait_until and (remaining <= 0 or attempt >= max_attempts):
                break

            if not queued_once:
                provider_hint = (
                    f" (providerIds={','.join(self.provider_ids)})"
                    if self.provider_ids
                    else " (any provider — set sms_provider_ids or SMS_PROVIDER_IDS)"
                )
                if wait_until:
                    names = ", ".join(self.countries)
                    print(
                        f"{self.provider_name} phone step is waiting for a number{provider_hint}; "
                        f"will keep requesting across {names} until one is available"
                    )
                else:
                    print(
                        f"{self.provider_name} waiting in number queue{provider_hint}; "
                        f"will poll up to {max_wait:.0f}s every ~{retry_delay:.0f}s..."
                    )
                queued_once = True

            sleep_for = _get_number_poll_sleep_seconds(retry_delay)
            if not wait_until:
                sleep_for = min(sleep_for, max(remaining, 0.0))
            left = "until a number is available" if wait_until else f"~{remaining:.0f}s left in queue window"
            print(
                f"{self.provider_name} getNumber returned {text} for country {chosen_country}, "
                f"retrying in {sleep_for:.1f}s (attempt {attempt}, {left})..."
            )
            time.sleep(sleep_for)
            _poll_while_waiting(on_poll)

        raise RuntimeError(f"{self.provider_name} getNumber failed: {last_error}")

    def set_status(self, activation_id: str, status: int) -> None:
        text = self._request(
            action="setStatus",
            id=activation_id,
            status=str(status),
        )
        if text.startswith("ACCESS_") or text == "EARLY_CANCEL_DENIED":
            return
        raise RuntimeError(f"{self.provider_name} setStatus failed: {text}")

    def get_status(self, activation_id: str) -> str:
        return self._request(action="getStatus", id=activation_id)

    def wait_for_sms(
        self,
        activation_id: str,
        timeout_seconds: int = 120,
        poll_interval: float = 3.0,
        on_poll: Callable[[], None] | None = None,
        expires_at: float = 0.0,
        ignore_codes: set[str] | None = None,
    ) -> str:
        deadline = time.time() + timeout_seconds
        last_log = 0.0
        ignored = {code.strip() for code in (ignore_codes or set()) if code and code.strip()}

        while time.time() < deadline:
            if on_poll is not None:
                on_poll()

            if expires_at > 0:
                left = activation_seconds_left(expires_at)
                if left < sms_min_remaining_seconds():
                    print(
                        f"{self.provider_name} number {activation_id} has "
                        f"{format_activation_time_left(left)} left "
                        "(under 5:00) — cancelling and requesting a new number"
                    )
                    self.cancel(activation_id)
                    raise SmsActivationLowTime(
                        f"{self.provider_name} activation has "
                        f"{format_activation_time_left(left)} left"
                    )

            status = self.get_status(activation_id)

            if status.startswith("STATUS_OK:") or status.startswith("STATUS_WAIT_RETRY:"):
                code = status.split(":", 1)[1].strip()
                if code and code not in ignored:
                    return code

            if status == "STATUS_CANCEL":
                raise RuntimeError(f"{self.provider_name} activation was canceled")

            if (
                not status.startswith("STATUS_OK:")
                and not status.startswith("STATUS_WAIT_RETRY:")
                and status not in {"STATUS_WAIT_CODE", "STATUS_WAIT_RESEND"}
            ):
                raise RuntimeError(f"Unexpected {self.provider_name} status: {status}")

            now = time.time()
            if now - last_log >= 15:
                remaining = max(0, int(deadline - now))
                if expires_at > 0:
                    provider_left = format_activation_time_left(
                        activation_seconds_left(expires_at, now)
                    )
                    print(
                        f"  Still waiting for SMS OTP ({remaining}s left, "
                        f"number {provider_left} left)..."
                    )
                else:
                    print(f"  Still waiting for SMS OTP ({remaining}s left)...")
                last_log = now

            time.sleep(poll_interval)

        raise TimeoutError(f"Timed out waiting for SMS on activation {activation_id}")

    def request_another_sms(self, activation_id: str) -> None:
        """Ask the provider for another SMS after Ticketmaster rejected the code."""

        self.set_status(activation_id, 3)

    def request_cancel(self, activation_id: str) -> str:
        """Ask the provider to cancel. EARLY_CANCEL_DENIED means it is still billed."""

        try:
            return self._request(action="setStatus", id=activation_id, status="8")
        except Exception as exc:
            return str(exc)

    def cancel(self, activation_id: str) -> None:
        try:
            self.set_status(activation_id, 8)
        except RuntimeError:
            pass

    def complete(self, activation_id: str) -> None:
        self.set_status(activation_id, 6)

    def close(self) -> None:
        self._client.close()


class SmsPoolNativeClient(_SmsClientBase):
    """SMSPool JSON API (purchase/sms + sms/check)."""

    API_BASE = "https://api.smspool.net"

    def __init__(
        self,
        *,
        api_key: str,
        service: str,
        country_iso: str,
        max_price: str = "",
        provider_ids: tuple[str, ...] = (),
        countries: tuple[str, ...] | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("SMSPOOL_API_KEY is required")
        if not service:
            raise ValueError("SMSPOOL_SERVICE is required for native SMSPool API")

        self.api_key = api_key
        self.service = service
        self.country_iso = country_iso.upper()
        self.countries = tuple(countries) if countries else ()
        self._rr = 0
        self.max_price = max_price.strip()
        self.provider_ids = tuple(p.strip() for p in provider_ids if str(p).strip())
        self.provider_name = "SMSPool"
        self.get_number_retry_seconds = _parse_float_env(
            "SMS_GET_NUMBER_RETRY_SECONDS",
            DEFAULT_NUMBER_RETRY_SECONDS,
        )
        self.get_number_max_wait_seconds = _parse_float_env(
            "SMS_GET_NUMBER_MAX_WAIT_SECONDS",
            DEFAULT_NUMBER_MAX_WAIT_SECONDS,
        )
        self._client = httpx.Client(
            timeout=httpx.Timeout(30.0, connect=20.0),
            trust_env=_http_trust_env("SMSPOOL_HTTP_TRUST_ENV"),
        )
        self._phone_exceptions = []
        self._last_country_profile = None

        if self.provider_ids:
            print(f"SMSPool pool filter: {','.join(self.provider_ids)}")

    def country_profile(self) -> PhoneCountryProfile:
        return profile_for_iso(self.country_iso)

    def _post(self, path: str, data: dict[str, str]) -> dict:
        payload = {"key": self.api_key, **data}
        response = self._client.post(f"{self.API_BASE}/{path}", data=payload)
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict):
            raise RuntimeError(f"SMSPool unexpected response: {body!r}")
        return body

    def buy_number(
        self,
        *,
        max_attempts: int | None = None,
        retry_delay_seconds: float | None = None,
        max_wait_seconds: float | None = None,
        on_poll: Callable[[], None] | None = None,
    ) -> PhoneActivation:
        last_error = "unknown error"
        retry_delay = (
            self.get_number_retry_seconds
            if retry_delay_seconds is None
            else retry_delay_seconds
        )
        max_wait = (
            self.get_number_max_wait_seconds
            if max_wait_seconds is None
            else max_wait_seconds
        )
        wait_until = _wait_until_number(max_wait_seconds)
        if max_attempts is None:
            max_attempts = max(
                1,
                int(max_wait / max(retry_delay, 0.5)) + 2,
            )
        deadline = time.monotonic() + max(max_wait, retry_delay)
        attempt = 0
        rotate_index = self._rr
        queued_once = False
        active_country = self.country_profile().smsbower_country

        while True:
            if not wait_until and (attempt >= max_attempts or time.monotonic() >= deadline):
                break
            attempt += 1
            if len(self.countries) > 1:
                active_country, rotate_index = _pick_rotating_country(self.countries, rotate_index)
                country = profile_from_country_id(active_country).iso
            else:
                country = self.country_iso
            data: dict[str, str] = {
                "country": country,
                "service": self.service,
            }
            if self.max_price:
                data["max_price"] = self.max_price
            if self.provider_ids:
                data["pool"] = self.provider_ids[0]

            body = self._post("purchase/sms", data)
            if body.get("success") == 1:
                order_id = str(body.get("order_id") or body.get("orderid") or "")
                cc = str(body.get("cc") or "")
                national = str(body.get("phonenumber") or body.get("number") or "")
                if not order_id or not national:
                    raise RuntimeError(f"SMSPool purchase missing fields: {body}")
                phone_number = f"{cc}{national}" if cc else national
                return self._remember(
                    PhoneActivation(
                        activation_id=order_id,
                        phone_number=phone_number,
                        country=active_country,
                    )
                )

            last_error = str(body.get("message") or body)
            message_upper = last_error.upper()
            retryable = (
                "NO_NUMBER" in message_upper
                or "NO NUMBERS" in message_upper
                or "OUT OF STOCK" in message_upper
            )
            if not retryable:
                break

            remaining = deadline - time.monotonic()
            if not wait_until and (remaining <= 0 or attempt >= max_attempts):
                break

            if wait_until and not queued_once:
                print(
                    "SMSPool phone step is waiting for a number; "
                    "will keep requesting until one is available"
                )
                queued_once = True
            sleep_for = _get_number_poll_sleep_seconds(retry_delay)
            if not wait_until:
                sleep_for = min(sleep_for, max(remaining, 0.0))
            print(
                f"SMSPool purchase queue wait ({attempt}): {last_error} "
                f"— retrying in {sleep_for:.1f}s..."
            )
            time.sleep(sleep_for)
            _poll_while_waiting(on_poll)

        raise RuntimeError(f"SMSPool purchase failed: {last_error}")

    def wait_for_sms(
        self,
        activation_id: str,
        timeout_seconds: int = 120,
        poll_interval: float = 3.0,
        on_poll: Callable[[], None] | None = None,
        expires_at: float = 0.0,
        ignore_codes: set[str] | None = None,
    ) -> str:
        del expires_at, ignore_codes
        deadline = time.time() + timeout_seconds
        last_log = 0.0

        while time.time() < deadline:
            if on_poll is not None:
                on_poll()

            body = self._post("sms/check", {"orderid": activation_id})
            status = int(body.get("status", 0))
            if status == 3:
                code = str(body.get("sms") or "").strip()
                if code:
                    return code
                full = str(body.get("full_sms") or "")
                match = re.search(r"\b(\d{4,8})\b", full)
                if match:
                    return match.group(1)
                raise RuntimeError(f"SMSPool completed but no code in response: {body}")

            if status in {5, 6, 2}:
                raise RuntimeError(f"SMSPool order ended with status {status}: {body}")

            now = time.time()
            if now - last_log >= 15:
                remaining = max(0, int(deadline - now))
                print(f"  Still waiting for SMS OTP ({remaining}s left)...")
                last_log = now

            time.sleep(poll_interval)

        raise TimeoutError(f"Timed out waiting for SMS on SMSPool order {activation_id}")

    def cancel(self, activation_id: str) -> None:
        for _ in range(3):
            try:
                body = self._post("sms/cancel", {"orderid": activation_id})
                if body.get("success") == 1:
                    return
            except Exception:
                pass
            time.sleep(2.0)

    def complete(self, activation_id: str) -> None:
        return

    def close(self) -> None:
        self._client.close()


class FiveSimClient(_SmsClientBase):
    """5SIM v1 API (https://5sim.net/docs)."""

    API_BASE = "https://5sim.net/v1"
    RETRYABLE_BUY_MARKERS = (
        "no free phones",
        "no free phone",
        "out of stock",
        "server offline",
    )

    def __init__(
        self,
        *,
        api_key: str,
        country_slug: str,
        product: str = "ticketmaster",
        operator: str = "any",
        max_price: str = "",
        provider_ids: tuple[str, ...] = (),
        handler_country: str = DEFAULT_COUNTRY,
        countries: tuple[str, ...] | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("FIVESIM_API_KEY is required")

        self.api_key = api_key
        self.country_slug = country_slug.strip().lower()
        self.product = (product or "ticketmaster").strip()
        self.operator = (operator or "any").strip() or "any"
        self.max_price = (max_price or "").strip()
        self.provider_ids = tuple(p.strip() for p in provider_ids if str(p).strip())
        if self.provider_ids:
            self.operator = self.provider_ids[0]
        self.countries = tuple(countries) if countries else (handler_country,)
        self.handler_country = self.countries[0]
        self._rr = 0
        self.provider_name = "5SIM"
        self.get_number_retry_seconds = _parse_float_env(
            "SMS_GET_NUMBER_RETRY_SECONDS",
            DEFAULT_NUMBER_RETRY_SECONDS,
        )
        self.get_number_max_wait_seconds = _parse_float_env(
            "SMS_GET_NUMBER_MAX_WAIT_SECONDS",
            DEFAULT_NUMBER_MAX_WAIT_SECONDS,
        )
        self._client = httpx.Client(
            timeout=httpx.Timeout(30.0, connect=20.0),
            trust_env=_http_trust_env("FIVESIM_HTTP_TRUST_ENV"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
            },
        )
        self._phone_exceptions = []
        self._last_country_profile = None
        print(
            f"5SIM buy path: country={self.country_slug} operator={self.operator} "
            f"product={self.product}"
            + (f" maxPrice={self.max_price}" if self.max_price else "")
        )

    def country_profile(self) -> PhoneCountryProfile:
        return profile_from_country_id(self.handler_country)

    def _get(self, path: str, params: dict[str, str] | None = None) -> tuple[int, str, dict | None]:
        response = self._client.get(f"{self.API_BASE}/{path.lstrip('/')}", params=params or {})
        text = response.text.strip()
        body: dict | None = None
        if text.startswith("{"):
            try:
                parsed = json.loads(text)
                if isinstance(parsed, dict):
                    body = parsed
            except json.JSONDecodeError:
                body = None
        return response.status_code, text, body

    def _slug_for_country(self, country_id: str) -> str:
        spec = get_country(country_id)
        if spec and spec.fivesim:
            return spec.fivesim
        if spec:
            return spec.iso.lower()
        return self.country_slug

    def buy_number(
        self,
        *,
        max_attempts: int | None = None,
        retry_delay_seconds: float | None = None,
        max_wait_seconds: float | None = None,
        on_poll: Callable[[], None] | None = None,
    ) -> PhoneActivation:
        last_error = "unknown error"
        retry_delay = (
            self.get_number_retry_seconds
            if retry_delay_seconds is None
            else retry_delay_seconds
        )
        max_wait = (
            self.get_number_max_wait_seconds
            if max_wait_seconds is None
            else max_wait_seconds
        )
        wait_until = _wait_until_number(max_wait_seconds)
        if max_attempts is None:
            max_attempts = max(1, int(max_wait / max(retry_delay, 0.5)) + 2)
        deadline = time.monotonic() + max(max_wait, retry_delay)
        attempt = 0
        rotate_index = self._rr
        queued_once = False
        active_country = self.handler_country
        params: dict[str, str] = {}
        if self.max_price and self.operator == "any":
            params["maxPrice"] = self.max_price

        while True:
            if not wait_until and (attempt >= max_attempts or time.monotonic() >= deadline):
                break
            attempt += 1
            if len(self.countries) > 1:
                active_country, rotate_index = _pick_rotating_country(self.countries, rotate_index)
            slug = self._slug_for_country(active_country) if len(self.countries) > 1 else self.country_slug
            path = f"user/buy/activation/{slug}/{self.operator}/{self.product}"
            status_code, text, body = self._get(path, params)
            _poll_while_waiting(on_poll)
            if status_code == 200 and body and body.get("id") and body.get("phone"):
                phone = str(body.get("phone") or "")
                cost = body.get("price")
                if cost is not None:
                    print(f"5SIM number cost: {cost} (order {body.get('id')})")
                return self._remember(
                    PhoneActivation(
                        activation_id=str(body["id"]),
                        phone_number=phone,
                        country=active_country,
                    )
                )

            last_error = str((body or {}).get("message") or text or f"HTTP {status_code}")
            lowered = last_error.lower()
            retryable = status_code == 200 or any(
                marker in lowered for marker in self.RETRYABLE_BUY_MARKERS
            )
            remaining = deadline - time.monotonic()
            if not retryable or (not wait_until and (remaining <= 0 or attempt >= max_attempts)):
                break
            if wait_until and not queued_once:
                print(
                    "5SIM phone step is waiting for a number; "
                    f"will keep requesting across {', '.join(self.countries)} until one is available"
                )
                queued_once = True
            sleep_for = _get_number_poll_sleep_seconds(retry_delay)
            if not wait_until:
                sleep_for = min(sleep_for, max(remaining, 0.0))
            print(
                f"5SIM buy wait ({attempt}, {slug}): {last_error} "
                f"— retrying in {sleep_for:.1f}s..."
            )
            time.sleep(sleep_for)
            _poll_while_waiting(on_poll)

        raise RuntimeError(f"5SIM buy failed: {last_error}")

    @staticmethod
    def _extract_sms_code(body: dict) -> str:
        code = str(body.get("code") or "").strip()
        if re.fullmatch(r"\d{4,8}", code):
            return code
        sms_list = body.get("sms")
        if isinstance(sms_list, list):
            for item in sms_list:
                if not isinstance(item, dict):
                    continue
                nested = str(item.get("code") or "").strip()
                if re.fullmatch(r"\d{4,8}", nested):
                    return nested
                text = str(item.get("text") or "")
                match = re.search(r"\b(\d{4,8})\b", text)
                if match:
                    return match.group(1)
        text = str(body.get("text") or "")
        match = re.search(r"\b(\d{4,8})\b", text)
        if match:
            return match.group(1)
        if code:
            return code
        return ""

    def wait_for_sms(
        self,
        activation_id: str,
        timeout_seconds: int = 120,
        poll_interval: float = 3.0,
        on_poll: Callable[[], None] | None = None,
        expires_at: float = 0.0,
        ignore_codes: set[str] | None = None,
    ) -> str:
        del expires_at, ignore_codes
        deadline = time.time() + timeout_seconds
        last_log = 0.0

        while time.time() < deadline:
            if on_poll is not None:
                on_poll()

            status_code, text, body = self._get(f"user/check/{activation_id}")
            if status_code == 200 and body:
                status = str(body.get("status") or "").upper()
                if status in {"CANCELED", "CANCELLED", "TIMEOUT", "BANNED"}:
                    raise RuntimeError(f"5SIM order {activation_id} ended with status {status}")
                code = self._extract_sms_code(body)
                if code:
                    return code
                if status == "FINISHED" and not code:
                    raise RuntimeError(f"5SIM order finished without a code: {body}")

            now = time.time()
            if now - last_log >= 15:
                remaining = max(0, int(deadline - now))
                print(f"  Still waiting for SMS OTP ({remaining}s left)...")
                last_log = now

            time.sleep(poll_interval)

        raise TimeoutError(f"Timed out waiting for SMS on 5SIM order {activation_id}")

    def cancel(self, activation_id: str) -> None:
        try:
            self._get(f"user/cancel/{activation_id}")
        except Exception:
            pass

    def complete(self, activation_id: str) -> None:
        try:
            self._get(f"user/finish/{activation_id}")
        except Exception:
            pass

    def close(self) -> None:
        self._client.close()


def parse_ticketmaster_phone(
    phone_number: str, profile: PhoneCountryProfile
) -> tuple[str, str]:
    digits = re.sub(r"\D", "", phone_number)
    if digits.startswith("00") and len(digits) > 4:
        digits = digits[2:]
    dial = profile.dial_code
    low, high = profile.length_bounds()

    national = ""
    if digits.startswith(dial):
        rest = digits[len(dial) :]
        if low <= len(rest) <= high + 1:
            national = rest
    if not national and low <= len(digits) <= high:
        national = digits

    if national.startswith("0") and low <= len(national) - 1 <= high:
        national = national[1:]

    if not national or not (low <= len(national) <= high):
        raise ValueError(
            f"Expected {low}-{high} national digits for {profile.tm_country_name} "
            f"(+{dial}), got {phone_number!r}"
        )

    return dial, national


def normalize_sms_country_id(raw: str) -> str:
    """Map a country id, ISO code, or name to an SMS-Activate handler id."""

    value = (raw or "").strip()
    if not value:
        return DEFAULT_COUNTRY
    return normalize_country_id(value)


_LEGACY_COUNTRY_ENV_VARS = (
    "SMSBOWER_COUNTRY",
    "HERO_SMS_COUNTRY",
    "SMSPOOL_COUNTRY",
    "FIVESIM_COUNTRY",
)


def resolve_sms_country_id() -> str:
    """Handler country id from SMS_COUNTRY (shared by every SMS provider)."""

    shared = os.getenv("SMS_COUNTRY", "").strip()
    if shared:
        return normalize_sms_country_id(shared)

    legacy: list[tuple[str, str]] = []
    for var in _LEGACY_COUNTRY_ENV_VARS:
        raw = os.getenv(var, "").strip()
        if raw:
            legacy.append((var, normalize_sms_country_id(raw)))

    if not legacy:
        return DEFAULT_COUNTRY

    ids = {country_id for _, country_id in legacy}
    if len(ids) > 1:
        parts = ", ".join(f"{var}={os.getenv(var)!r}" for var, _ in legacy)
        raise ValueError(
            f"Conflicting legacy country settings ({parts}). "
            "Use a single SMS_COUNTRY for all providers."
        )
    if legacy:
        print(f"Note: set SMS_COUNTRY instead of {legacy[0][0]}")
    return legacy[0][1]


def sms_country_iso_for_handler(handler_country_id: str) -> str:
    profile = HANDLER_COUNTRY_PROFILES.get(handler_country_id)
    if not profile:
        raise ValueError(f"Unknown handler country id {handler_country_id}")
    return str(profile["iso"])


def resolve_smspool_native_country_iso(handler_country_id: str) -> str:
    """SMSPool native API uses ISO; must match SMS_COUNTRY handler mapping."""

    expected = sms_country_iso_for_handler(handler_country_id)
    override = os.getenv("SMSPOOL_COUNTRY_ISO", "").strip().upper()
    if override and override != expected:
        raise ValueError(
            f"SMSPOOL_COUNTRY_ISO={override} conflicts with SMS_COUNTRY "
            f"(handler id {handler_country_id} → ISO {expected}). "
            "Remove SMSPOOL_COUNTRY_ISO or change SMS_COUNTRY."
        )
    return override or expected


def resolve_provider_country_ids(provider_slug: str) -> tuple[str, ...]:
    """Country list for the active provider. SMS_COUNTRY is the single-country fallback."""

    raw = ""
    if provider_slug in _SMSBOWER_PROVIDER_SLUGS:
        raw = os.getenv("SMSBOWER_COUNTRIES", "").strip() or os.getenv("SMS_COUNTRIES", "").strip()
    elif provider_slug in _GRIZZLY_PROVIDER_SLUGS:
        raw = (
            os.getenv("GRIZZLY_COUNTRIES", "").strip()
            or os.getenv("SMS_COUNTRIES", "").strip()
            or os.getenv("SMSBOWER_COUNTRIES", "").strip()
        )
    else:
        raw = (
            os.getenv("SMS_COUNTRIES", "").strip()
            or os.getenv("SMSBOWER_COUNTRIES", "").strip()
            or os.getenv("GRIZZLY_COUNTRIES", "").strip()
        )
    if not raw:
        return (resolve_sms_country_id(),)

    seen: list[str] = []
    for part in raw.split(","):
        if not part.strip():
            continue
        country_id = normalize_sms_country_id(part)
        if country_id not in seen:
            seen.append(country_id)
    if not seen:
        raise ValueError("SMS country list is empty")
    return tuple(seen)


def _provider_uses_number_pool(provider_slug: str) -> bool:
    return provider_slug in _SMSBOWER_PROVIDER_SLUGS or provider_slug in _GRIZZLY_PROVIDER_SLUGS


def create_phone_sms_client(
    provider_ids: tuple[str, ...] | None = None,
    *,
    pool_enabled: bool | None = None,
) -> PhoneSmsClient:
    provider = os.getenv("SMS_PROVIDER", "smsbower").strip().lower()
    if provider_ids is None:
        resolved_providers = _parse_provider_ids(provider)
    elif provider_ids:
        resolved_providers = provider_ids
    else:
        resolved_providers = _parse_provider_ids(provider)
    countries = resolve_provider_country_ids(provider)
    handler_country = countries[0]
    country_iso = sms_country_iso_for_handler(handler_country)
    print(f"Phone SMS provider: {provider}")
    if len(countries) == 1:
        print(
            f"SMS country: handler id {handler_country} ({country_iso}) "
            "(SMSBower / GrizzlySMS / Hero / SMSPool handler use this id)"
        )
    else:
        labels = []
        for country_id in countries:
            spec = get_country(country_id)
            labels.append(f"{country_id} ({spec.iso})" if spec else country_id)
        print(f"SMS countries: {', '.join(labels)}")

    if provider in {"hero", "hero_sms", "herosms", "hero-sms"}:
        api_key = os.getenv("HERO_SMS_API_KEY", "").strip()
        return HandlerApiSmsClient(
            api_key=api_key,
            api_url=os.getenv(
                "HERO_SMS_API_URL",
                "https://hero-sms.com/stubs/handler_api.php",
            ).strip(),
            provider_name="Hero SMS",
            service=os.getenv("HERO_SMS_SERVICE", os.getenv("SMS_SERVICE", DEFAULT_SERVICE)).strip(),
            country=handler_country,
            countries=countries,
            max_price=os.getenv("HERO_SMS_MAX_PRICE", os.getenv("SMS_MAX_PRICE", DEFAULT_MAX_PRICE)).strip(),
            min_price=os.getenv("HERO_SMS_MIN_PRICE", os.getenv("SMS_MIN_PRICE", DEFAULT_MIN_PRICE)).strip(),
            provider_ids=resolved_providers,
            trust_env_var="HERO_SMS_HTTP_TRUST_ENV",
        )

    if provider in _GRIZZLY_PROVIDER_SLUGS:
        grizzly_ids = _csv_env("GRIZZLY_PROVIDER_IDS") or resolved_providers
        return HandlerApiSmsClient(
            api_key=os.getenv("GRIZZLY_API_KEY", "").strip(),
            api_url=os.getenv(
                "GRIZZLY_API_URL",
                "https://api.grizzlysms.com/stubs/handler_api.php",
            ).strip(),
            provider_name="GrizzlySMS",
            service=os.getenv("GRIZZLY_SERVICE", os.getenv("SMS_SERVICE", DEFAULT_SERVICE)).strip(),
            country=handler_country,
            countries=countries,
            pool_enabled=pool_enabled,
            max_price=os.getenv("GRIZZLY_MAX_PRICE", os.getenv("SMS_MAX_PRICE", DEFAULT_MAX_PRICE)).strip(),
            min_price=os.getenv("GRIZZLY_MIN_PRICE", os.getenv("SMS_MIN_PRICE", DEFAULT_MIN_PRICE)).strip(),
            provider_ids=grizzly_ids,
            trust_env_var="GRIZZLY_HTTP_TRUST_ENV",
        )

    if provider in {"5sim", "fivesim", "five_sim", "5-sim"}:
        spec = get_country(handler_country)
        slug = spec.fivesim if spec and spec.fivesim else country_iso.lower()
        override = os.getenv("FIVESIM_COUNTRY_SLUG", "").strip().lower()
        if override and len(countries) == 1:
            slug = override
        operator = os.getenv("FIVESIM_OPERATOR", "any").strip() or "any"
        return FiveSimClient(
            api_key=os.getenv("FIVESIM_API_KEY", os.getenv("FIVE_SIM_API_KEY", "")).strip(),
            country_slug=slug,
            product=os.getenv("FIVESIM_SERVICE", "ticketmaster").strip() or "ticketmaster",
            operator=operator,
            max_price=os.getenv("FIVESIM_MAX_PRICE", os.getenv("SMS_MAX_PRICE", "")).strip(),
            provider_ids=resolved_providers,
            handler_country=handler_country,
            countries=countries,
        )

    if provider in {"smspool", "sms_pool"}:
        api_key = os.getenv("SMSPOOL_API_KEY", "").strip()
        api_mode = os.getenv("SMSPOOL_API_MODE", "handler").strip().lower()
        if api_mode == "native":
            pool_iso = resolve_smspool_native_country_iso(handler_country)
            return SmsPoolNativeClient(
                api_key=api_key,
                service=os.getenv("SMSPOOL_SERVICE", "").strip(),
                country_iso=pool_iso,
                max_price=os.getenv("SMSPOOL_MAX_PRICE", "").strip(),
                provider_ids=resolved_providers,
                countries=countries,
            )

        extras: dict[str, str] = {}
        if os.getenv("SMSPOOL_USE_SMSPOOL_IDS", "1").strip().lower() in {"1", "true", "yes"}:
            extras["setting"] = "smspool"
        return HandlerApiSmsClient(
            api_key=api_key,
            api_url=os.getenv(
                "SMSPOOL_HANDLER_API_URL",
                "https://api.smspool.net/stubs/handler_api",
            ).strip(),
            provider_name="SMSPool",
            service=os.getenv("SMSPOOL_SERVICE", os.getenv("SMS_SERVICE", DEFAULT_SERVICE)).strip(),
            country=handler_country,
            countries=countries,
            max_price=os.getenv("SMSPOOL_MAX_PRICE", os.getenv("SMS_MAX_PRICE", DEFAULT_MAX_PRICE)).strip(),
            min_price=os.getenv("SMSPOOL_MIN_PRICE", os.getenv("SMS_MIN_PRICE", DEFAULT_MIN_PRICE)).strip(),
            provider_ids=resolved_providers,
            extra_params=extras,
            trust_env_var="SMSPOOL_HTTP_TRUST_ENV",
        )

    return HandlerApiSmsClient(
        api_key=os.getenv("SMSBOWER_API_KEY", "").strip(),
        api_url=os.getenv(
            "SMSBOWER_API_URL",
            "https://smsbower.page/stubs/handler_api.php",
        ).strip(),
        provider_name="SMSBower",
        service=os.getenv("SMSBOWER_SERVICE", os.getenv("SMS_SERVICE", DEFAULT_SERVICE)).strip(),
        country=handler_country,
        max_price=os.getenv("SMSBOWER_MAX_PRICE", os.getenv("SMS_MAX_PRICE", DEFAULT_MAX_PRICE)).strip(),
        min_price=os.getenv("SMSBOWER_MIN_PRICE", os.getenv("SMS_MIN_PRICE", DEFAULT_MIN_PRICE)).strip(),
        provider_ids=resolved_providers,
        countries=countries,
        pool_enabled=pool_enabled,
        trust_env_var="SMSBOWER_HTTP_TRUST_ENV",
    )


def _csv_env(name: str) -> tuple[str, ...]:
    raw = os.getenv(name, "").strip()
    if not raw:
        return ()
    return tuple(part.strip() for part in raw.split(",") if part.strip())


def _parse_provider_ids(provider_slug: str = "") -> tuple[str, ...]:
    names = ["SMS_PROVIDER_IDS"]
    if provider_slug in _GRIZZLY_PROVIDER_SLUGS:
        names.append("GRIZZLY_PROVIDER_IDS")
    elif provider_slug in _SMSBOWER_PROVIDER_SLUGS or not provider_slug:
        names.append("SMSBOWER_PROVIDER_IDS")
    if provider_slug in {"hero", "hero_sms", "herosms", "hero-sms"} or not provider_slug:
        names.append("HERO_SMS_PROVIDER_IDS")
    if provider_slug in {"smspool", "sms_pool"} or not provider_slug:
        names.append("SMSPOOL_POOL")
    seen: list[str] = []
    for env_name in names:
        for part in _csv_env(env_name):
            if part not in seen:
                seen.append(part)
        if seen:
            return tuple(seen)
    return ()
