"""Rewrite export CSV rows using the canonical 32-segment COOKIES model."""

from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPORT_DIR = ROOT / "export"
EXPORT_FILE = EXPORT_DIR / "TicketMasterAccount.csv"
REFERENCE = ROOT / "TicketMasterAccount - Copy - Copy.csv"

CSV_HEADERS = [
    "EMAIL",
    "PASSWORD",
    "ZIP",
    "FIRSTNAME",
    "LASTNAME",
    "NUMBER",
    "PHONE",
    "COUNTRY",
    "PROXY",
    "STATUS",
    "DATE",
    "COOKIES",
    "PROFILE STATUS",
    "SORTC",
]

EXPORT_COOKIE_SPECS: list[tuple[str, str]] = [
    ("identity.ticketmaster.com", "tmpt"),
    ("identity.ticketmaster.com", "SID"),
    ("identity.ticketmaster.com", "BID"),
    ("ticketmaster.com", "tmpt"),
    ("ticketmaster.com", "LANGUAGE"),
    ("ticketmaster.com", "SID"),
    ("ticketmaster.com", "BID"),
    ("ticketmaster.com", "SOTC"),
    ("ticketmaster.com", "SORTC"),
    ("ticketmaster.com", "id-token"),
    ("ticketmaster.com", "TMUO"),
    ("auth.ticketmaster.com", "ma.LANGUAGE"),
    ("auth.ticketmaster.com", "ma.SID"),
    ("auth.ticketmaster.com", "ma.BID"),
    ("auth.ticketmaster.com", "ma.did"),
    ("auth.ticketmaster.com", "ma.paramsToken"),
    ("auth.ticketmaster.com", "ma.GSID"),
    ("auth.ticketmaster.com", "TMAUO"),
    ("auth.ticketmaster.com", "SID"),
    ("auth.ticketmaster.com", "BID"),
    ("auth.ticketmaster.com", "ma.pktrk"),
    ("auth.ticketmaster.com", "ma.SID"),
    ("auth.ticketmaster.com", "ma.BID"),
    ("auth.ticketmaster.com", "ma.did"),
    ("auth.ticketmaster.com", "ma.paramsToken"),
    ("auth.ticketmaster.com", "ma.GSID"),
    ("auth.ticketmaster.com", "TMAUO"),
    ("auth.ticketmaster.com", "SID"),
    ("auth.ticketmaster.com", "BID"),
    ("auth.ticketmaster.com", "tmpt"),
    ("epsf.ticketmaster.com", "SID"),
    ("epsf.ticketmaster.com", "BID"),
]


def normalize_export_domain(domain: str) -> str:
    normalized = domain.lstrip(".").lower()
    if normalized == "www.ticketmaster.com":
        return "ticketmaster.com"
    return normalized


def build_export_cookie_map(cookies: list[dict]) -> dict[tuple[str, str], str]:
    mapped: dict[tuple[str, str], str] = {}
    for cookie in cookies:
        domain = normalize_export_domain(str(cookie.get("domain", "")))
        name = str(cookie.get("name", ""))
        value = str(cookie.get("value", ""))
        if not domain or not name or not value:
            continue
        mapped[(domain, name)] = value
    return mapped


def extract_sortc_token(cookie_map: dict[tuple[str, str], str]) -> str:
    direct = cookie_map.get(("ticketmaster.com", "SORTC"))
    if direct:
        return direct
    for (_domain, name), value in cookie_map.items():
        if name == "SORTC" and value:
            return value
    return ""


def lookup_export_cookie_value(
    cookie_map: dict[tuple[str, str], str],
    export_domain: str,
    name: str,
) -> str:
    value = cookie_map.get((export_domain, name))
    if value:
        return value
    if export_domain == "ticketmaster.com" and name == "SORTC":
        return extract_sortc_token(cookie_map)
    return ""


def format_sortc_export_column(sortc_token: str) -> str:
    token = (sortc_token or "").strip()
    if not token:
        return ""
    if token.upper().startswith("SORTC="):
        return token
    return f"SORTC={token}"


def format_cookies(cookies: list[dict]) -> tuple[str, str]:
    cookie_map = build_export_cookie_map(cookies)
    parts: list[str] = []
    for export_domain, name in EXPORT_COOKIE_SPECS:
        value = lookup_export_cookie_value(cookie_map, export_domain, name)
        if value:
            parts.append(f"{export_domain}|{name}={value}")
    sortc_value = extract_sortc_token(cookie_map)
    return "; ".join(parts), format_sortc_export_column(sortc_value)


def missing_export_spec_pairs(
    cookie_map: dict[tuple[str, str], str],
) -> list[tuple[str, str]]:
    return [
        (export_domain, name)
        for export_domain, name in EXPORT_COOKIE_SPECS
        if not lookup_export_cookie_value(cookie_map, export_domain, name)
    ]


def parse_cookies_column(cookies_str: str) -> list[dict]:
    cookies: list[dict] = []
    for part in cookies_str.split(";"):
        part = part.strip()
        if not part or part.upper().startswith("SORTC="):
            continue
        if "|" not in part:
            continue
        domain, rest = part.split("|", 1)
        if "=" not in rest:
            continue
        name, value = rest.split("=", 1)
        cookies.append(
            {
                "domain": domain.strip(),
                "name": name.strip(),
                "value": value.strip(),
            }
        )
    return cookies


def sortc_from_row(row: dict[str, str], cookie_map: dict[tuple[str, str], str]) -> str:
    sortc_col = (row.get("SORTC") or "").strip()
    if sortc_col:
        return (
            sortc_col
            if sortc_col.upper().startswith("SORTC=")
            else f"SORTC={sortc_col}"
        )
    return format_sortc_export_column(extract_sortc_token(cookie_map))


def regenerate_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for row in rows:
        parsed = parse_cookies_column(row.get("COOKIES", ""))
        cookies_str, sortc_from_format = format_cookies(parsed)
        cookie_map = build_export_cookie_map(parsed)
        sortc = sortc_from_row(row, cookie_map) or sortc_from_format
        missing = missing_export_spec_pairs(cookie_map)
        email = row.get("EMAIL", "")
        present = len(EXPORT_COOKIE_SPECS) - len(missing)
        print(
            f"{email}: {present}/{len(EXPORT_COOKIE_SPECS)} model cookies "
            f"({len([p for p in cookies_str.split(';') if p.strip()])} COOKIES segments)"
        )
        new_row = {key: row.get(key, "") for key in CSV_HEADERS}
        new_row["COOKIES"] = cookies_str
        new_row["SORTC"] = sortc
        new_row.setdefault("PROFILE STATUS", "")
        new_row.setdefault("STATUS", "")
        out.append(new_row)
    return out


def write_export(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=CSV_HEADERS,
            quoting=csv.QUOTE_MINIMAL,
            lineterminator="\n",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})
    print(f"Wrote {path} ({len(rows)} row(s))")


def load_unique_rows(sources: list[Path]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    seen: set[str] = set()
    for source in sources:
        if not source.exists():
            continue
        with source.open(encoding="utf-8", newline="") as file:
            for row in csv.DictReader(file):
                email = (row.get("EMAIL") or "").strip().lower()
                if not email or email in seen:
                    continue
                seen.add(email)
                rows.append(dict(row))
    return rows


def main() -> None:
    sources = [EXPORT_FILE]
    rows = load_unique_rows(sources)
    if not rows:
        raise SystemExit("No export rows found to regenerate.")

    regenerated = regenerate_rows(rows)
    write_export(EXPORT_FILE, regenerated)


if __name__ == "__main__":
    main()
