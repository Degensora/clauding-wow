"""Discord webhook notifications for successful signups."""

from __future__ import annotations

import os

import httpx


def _webhook_url() -> str:
    return (os.getenv("DISCORD_WEBHOOK_URL") or "").strip()


def notify_account_created(
    *,
    email: str,
    password: str,
    first_name: str,
    last_name: str,
    postal_code: str,
    country: str,
    phone: str,
    proxy_line: str,
) -> None:
    url = _webhook_url()
    if not url:
        return

    digits = "".join(c for c in phone if c.isdigit())
    phone_display = f"+{digits}" if digits else phone
    fields = [
        {"name": "Email", "value": email, "inline": False},
        {"name": "Password", "value": password, "inline": False},
        {"name": "Phone", "value": phone_display, "inline": True},
        {"name": "Country", "value": country.upper(), "inline": True},
        {"name": "ZIP", "value": postal_code or "—", "inline": True},
        {
            "name": "Name",
            "value": f"{first_name} {last_name}".strip() or "—",
            "inline": True,
        },
    ]
    if proxy_line:
        fields.append(
            {"name": "Proxy", "value": f"`{proxy_line[:900]}`", "inline": False}
        )

    payload = {
        "username": "TM Signup",
        "embeds": [
            {
                "title": "Ticketmaster account created successfully 🎉!!!",
                "color": 0x5865F2,
                "fields": fields,
            }
        ],
    }

    try:
        response = httpx.post(url, json=payload, timeout=15.0)
        response.raise_for_status()
        print("Discord webhook notification sent.")
    except httpx.HTTPError as exc:
        print(f"Warning: Discord webhook failed ({exc})")
