"""Track signup emails in customsinformation.csv (replaces email.txt)."""

import csv
from datetime import datetime
from pathlib import Path

from config import interprocess_lock

CUSTOMS_FILE = Path(__file__).parent / "customsinformation.csv"
CUSTOMS_LOCK = CUSTOMS_FILE.parent / ".customsinformation.lock"

CSV_HEADERS = ("EMAIL", "STATUS", "DATE_USED", "NOTES")

STATUS_UNUSED = "unused"
STATUS_USED = "used"

_USED_STATUS_TOKENS = frozenset(
    {
        "used",
        "complete",
        "completed",
        "done",
        "exported",
        "success",
        "yes",
        "y",
    }
)
_UNUSED_STATUS_TOKENS = frozenset({"unused", "pending", "no", "n", ""})


def _normalize_status(raw: str) -> str:
    value = (raw or "").strip().lower()
    if value in _USED_STATUS_TOKENS:
        return STATUS_USED
    if value in _UNUSED_STATUS_TOKENS:
        return STATUS_UNUSED
    # Unknown values: treat as unused unless they clearly mean "used"
    if "used" in value or "export" in value or "complete" in value:
        return STATUS_USED
    return STATUS_UNUSED


def _normalize_email(email: str) -> str:
    return email.strip().lower()


def _read_rows() -> list[dict[str, str]]:
    if not CUSTOMS_FILE.exists():
        return []

    with CUSTOMS_FILE.open(newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        rows: list[dict[str, str]] = []
        for row in reader:
            email = ""
            status_raw = ""
            date_used = ""
            notes = ""
            for key, value in row.items():
                if not key:
                    continue
                normalized_key = key.strip().lstrip("\ufeff").upper()
                text = (value or "").strip()
                if normalized_key == "EMAIL":
                    email = text
                elif normalized_key == "STATUS":
                    status_raw = text
                elif normalized_key == "DATE_USED":
                    date_used = text
                elif normalized_key == "NOTES":
                    notes = text
            if not email:
                continue
            status = _normalize_status(status_raw)
            if status != STATUS_USED and date_used:
                status = STATUS_USED
            rows.append(
                {
                    "EMAIL": email,
                    "STATUS": status,
                    "DATE_USED": date_used,
                    "NOTES": notes,
                }
            )
        return rows


def _write_rows(rows: list[dict[str, str]]) -> None:
    CUSTOMS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with CUSTOMS_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=CSV_HEADERS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})


def ensure_customs_file() -> None:
    if CUSTOMS_FILE.exists():
        return

    legacy_txt = Path(__file__).parent / "email.txt"
    rows: list[dict[str, str]] = []
    if legacy_txt.exists():
        for line in legacy_txt.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(
                    {
                        "EMAIL": line,
                        "STATUS": STATUS_UNUSED,
                        "DATE_USED": "",
                        "NOTES": "imported from email.txt",
                    }
                )
    _write_rows(rows)


def _merged_email_rows() -> dict[str, dict[str, str]]:
    """One entry per email; ``used`` wins if duplicate rows disagree."""

    merged: dict[str, dict[str, str]] = {}
    for row in _read_rows():
        key = _normalize_email(row["EMAIL"])
        if not key:
            continue
        existing = merged.get(key)
        if existing is None:
            merged[key] = dict(row)
            continue
        if row["STATUS"] == STATUS_USED:
            merged[key] = dict(row)
        elif existing["STATUS"] != STATUS_USED:
            merged[key] = dict(row)
    return merged


def is_email_marked_used(email: str) -> bool:
    """Fresh read from disk — safe to call before each signup attempt."""

    key = _normalize_email(email)
    if not key:
        return True
    row = _merged_email_rows().get(key)
    if row is None:
        return False
    return row["STATUS"] == STATUS_USED


def load_pending_emails() -> list[str]:
    """Emails eligible for signup: not ``used`` (re-reads customsinformation.csv)."""
    ensure_customs_file()
    pending = [
        row["EMAIL"]
        for row in _merged_email_rows().values()
        if row["STATUS"] != STATUS_USED
    ]
    if not pending:
        raise ValueError(
            f"No available emails in {CUSTOMS_FILE}. "
            f"Add rows with STATUS={STATUS_UNUSED} (or leave STATUS empty)."
        )
    return pending


def _update_email(email: str, *, status: str, notes: str = "") -> None:
    normalized = _normalize_email(email)
    if not normalized:
        return

    with interprocess_lock(CUSTOMS_LOCK):
        rows = _read_rows()
        found = False
        for row in rows:
            if _normalize_email(row["EMAIL"]) != normalized:
                continue
            found = True
            row["STATUS"] = _normalize_status(status)
            if row["STATUS"] == STATUS_USED:
                row["DATE_USED"] = datetime.now().strftime("%d/%m/%Y")
            if notes:
                row["NOTES"] = notes
            break

        if not found:
            rows.append(
                {
                    "EMAIL": email.strip(),
                    "STATUS": _normalize_status(status),
                    "DATE_USED": datetime.now().strftime("%d/%m/%Y")
                    if _normalize_status(status) == STATUS_USED
                    else "",
                    "NOTES": notes,
                }
            )

        _write_rows(rows)


def mark_email_used(email: str, notes: str = "account exported") -> None:
    _update_email(email, status=STATUS_USED, notes=notes)
    print(f"Marked {email} as used in {CUSTOMS_FILE}")


