"""Limit how many CloakBrowser instances launch at once across worker processes."""

from __future__ import annotations

import atexit
import json
import os
import random
import time
from contextlib import contextmanager
from pathlib import Path

from config import RUNTIME_DIR, interprocess_lock, load_config


class BrowserSlotWaitTimeout(TimeoutError):
    """Raised when no browser slot becomes free within browser_slot_wait_seconds."""


_SLOTS_LOCK = RUNTIME_DIR / "browser_slots.lock"
_SLOTS_STATE = RUNTIME_DIR / "browser_slots.json"
_LAUNCH_LOCK = RUNTIME_DIR / "browser_launch.lock"
_LAUNCH_STATE = RUNTIME_DIR / "browser_launch.json"

_slot_held_by_process = False
_launch_gate_held = False

_MAX_SLOT_HOLDER_SECONDS = 7200.0
_alive_pid_cache: tuple[float, set[int]] | None = None
_cached_max_active_sessions: int | None = None
_cached_max_simultaneous_launches: int | None = None
_cached_launch_spacing: float | None = None


def configure_browser_pool_limits(
    *,
    max_active_sessions: int,
    max_simultaneous_launches: int,
    launch_spacing_seconds: float,
) -> None:
    global _cached_max_active_sessions
    global _cached_max_simultaneous_launches
    global _cached_launch_spacing
    _cached_max_active_sessions = max(1, int(max_active_sessions))
    _cached_max_simultaneous_launches = max(1, int(max_simultaneous_launches))
    _cached_launch_spacing = max(0.0, float(launch_spacing_seconds))


def _living_pid_snapshot() -> set[int] | None:
    """One process-table snapshot, cached briefly. Never call this while holding a slot lock."""
    global _alive_pid_cache
    now = time.time()
    if _alive_pid_cache is not None and (now - _alive_pid_cache[0]) < 1.0:
        return _alive_pid_cache[1]
    try:
        import psutil

        pids = {int(proc.pid) for proc in psutil.process_iter(["pid"])}
    except Exception:
        return None
    _alive_pid_cache = (now, pids)
    return pids


def _read_json_list(path: Path, key: str) -> list[dict[str, float | int]]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []

    holders = data.get(key)
    if not isinstance(holders, list):
        return []

    cleaned: list[dict[str, float | int]] = []
    for item in holders:
        if not isinstance(item, dict):
            continue
        try:
            pid = int(item.get("pid", 0))
        except (TypeError, ValueError):
            continue
        if pid <= 0:
            continue
        since = float(item.get("since", 0.0) or 0.0)
        cleaned.append({"pid": pid, "since": since})
    return cleaned


def _write_json_list(path: Path, key: str, holders: list[dict[str, float | int]]) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                key: holders,
                "active": len(holders),
                "updated": time.time(),
            }
        ),
        encoding="utf-8",
    )


def _read_holders() -> list[dict[str, float | int]]:
    return _read_json_list(_SLOTS_STATE, "holders")


def _write_holders(holders: list[dict[str, float | int]]) -> None:
    _write_json_list(_SLOTS_STATE, "holders", holders)


def _read_launch_holders() -> list[dict[str, float | int]]:
    return _read_json_list(_LAUNCH_STATE, "holders")


def _write_launch_holders(holders: list[dict[str, float | int]]) -> None:
    _write_json_list(_LAUNCH_STATE, "holders", holders)


def _prune_stale_holders(
    holders: list[dict[str, float | int]],
    *,
    max_age_seconds: float,
    alive_pids: set[int] | None,
) -> list[dict[str, float | int]]:
    now = time.time()
    living: list[dict[str, float | int]] = []
    for item in holders:
        pid = int(item["pid"])
        since = float(item.get("since", 0.0) or 0.0)
        if since and (now - since) > max_age_seconds:
            continue
        if alive_pids is not None and pid not in alive_pids:
            continue
        living.append(item)
    return living


def reconcile_browser_slots() -> None:
    """Drop slot entries for crashed worker processes (does not reset the pool)."""

    alive = _living_pid_snapshot()
    try:
        with interprocess_lock(_SLOTS_LOCK, timeout=30.0):
            _write_holders(
                _prune_stale_holders(
                    _read_holders(),
                    max_age_seconds=_MAX_SLOT_HOLDER_SECONDS,
                    alive_pids=alive,
                )
            )
    except Exception:
        pass
    try:
        with interprocess_lock(_LAUNCH_LOCK, timeout=30.0):
            _write_launch_holders(
                _prune_stale_holders(
                    _read_launch_holders(),
                    max_age_seconds=180.0,
                    alive_pids=alive,
                )
            )
    except Exception:
        pass


def reset_browser_slots() -> None:
    """Clear slot counter at the start of a run (recovers from crashed workers)."""

    for lock_path in (_SLOTS_LOCK, _LAUNCH_LOCK):
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            pass
    try:
        with interprocess_lock(_SLOTS_LOCK, timeout=30.0):
            _write_holders([])
    except Exception:
        _write_holders([])
    try:
        with interprocess_lock(_LAUNCH_LOCK, timeout=30.0):
            _write_launch_holders([])
    except Exception:
        _write_launch_holders([])


def max_active_browser_sessions() -> int:
    if _cached_max_active_sessions is not None:
        return _cached_max_active_sessions
    config = load_config()
    if config.max_active_browser_sessions > 0:
        return config.max_active_browser_sessions
    return max(1, config.concurrent_browsers)


def max_simultaneous_browser_launches() -> int:
    if _cached_max_simultaneous_launches is not None:
        return _cached_max_simultaneous_launches
    config = load_config()
    value = int(getattr(config, "max_simultaneous_browser_launches", 0) or 0)
    if value > 0:
        return value
    return max(1, config.concurrent_browsers)


def browser_launch_spacing_seconds() -> float:
    if _cached_launch_spacing is not None:
        return _cached_launch_spacing
    config = load_config()
    return max(0.0, float(config.browser_launch_spacing_seconds))


def _release_holders_for_pid(
    *,
    lock_path: Path,
    read_fn,
    write_fn,
    pid: int,
    max_age_seconds: float,
) -> None:
    alive = _living_pid_snapshot()
    try:
        with interprocess_lock(lock_path, timeout=15.0):
            holders = _prune_stale_holders(
                read_fn(),
                max_age_seconds=max_age_seconds,
                alive_pids=alive,
            )
            write_fn([h for h in holders if int(h["pid"]) != pid])
    except Exception:
        pass


def _emergency_release_browser_slot() -> None:
    global _slot_held_by_process, _launch_gate_held
    pid = os.getpid()
    if _launch_gate_held:
        _release_holders_for_pid(
            lock_path=_LAUNCH_LOCK,
            read_fn=_read_launch_holders,
            write_fn=_write_launch_holders,
            pid=pid,
            max_age_seconds=180.0,
        )
        _launch_gate_held = False
    if _slot_held_by_process:
        _release_holders_for_pid(
            lock_path=_SLOTS_LOCK,
            read_fn=_read_holders,
            write_fn=_write_holders,
            pid=pid,
            max_age_seconds=_MAX_SLOT_HOLDER_SECONDS,
        )
        _slot_held_by_process = False


atexit.register(_emergency_release_browser_slot)


def _acquire_listed_slot(
    *,
    lock_path: Path,
    read_fn,
    write_fn,
    max_slots: int,
    timeout_seconds: float,
    max_age_seconds: float,
    label: str,
) -> None:
    deadline = time.time() + timeout_seconds
    attempt = 0
    pid = os.getpid()

    while time.time() < deadline:
        attempt += 1
        alive = _living_pid_snapshot()
        remaining = max(1.0, deadline - time.time())
        try:
            with interprocess_lock(lock_path, timeout=min(8.0, remaining)):
                holders = _prune_stale_holders(
                    read_fn(),
                    max_age_seconds=max_age_seconds,
                    alive_pids=alive,
                )
                holders = [h for h in holders if int(h["pid"]) != pid]
                if len(holders) < max_slots:
                    holders.append({"pid": pid, "since": time.time()})
                    write_fn(holders)
                    if attempt > 1:
                        print(f"Acquired {label} ({len(holders)}/{max_slots} active)")
                    return
                waiting = len(holders)
        except TimeoutError:
            if attempt == 1 or attempt % 5 == 0:
                print(
                    f"{label} lock busy — retrying "
                    f"(attempt {attempt}, pid={pid})"
                )
            time.sleep(min(2.0, 0.15 + random.random()))
            continue

        wait = min(8.0, 1.0 + random.uniform(0.3, 1.2) * attempt)
        if attempt == 1 or attempt % 8 == 0:
            print(
                f"Waiting for {label} ({waiting}/{max_slots} active, "
                f"attempt {attempt}, pid={pid})..."
            )
        time.sleep(wait)

    raise BrowserSlotWaitTimeout(
        f"Timed out waiting for {label} ({max_slots} max)"
    )


def _acquire_browser_slot(*, max_slots: int, timeout_seconds: float) -> None:
    global _slot_held_by_process
    _acquire_listed_slot(
        lock_path=_SLOTS_LOCK,
        read_fn=_read_holders,
        write_fn=_write_holders,
        max_slots=max_slots,
        timeout_seconds=timeout_seconds,
        max_age_seconds=_MAX_SLOT_HOLDER_SECONDS,
        label="browser slot",
    )
    _slot_held_by_process = True


def _release_browser_slot() -> None:
    global _slot_held_by_process
    _release_holders_for_pid(
        lock_path=_SLOTS_LOCK,
        read_fn=_read_holders,
        write_fn=_write_holders,
        pid=os.getpid(),
        max_age_seconds=_MAX_SLOT_HOLDER_SECONDS,
    )
    _slot_held_by_process = False


def _acquire_launch_gate(*, max_launches: int, timeout_seconds: float) -> None:
    global _launch_gate_held
    _acquire_listed_slot(
        lock_path=_LAUNCH_LOCK,
        read_fn=_read_launch_holders,
        write_fn=_write_launch_holders,
        max_slots=max_launches,
        timeout_seconds=timeout_seconds,
        max_age_seconds=180.0,
        label="browser launch gate",
    )
    _launch_gate_held = True


def _release_launch_gate() -> None:
    global _launch_gate_held
    _release_holders_for_pid(
        lock_path=_LAUNCH_LOCK,
        read_fn=_read_launch_holders,
        write_fn=_write_launch_holders,
        pid=os.getpid(),
        max_age_seconds=180.0,
    )
    _launch_gate_held = False


@contextmanager
def browser_launch_gate():
    """Stagger CloakBrowser launches so Windows does not spawn every Chromium at once."""

    spacing = browser_launch_spacing_seconds()
    if spacing > 0:
        time.sleep(random.uniform(spacing * 0.25, spacing))

    config = load_config()
    _acquire_launch_gate(
        max_launches=max_simultaneous_browser_launches(),
        timeout_seconds=float(config.browser_slot_wait_seconds),
    )
    try:
        yield
    finally:
        _release_launch_gate()


@contextmanager
def browser_session_slot():
    """Hold a cross-process slot for one live CloakBrowser session."""

    config = load_config()
    _acquire_browser_slot(
        max_slots=max_active_browser_sessions(),
        timeout_seconds=float(config.browser_slot_wait_seconds),
    )
    try:
        yield
    finally:
        _release_browser_slot()


@contextmanager
def browser_launch_slot():
    """Backward-compatible alias for browser_session_slot()."""

    with browser_session_slot():
        yield
