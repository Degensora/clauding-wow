import csv
import multiprocessing as mp
import os
import random
import re
import secrets
import string
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
import signal
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from playwright.sync_api import BrowserContext, Page, expect

from aycd import AycdInboxClient, create_aycd_client
from discord_notify import notify_account_created
from browser_slots import (
    BrowserSlotWaitTimeout,
    browser_launch_gate,
    browser_session_slot,
    configure_browser_pool_limits,
    max_active_browser_sessions,
    reconcile_browser_slots,
    reset_browser_slots,
)
from process_cleanup import (
    cleanup_orphan_tm_browsers,
    kill_browser_child_processes,
    shutdown_process_tree,
)
from browser import (
    BrowsingPausedRestart,
    ExistingTicketmasterAccountError,
    InvalidOtpCode,
    OtpValidationRestart,
    click_request_new_otp_code,
    SessionInterruptedRestart,
    PhoneNumberSessionRestart,
    PhoneNumberUnsupportedError,
    PhoneVerifyRetry,
    dismiss_phone_try_later_dialog,
    click_signup_from_home,
    complete_post_signup_navigation,
    dismiss_passkey_prompt_if_present,
    is_tm_portal_content_error,
    recover_tm_session_for_export,
    is_phone_number_unsupported,
    configure_ticketmaster_phone_country,
    ensure_ticketmaster_phone_number,
    fill_ticketmaster_phone_number,
    reset_phone_entry_for_next_attempt,
    check_phone_marketing_consent,
    click_phone_add_number_button,
    check_signup_disclaimer,
    click_add_phone_button,
    click_until_visible,
    click_verify_email_button,
    configure_cloakbrowser,
    configure_home_scroll_before_signup,
    configure_signup_disclaimer_read,
    configure_phone_add_number_submits,
    configure_spotify_before_ticketmaster,
    configure_step_delays,
    create_browser_session,
    destroy_browser_session,
    ensure_cloakbrowser_ready,
    ensure_email_verification_step,
    ensure_not_blocked,
    fill_field,
    fill_phone_field,
    fill_tm_field,
    human_button,
    human_click,
    human_heading,
    human_pause,
    verify_tm_field,
    submit_auth_email_address,
    is_passkey_prompt_page,
    is_session_export_ready_page,
    wait_for_confirm_account_step,
    wait_for_phone_otp_modal,
    wait_for_signup_password_form,
    poll_page_during_otp_wait,
    submit_otp_code,
)
from config import AppConfig, interprocess_lock, load_config, resolve_sms_provider_ids
from email_inventory import (
    ensure_customs_file,
    is_email_marked_used,
    load_pending_emails,
    mark_email_used,
)
from signup_data import random_first_name, random_last_name, random_postal_for_country
from phone_sms import (
    DEFAULT_PHONE_NUMBER_MAX_ROTATIONS,
    PhoneCountryProfile,
    PhoneSmsClient,
    SmsActivationLowTime,
    activation_seconds_left,
    create_phone_sms_client,
    format_activation_time_left,
    parse_ticketmaster_phone,
    sms_min_remaining_seconds,
)
from sms_number_pool import start_sms_number_pool

load_dotenv()

AUTH_PAGE_TIMEOUT_MS = 360_000
NAVIGATION_TIMEOUT_MS = 120_000
POST_SIGNUP_WAIT_MS = 90_000
OTP_WAIT_SECONDS = 300
SMS_OTP_WAIT_SECONDS = 180
PHONE_NUMBER_MAX_ROTATIONS = DEFAULT_PHONE_NUMBER_MAX_ROTATIONS
SMS_PROVIDER_IDS: tuple[str, ...] = ()

TM_COOKIE_URLS = [
    "https://www.ticketmaster.com",
    "https://ticketmaster.com",
    "https://auth.ticketmaster.com",
    "https://identity.ticketmaster.com",
    "https://epsf.ticketmaster.com",
    "https://my.ticketmaster.com",
]

POST_SIGNUP_HOME_RE = re.compile(r"^https://(?:www\.)?ticketmaster\.com(?:/|$|\?)")

# Session CSV column order and cookie segments (32 entries, incl. duplicate auth block).
EXPORT_COOKIE_SPECS: list[tuple[str, str]] = [
    ("identity.ticketmaster.com", "tmpt"),
    ("identity.ticketmaster.com", "SID"),
    ("identity.ticketmaster.com", "BID"),
    ("ticketmaster.com", "tmpt"),
    ("ticketmaster.com", "LANGUAGE"),
    ("ticketmaster.com", "SID"),
    ("ticketmaster.com", "BID"),
    ("ticketmaster.com", "SOTC"),
    ("ticketmaster.com", "SORTC"),
    ("ticketmaster.com", "id-token"),
    ("ticketmaster.com", "TMUO"),
    ("auth.ticketmaster.com", "ma.LANGUAGE"),
    ("auth.ticketmaster.com", "ma.SID"),
    ("auth.ticketmaster.com", "ma.BID"),
    ("auth.ticketmaster.com", "ma.did"),
    ("auth.ticketmaster.com", "ma.paramsToken"),
    ("auth.ticketmaster.com", "ma.GSID"),
    ("auth.ticketmaster.com", "TMAUO"),
    ("auth.ticketmaster.com", "SID"),
    ("auth.ticketmaster.com", "BID"),
    ("auth.ticketmaster.com", "ma.pktrk"),
    ("auth.ticketmaster.com", "ma.SID"),
    ("auth.ticketmaster.com", "ma.BID"),
    ("auth.ticketmaster.com", "ma.did"),
    ("auth.ticketmaster.com", "ma.paramsToken"),
    ("auth.ticketmaster.com", "ma.GSID"),
    ("auth.ticketmaster.com", "TMAUO"),
    ("auth.ticketmaster.com", "SID"),
    ("auth.ticketmaster.com", "BID"),
    ("auth.ticketmaster.com", "tmpt"),
    ("epsf.ticketmaster.com", "SID"),
    ("epsf.ticketmaster.com", "BID"),
]

PROXY_FILE = Path(__file__).parent / "proxy.txt"
PROXY_LOCK_FILE = Path(__file__).parent / ".proxy.lock"
EXPORT_DIR = Path(__file__).parent / "export"
EXPORT_FILE = EXPORT_DIR / "TicketMasterAccount.csv"

CSV_HEADERS = [
    "EMAIL",
    "PASSWORD",
    "ZIP",
    "FIRSTNAME",
    "LASTNAME",
    "NUMBER",
    "PHONE",
    "COUNTRY",
    "PROXY",
    "STATUS",
    "DATE",
    "COOKIES",
    "PROFILE STATUS",
    "SORTC",
]

EXPORT_LOCK_FILE = EXPORT_DIR / ".export.lock"

_COUNTRY_EXPORT_CODES = {"US": "us", "GB": "uk", "CL": "cl"}


@dataclass
class SignupDetails:
    first_name: str
    last_name: str
    password: str
    country: str
    postal_code: str


def load_lines(path: Path) -> list[str]:
    if not path.exists():
        return []

    lines: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            lines.append(line)
    return lines


def parse_proxy_line(line: str) -> dict[str, str] | None:
    if not line:
        return None

    if "://" in line:
        parsed = urlparse(line)
        proxy: dict[str, str] = {"server": f"{parsed.scheme}://{parsed.hostname}:{parsed.port}"}
        if parsed.username:
            proxy["username"] = parsed.username
        if parsed.password:
            proxy["password"] = parsed.password
        return proxy

    parts = line.split(":")
    if len(parts) == 2:
        host, port = parts
        return {"server": f"http://{host}:{port}"}
    if len(parts) >= 4:
        host, port, username = parts[0], parts[1], parts[2]
        password = ":".join(parts[3:])
        return {
            "server": f"http://{host}:{port}",
            "username": username,
            "password": password,
        }

    raise ValueError(f"Invalid proxy format: {line}")


def load_proxy_lines(path: Path = PROXY_FILE) -> list[str]:
    return load_lines(path)


def load_proxy_by_index(index: int = 0, path: Path = PROXY_FILE) -> tuple[dict[str, str] | None, str]:
    lines = load_proxy_lines(path)
    if not lines:
        return None, ""

    line = lines[index % len(lines)]
    return parse_proxy_line(line), line


def remove_proxy_line(line: str, *, path: Path = PROXY_FILE) -> bool:
    """Remove one proxy line from proxy.txt (safe across worker processes)."""

    target = line.strip()
    if not target:
        return False

    with interprocess_lock(PROXY_LOCK_FILE):
        lines = load_lines(path)
        kept = [entry for entry in lines if entry.strip() != target]
        if len(kept) == len(lines):
            print(
                f"Failed proxy not found in {path.name} (already removed?): "
                f"{target[:72]}..."
            )
            return False

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            "\n".join(kept) + ("\n" if kept else ""),
            encoding="utf-8",
        )
        removed = len(lines) - len(kept)
        print(
            f"Removed {removed} failed proxy line(s) from {path.name} "
            f"({len(kept)} remaining)."
        )
        return True


def burn_failed_proxy(proxy_line: str) -> None:
    if not proxy_line.strip():
        return
    remove_proxy_line(proxy_line)


def count_distinct_proxy_servers(path: Path = PROXY_FILE) -> tuple[int, int]:
    """Return (total lines, distinct proxy server URLs)."""

    lines = load_proxy_lines(path)
    if not lines:
        return 0, 0
    servers: set[str] = set()
    for line in lines:
        try:
            parsed = parse_proxy_line(line)
            if parsed:
                servers.add(parsed["server"])
        except Exception:
            continue
    return len(lines), len(servers)


def personalize_proxy_settings(proxy: dict[str, str] | None) -> dict[str, str] | None:
    """Give each browser its own sticky proxy session when supported."""

    if not proxy:
        return None

    settings = dict(proxy)
    password = settings.get("password", "")
    if not password:
        return settings

    session_id = secrets.token_urlsafe(8)
    if re.search(r"session[-_]", password, re.IGNORECASE):
        settings["password"] = re.sub(
            r"([_-]?session[-_])[A-Za-z0-9]+",
            lambda match: f"{match.group(1)}{session_id}",
            password,
            count=1,
            flags=re.IGNORECASE,
        )
    return settings


def resolve_parallel_browser_cap(requested: int) -> int:
    """Cap parallel browsers to CloakBrowser license seats when known."""

    if requested < 1:
        return 1

    license_key = os.getenv("CLOAKBROWSER_LICENSE_KEY", "").strip()
    if not license_key:
        return requested

    try:
        from cloakbrowser.license import get_session_seats

        seats = get_session_seats(license_key)
    except Exception:
        return requested

    if seats.state != "ok" or seats.limit is None:
        return requested

    active = seats.active if seats.active is not None else 0
    # Cap to the license limit only. Ghost "active" seats from crashed browsers
    # used to shrink this to 1–2 live workers even when the key allows more.
    capped = min(requested, max(1, seats.limit))
    if active:
        print(
            f"CloakBrowser license: {seats.limit} seat(s), server reports "
            f"{active} already active (often leftovers from a crash)."
        )
    if capped < requested:
        print(
            f"CloakBrowser license allows {seats.limit} concurrent session(s); "
            f"running {capped} browser process(es) in parallel."
        )
    return capped


def stagger_worker_start(worker_slot: int, email: str) -> None:
    config = load_config()
    step = config.worker_spawn_stagger_seconds
    if worker_slot <= 0 and step <= 0:
        return

    delay = worker_slot * step + random.uniform(1.0, 3.0)
    print(f"[{email}] Staggering worker start by {delay:.1f}s...")
    time.sleep(delay)


def load_emails() -> list[str]:
    ensure_customs_file()
    return load_pending_emails()


def generate_password(length: int = 16) -> str:
    length = max(length, 12)
    letters = string.ascii_letters
    digits = string.digits
    all_chars = letters + digits + "!@#$%"

    password = [
        secrets.choice(letters),
        secrets.choice(digits),
    ]
    password.extend(secrets.choice(all_chars) for _ in range(length - len(password)))

    secrets.SystemRandom().shuffle(password)
    return "".join(password)


def build_signup_details(phone_profile: PhoneCountryProfile) -> SignupDetails:
    iso = phone_profile.iso
    return SignupDetails(
        first_name=random_first_name(),
        last_name=random_last_name(),
        password=generate_password(),
        country=_COUNTRY_EXPORT_CODES.get(iso, iso.lower()),
        postal_code=random_postal_for_country(iso),
    )


def configure_page_timeouts(page: Page) -> None:
    page.set_default_timeout(AUTH_PAGE_TIMEOUT_MS)
    page.set_default_navigation_timeout(NAVIGATION_TIMEOUT_MS)


def submit_email(page: Page, email: str) -> None:
    configure_page_timeouts(page)

    click_signup_from_home(page)

    submit_auth_email_address(page, email, timeout_ms=AUTH_PAGE_TIMEOUT_MS)

    print("Waiting for signup form after email submit...")
    wait_for_signup_password_form(page, timeout_ms=AUTH_PAGE_TIMEOUT_MS, email=email)
    human_pause(0.5, 1.0)
    ensure_not_blocked(page)
    print(f"Submitted email: {email}")


def fill_signup_form(page: Page, details: SignupDetails, *, email: str = "") -> None:
    wait_for_signup_password_form(page, timeout_ms=AUTH_PAGE_TIMEOUT_MS, email=email)
    ensure_not_blocked(page)

    human_pause(0.3, 0.5)
    fill_tm_field(page, "password-input", details.password)
    human_pause(0.2, 0.3)
    fill_tm_field(page, "firstName-input", details.first_name)
    human_pause(0.2, 0.3)
    fill_tm_field(page, "lastName-input", details.last_name)
    human_pause(0.2, 0.3)
    fill_tm_field(page, "postalCode-input", details.postal_code)

    human_pause(0.3, 0.5)
    verify_tm_field(page, "password-input", details.password)
    verify_tm_field(page, "firstName-input", details.first_name)
    verify_tm_field(page, "lastName-input", details.last_name)
    verify_tm_field(page, "postalCode-input", details.postal_code)

    check_signup_disclaimer(page)
    ensure_email_verification_step(page)
    print(f"Submitted signup form for {details.first_name} {details.last_name}")


def _otp_regex_excluding(codes: list[str]) -> str:
    """AYCD body regex that skips OTP codes Ticketmaster already rejected."""

    cleaned = [code for code in codes if code.isdigit()]
    if not cleaned:
        return r"\b\d{6}\b"
    joined = "|".join(cleaned)
    return rf"\b(?!(?:{joined})\b)\d{{6}}\b"


def _fetch_email_otp(
    aycd: AycdInboxClient,
    email: str,
    *,
    received_at: int,
    timeout_seconds: int,
    otp_regex: str,
    on_poll,
):
    created = aycd.create_mail_task(
        email=email,
        timeout_seconds=timeout_seconds,
        subject="Authentication Code",
        sender="ticketmaster",
        received_at=received_at,
        otp_regex=otp_regex,
    )
    if created.immediate is not None:
        return created.immediate
    return aycd.wait_for_mail_task(
        created.task_id,
        created.group,
        timeout_seconds=timeout_seconds,
        on_poll=on_poll,
    )


def _next_email_otp(
    page: Page,
    aycd: AycdInboxClient,
    email: str,
    rejected_codes: list[str],
    received_at: int,
    on_poll,
):
    """Look in the mailbox for a code other than the ones Ticketmaster rejected."""

    otp_regex = _otp_regex_excluding(rejected_codes)
    print(
        f"Looking through the mail for a code other than {', '.join(rejected_codes)}..."
    )
    try:
        found = _fetch_email_otp(
            aycd,
            email,
            received_at=received_at,
            timeout_seconds=min(60, OTP_WAIT_SECONDS),
            otp_regex=otp_regex,
            on_poll=on_poll,
        )
    except TimeoutError:
        found = None
    if found is not None and found.code and found.code not in rejected_codes:
        return found

    print("No other code in the current mail — requesting a new one")
    click_request_new_otp_code(page)
    found = _fetch_email_otp(
        aycd,
        email,
        received_at=int(time.time()) - 1,
        timeout_seconds=OTP_WAIT_SECONDS,
        otp_regex=otp_regex,
        on_poll=on_poll,
    )
    if found is None or not found.code or found.code in rejected_codes:
        raise RuntimeError(
            "AYCD did not return a different OTP after the previous code was rejected"
        )
    return found


def handle_email_verification(page: Page, aycd: AycdInboxClient, email: str) -> None:
    ensure_email_verification_step(page)
    ensure_not_blocked(page)

    print(f"Starting AYCD mail task for {email}...")
    received_at = int(time.time()) - 1
    created = aycd.create_mail_task(
        email=email,
        timeout_seconds=OTP_WAIT_SECONDS,
        subject="Authentication Code",
        sender="ticketmaster",
        received_at=received_at,
    )
    print(f"AYCD mail task created: {created.task_id} (group={created.group})")

    click_verify_email_button(page)

    poll = lambda: poll_page_during_otp_wait(page)

    if created.immediate is not None:
        result = created.immediate
    else:
        print(
            f"Waiting for OTP via AYCD for {email} "
            f"(up to {OTP_WAIT_SECONDS}s, watching browser)..."
        )
        result = aycd.wait_for_mail_task(
            created.task_id,
            created.group,
            timeout_seconds=OTP_WAIT_SECONDS,
            on_poll=poll,
        )

    if not result.code:
        raise RuntimeError(f"AYCD did not return an OTP code: {result.raw}")

    rejected_codes: list[str] = []
    for code_try in range(1, 4):
        print(f"Received email OTP: {result.code}")
        poll_page_during_otp_wait(page)
        try:
            submit_otp_code(page, result.code, "Verify Your Email", is_email=True)
            return
        except InvalidOtpCode:
            rejected_codes.append(result.code)
            print(
                f"Email OTP {result.code} was rejected "
                f"({code_try}/3) — looking for a different code in the mail"
            )
        if code_try >= 3:
            break
        result = _next_email_otp(
            page,
            aycd,
            email,
            rejected_codes,
            received_at,
            poll,
        )
        if result.code in rejected_codes:
            raise RuntimeError(
                f"AYCD returned rejected OTP {result.code} again"
            )
    raise RuntimeError(
        f"Ticketmaster rejected the email OTP codes: {', '.join(rejected_codes)}"
    )


def _sync_export_country(details: SignupDetails, phone_sms: PhoneSmsClient) -> None:
    """CSV country follows the number that was actually used. ZIP stays US."""

    try:
        profile = phone_sms.last_country_profile()
    except Exception:
        return
    details.country = _COUNTRY_EXPORT_CODES.get(profile.iso, profile.iso.lower())


def handle_phone_verification(page: Page, phone_sms: PhoneSmsClient) -> str:
    click_add_phone_button(page)
    entry_mode = "other"

    for attempt in range(1, PHONE_NUMBER_MAX_ROTATIONS + 1):
        activation = phone_sms.buy_number(
            on_poll=lambda: poll_page_during_otp_wait(page),
        )
        provider_left = activation_seconds_left(getattr(activation, "expires_at", 0.0) or 0.0)
        if activation.expires_at > 0 and provider_left < sms_min_remaining_seconds():
            print(
                f"Number {activation.phone_number} has "
                f"{format_activation_time_left(provider_left)} left "
                "(under 5:00) — cancelling and requesting a new number"
            )
            phone_sms.cancel(activation.activation_id)
            continue
        phone_profile = phone_sms.country_profile_for(getattr(activation, "country", "") or "")
        try:
            dial_code, local_number = parse_ticketmaster_phone(
                activation.phone_number, phone_profile
            )
        except Exception as exc:
            print(
                f"Phone number could not be parsed "
                f"({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}): {exc} — rotating..."
            )
            phone_sms.cancel(activation.activation_id)
            phone_sms.add_phone_exception(
                activation.phone_number, phone_profile.smsbower_country
            )
            human_pause(0.5, 1.0)
            continue

        phone_profile = replace(phone_profile, national_length=len(local_number))
        print(
            f"Phone country ({phone_sms.provider_name}) id={phone_profile.smsbower_country}: "
            f"{phone_profile.tm_country_name} (+{phone_profile.dial_code})"
        )
        print(
            f"Bought {phone_profile.tm_country_name} number from {phone_sms.provider_name}: "
            f"+{dial_code}{local_number} (attempt {attempt}/{PHONE_NUMBER_MAX_ROTATIONS})"
        )

        same_number_tries = 0
        while same_number_tries < 3:
            same_number_tries += 1
            try:
                if attempt > 1 or same_number_tries > 1:
                    reset_phone_entry_for_next_attempt(page, entry_mode=entry_mode)
                entry_mode = configure_ticketmaster_phone_country(
                    page,
                    country_name=phone_profile.tm_country_name,
                    dial_code=phone_profile.dial_code,
                    iso=phone_profile.iso,
                )
                fill_ticketmaster_phone_number(
                    page,
                    dial_code=dial_code,
                    national_number=local_number,
                    mode=entry_mode,
                    expected_digits=phone_profile.national_length,
                    iso=phone_profile.iso,
                )
            except PhoneVerifyRetry:
                raise
            except Exception as exc:
                if dismiss_phone_try_later_dialog(page):
                    print(
                        "Something went wrong — clicked OK, trying phone verification again"
                    )
                    human_pause(0.6, 1.2)
                    continue
                print(
                    f"Phone entry failed ({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}): {exc} — rotating..."
                )
                phone_sms.cancel(activation.activation_id)
                phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
                human_pause(0.5, 1.0)
                break

            print(f"Entered phone number: +{dial_code}{local_number}")
            human_pause(0.35, 0.55)

            ensure_ticketmaster_phone_number(
                page,
                dial_code=dial_code,
                national_number=local_number,
                mode=entry_mode,
                expected_digits=phone_profile.national_length,
                iso=phone_profile.iso,
            )
            check_phone_marketing_consent(page)
            ensure_ticketmaster_phone_number(
                page,
                dial_code=dial_code,
                national_number=local_number,
                mode=entry_mode,
                expected_digits=phone_profile.national_length,
                iso=phone_profile.iso,
            )
            try:
                click_phone_add_number_button(page)
            except PhoneVerifyRetry as exc:
                print(f"{exc} — trying phone verification again with the same number")
                human_pause(0.6, 1.2)
                continue
            except PhoneNumberUnsupportedError as exc:
                print(
                    f"{exc} ({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}) "
                    "— cancelling this number and requesting a new one"
                )
                phone_sms.cancel(activation.activation_id)
                phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
                human_pause(0.5, 1.0)
                break
            print("Clicked Add Number - waiting for phone OTP modal...")

            human_pause(0.8, 1.2)
            if is_phone_number_unsupported(page):
                print(
                    f"Phone number rejected ({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}) — rotating..."
                )
                phone_sms.cancel(activation.activation_id)
                phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
                human_pause(0.5, 1.0)
                break

            try:
                try:
                    wait_for_phone_otp_modal(page, timeout_ms=AUTH_PAGE_TIMEOUT_MS)
                except PhoneVerifyRetry as exc:
                    print(f"{exc} — trying phone verification again with the same number")
                    human_pause(0.6, 1.2)
                    continue
                except PhoneNumberUnsupportedError as exc:
                    print(
                        f"{exc} ({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}) "
                        "— cancelling this number and requesting a new one"
                    )
                    phone_sms.cancel(activation.activation_id)
                    phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
                    human_pause(0.5, 1.0)
                    break

                print(
                    f"Waiting for phone OTP via {phone_sms.provider_name} (up to {SMS_OTP_WAIT_SECONDS}s)..."
                )
                rejected_sms: set[str] = set()
                sms_code = ""
                for code_try in range(1, 4):
                    sms_code = phone_sms.wait_for_sms(
                        activation.activation_id,
                        timeout_seconds=SMS_OTP_WAIT_SECONDS,
                        on_poll=lambda: poll_page_during_otp_wait(page),
                        expires_at=activation.expires_at,
                        ignore_codes=rejected_sms,
                    )
                    poll_page_during_otp_wait(page)
                    try:
                        submit_otp_code(page, sms_code, "Verify Your Phone", is_email=False)
                        break
                    except InvalidOtpCode:
                        rejected_sms.add(sms_code)
                        if code_try >= 3:
                            raise RuntimeError(
                                f"Ticketmaster rejected SMS codes: {', '.join(rejected_sms)}"
                            ) from None
                        print(
                            f"SMS OTP {sms_code} was rejected ({code_try}/3) "
                            "— waiting for a different code"
                        )
                        requester = getattr(phone_sms, "request_another_sms", None)
                        if callable(requester):
                            try:
                                requester(activation.activation_id)
                            except Exception as exc:
                                print(f"  Could not ask for another SMS yet: {exc}")
                        click_request_new_otp_code(page)
                wait_for_confirm_account_step(page)
            except SessionInterruptedRestart:
                print(
                    "Phone session interrupted — cancelling this number and restarting the browser"
                )
                phone_sms.cancel(activation.activation_id)
                raise
            except SmsActivationLowTime as exc:
                print(f"{exc} — requesting a new number")
                break
            except PhoneNumberUnsupportedError as exc:
                print(
                    f"{exc} ({attempt}/{PHONE_NUMBER_MAX_ROTATIONS}) "
                    "— cancelling this number and requesting a new one"
                )
                phone_sms.cancel(activation.activation_id)
                phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
                human_pause(0.5, 1.0)
                break
            except PhoneVerifyRetry as exc:
                print(f"{exc} — trying phone verification again with the same number")
                human_pause(0.6, 1.2)
                continue
            print("Email and phone verification accepted — continuing signup")

            phone_sms.complete(activation.activation_id)
            return f"+{dial_code}{local_number}"
        else:
            print(
                "Phone verification still failing after the Attention dialog. "
                "Cancelling this number and requesting a new one."
            )
            phone_sms.cancel(activation.activation_id)
            phone_sms.add_phone_exception(local_number, phone_profile.smsbower_country)
            human_pause(0.5, 1.0)
        continue

    raise PhoneNumberSessionRestart(
        "Could not find an accepted phone number after "
        f"{PHONE_NUMBER_MAX_ROTATIONS} rotation(s) — restarting session"
    )


def _is_my_ticketmaster_url(page: Page) -> bool:
    try:
        return "my.ticketmaster.com" in (page.url or "").lower()
    except Exception:
        return False


def is_post_signup_export_landing(page: Page) -> bool:
    """True when signup finished on a page where we should export session cookies."""

    if POST_SIGNUP_HOME_RE.match(page.url or ""):
        return True
    if _is_my_ticketmaster_url(page):
        return True
    return is_session_export_ready_page(page)


def wait_for_post_signup_home(
    page: Page,
    context: BrowserContext | None = None,
) -> None:
    """Wait until OAuth exchange finishes and lands on TM home or export-ready auth page."""

    deadline = time.time() + (POST_SIGNUP_WAIT_MS / 1000)
    last_log = 0.0
    portal_recovery_attempted = False

    while time.time() < deadline:
        if is_tm_portal_content_error(page):
            if not portal_recovery_attempted:
                portal_recovery_attempted = True
                print("Detected my.ticketmaster.com content error during post-signup wait...")
                recover_tm_session_for_export(page)
                continue
            if _is_my_ticketmaster_url(page):
                print(
                    "my.ticketmaster.com still shows content error (503) — "
                    "proceeding to export session cookies"
                )
                return

        if _is_my_ticketmaster_url(page) and not is_tm_portal_content_error(page):
            print("Post-signup session established on my.ticketmaster.com")
            return

        if is_passkey_prompt_page(page):
            if dismiss_passkey_prompt_if_present(page, max_attempts=2):
                human_pause(0.8, 1.4)
                continue

        if POST_SIGNUP_HOME_RE.match(page.url):
            page.wait_for_load_state("domcontentloaded")
            print("Post-signup session established on ticketmaster.com")
            return

        if _is_post_signup_account_portal(page):
            print("Post-signup session established on my.ticketmaster.com")
            return

        if is_session_export_ready_page(page):
            print("Post-signup auth landing page detected — session ready for export")
            return

        now = time.time()
        if now - last_log >= 15:
            remaining = max(0, int(deadline - now))
            print(f"  Waiting for post-signup navigation ({remaining}s left)...")
            last_log = now

        try:
            page.wait_for_url(
                re.compile(r"https://identity\.ticketmaster\.com/exchange"),
                timeout=2_000,
            )
        except Exception:
            pass

        time.sleep(0.5)

    if is_tm_portal_content_error(page):
        recover_tm_session_for_export(page)

    if is_post_signup_export_landing(page):
        if is_tm_portal_content_error(page):
            print(
                "Post-signup on my.ticketmaster.com content error (503) — "
                "continuing to export cookies"
            )
        return

    if context is not None and _export_auth_cookies_ready(context):
        print(
            "Post-signup navigation timed out on "
            f"{page.url}, but auth cookies are present — continuing to export"
        )
        return

    if is_tm_portal_content_error(page) or _is_my_ticketmaster_url(page):
        print(
            f"Post-signup navigation timed out on {page.url} — "
            "exporting cookies from current session anyway"
        )
        return

    raise OtpValidationRestart(
        f"Timed out waiting for post-signup navigation (last URL: {page.url})"
    )


def _export_auth_cookies_ready(context: BrowserContext) -> bool:
    cookie_map = build_export_cookie_map(get_ticketmaster_cookies(context))
    return bool(extract_sortc_token(cookie_map) or extract_sotc_token(cookie_map))


def _is_post_signup_account_portal(page: Page) -> bool:
    try:
        url = (page.url or "").lower()
    except Exception:
        return False
    return "my.ticketmaster.com" in url and not is_tm_portal_content_error(page)


def confirm_account(page: Page, context: BrowserContext | None = None) -> None:
    wait_for_confirm_account_step(page)
    ensure_not_blocked(page)

    if is_passkey_prompt_page(page):
        print("Passkey prompt after verification — dismissing...")
        dismiss_passkey_prompt_if_present(page, max_attempts=4)

    if is_session_export_ready_page(page) and is_passkey_prompt_page(page):
        print(
            "Passkey prompt still visible — continuing anyway "
            "(export may use current auth session)"
        )
        return

    if is_session_export_ready_page(page):
        print("Post-signup auth landing page detected — skipping confirm Done step")
        return

    if is_tm_portal_content_error(page):
        recover_tm_session_for_export(page)
        if context is not None and _export_auth_cookies_ready(context):
            return

    done_btn = human_button(page, "Done")
    expect(done_btn).to_be_visible(timeout=15_000)
    human_pause(0.2, 0.3)
    human_click(done_btn)
    print("Clicked Done - waiting for identity exchange...")

    wait_for_post_signup_home(page, context)


def format_phone_digits(phone_number: str) -> str:
    return re.sub(r"\D", "", phone_number)


def is_ticketmaster_cookie_domain(domain: str) -> bool:
    normalized = domain.lstrip(".").lower()
    return normalized == "ticketmaster.com" or normalized.endswith(".ticketmaster.com")


def normalize_export_domain(domain: str) -> str:
    normalized = domain.lstrip(".").lower()
    if normalized == "www.ticketmaster.com":
        return "ticketmaster.com"
    return normalized


def get_ticketmaster_cookies(context: BrowserContext) -> list[dict]:
    """Collect Ticketmaster cookies (excludes google.com, live-harbor, etc.)."""

    merged: dict[tuple[str, str], dict] = {}

    def ingest(batch: list[dict]) -> None:
        for cookie in batch:
            domain = normalize_export_domain(str(cookie.get("domain", "")))
            if not is_ticketmaster_cookie_domain(domain):
                continue
            name = str(cookie.get("name", ""))
            if not name:
                continue
            merged[(domain, name)] = cookie

    ingest(context.cookies(urls=TM_COOKIE_URLS))
    ingest(context.cookies())
    return list(merged.values())


def build_export_cookie_map(cookies: list[dict]) -> dict[tuple[str, str], str]:
    mapped: dict[tuple[str, str], str] = {}

    for cookie in cookies:
        domain = normalize_export_domain(str(cookie.get("domain", "")))
        if not is_ticketmaster_cookie_domain(domain):
            continue

        name = str(cookie.get("name", ""))
        value = str(cookie.get("value", ""))
        if not name or not value:
            continue

        mapped[(domain, name)] = value

    return mapped


def extract_sortc_token(cookie_map: dict[tuple[str, str], str]) -> str:
    direct = cookie_map.get(("ticketmaster.com", "SORTC"))
    if direct:
        return direct
    for (_domain, name), value in cookie_map.items():
        if name == "SORTC" and value:
            return value
    return ""


def extract_sotc_token(cookie_map: dict[tuple[str, str], str]) -> str:
    direct = cookie_map.get(("ticketmaster.com", "SOTC"))
    if direct:
        return direct
    for (_domain, name), value in cookie_map.items():
        if name == "SOTC" and value:
            return value
    return ""


def lookup_export_cookie_value(
    cookie_map: dict[tuple[str, str], str],
    export_domain: str,
    name: str,
) -> str:
    value = cookie_map.get((export_domain, name))
    if value:
        return value

    if export_domain == "ticketmaster.com" and name == "SORTC":
        return extract_sortc_token(cookie_map)
    if export_domain == "ticketmaster.com" and name == "SOTC":
        return extract_sotc_token(cookie_map)
    return ""


def format_sortc_export_column(sortc_token: str) -> str:
    """Dedicated SORTC column: SORTC=<token> (same token as in COOKIES)."""

    token = (sortc_token or "").strip()
    if not token:
        return ""
    if token.upper().startswith("SORTC="):
        return token
    return f"SORTC={token}"


def export_session_tokens_ready(cookie_map: dict[tuple[str, str], str]) -> bool:
    return bool(extract_sortc_token(cookie_map) and extract_sotc_token(cookie_map))


def missing_export_spec_pairs(
    cookie_map: dict[tuple[str, str], str],
) -> list[tuple[str, str]]:
    return [
        (export_domain, name)
        for export_domain, name in EXPORT_COOKIE_SPECS
        if not lookup_export_cookie_value(cookie_map, export_domain, name)
    ]


def _visit_export_cookie_origin(page: Page, url: str, label: str) -> None:
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=min(NAVIGATION_TIMEOUT_MS, 45_000))
        human_pause(1.0, 1.8)
    except Exception as exc:
        print(f"  Cookie visit warning ({label}): {exc}")
        raise


def refresh_export_session_cookies(context: BrowserContext, page: Page) -> list[dict]:
    """Collect Ticketmaster cookies for CSV export without extra hops that crash CloakBrowser."""

    try:
        cookies = get_ticketmaster_cookies(context)
    except Exception as exc:
        print(f"Cookie snapshot failed: {exc}")
        return []

    before_map = build_export_cookie_map(cookies)
    if export_session_tokens_ready(before_map):
        missing = missing_export_spec_pairs(before_map)
        print(
            f"SOTC/SORTC present — exporting current session cookies "
            f"({len(EXPORT_COOKIE_SPECS) - len(missing)}/{len(EXPORT_COOKIE_SPECS)} model keys)"
        )
        return cookies

    print("SOTC/SORTC missing — visiting ticketmaster.com once for session cookies...")
    try:
        _visit_export_cookie_origin(
            page,
            "https://www.ticketmaster.com/",
            "ticketmaster.com",
        )
        cookies = get_ticketmaster_cookies(context)
    except Exception as exc:
        print(f"Cookie refresh navigation failed ({exc}) — using snapshot")

    missing = missing_export_spec_pairs(build_export_cookie_map(cookies))
    if missing:
        print(
            f"Warning: export missing {len(missing)}/{len(EXPORT_COOKIE_SPECS)} "
            f"model cookie(s): "
            f"{', '.join(f'{d}|{n}' for d, n in missing[:8])}"
            + (" ..." if len(missing) > 8 else "")
        )
    return cookies


def format_cookies(cookies: list[dict]) -> tuple[str, str]:
    cookie_map = build_export_cookie_map(cookies)
    parts: list[str] = []
    sortc_value = extract_sortc_token(cookie_map)

    for export_domain, name in EXPORT_COOKIE_SPECS:
        value = lookup_export_cookie_value(cookie_map, export_domain, name)
        if not value:
            continue
        parts.append(f"{export_domain}|{name}={value}")

    missing = missing_export_spec_pairs(cookie_map)
    if missing:
        print(
            "Warning: COOKIES string omitting "
            f"{len(missing)} unset segment(s) "
            f"({len(parts)}/{len(EXPORT_COOKIE_SPECS)} present)"
        )

    return "; ".join(parts), format_sortc_export_column(sortc_value)


def settle_ticketmaster_session(page: Page) -> bool:
    """Prepare cookies for export without navigating away from passkey/WELCOME.

    Returns True when export should use the current page as-is (passkey/WELCOME).
    """

    if is_tm_portal_content_error(page):
        recover_tm_session_for_export(page)

    if is_passkey_prompt_page(page):
        dismiss_passkey_prompt_if_present(page, max_attempts=3)

    if is_session_export_ready_page(page):
        if is_passkey_prompt_page(page):
            print(
                "Passkey prompt detected — export from this page and close "
                "(no auth links, no new tabs)"
            )
        else:
            print(
                "WELCOME page detected — export from this page and close "
                "(no auth links, no new tabs)"
            )
        return True

    if not POST_SIGNUP_HOME_RE.match(page.url):
        wait_for_post_signup_home(page)

    if is_session_export_ready_page(page):
        print(
            "Post-signup landing page detected — export from current page, "
            "skipping extra navigation"
        )
        return True

    try:
        page.goto(
            "https://www.ticketmaster.com/",
            wait_until="domcontentloaded",
            timeout=NAVIGATION_TIMEOUT_MS,
        )
        human_pause(1.0, 1.5)
        ensure_not_blocked(page)
    except Exception as exc:
        print(f"Session settle warning (ticketmaster.com): {exc}")

    return False


def write_export_row(
    email: str,
    details: SignupDetails,
    phone_number: str,
    proxy_line: str,
    tm_cookies: list[dict],
) -> None:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    phone_digits = format_phone_digits(phone_number)
    cookies_str, sortc = format_cookies(tm_cookies)
    sortc_token = extract_sortc_token(build_export_cookie_map(tm_cookies))
    if sortc_token and not sortc:
        sortc = format_sortc_export_column(sortc_token)

    if not sortc:
        print("Warning: SORTC cookie not found in exported Ticketmaster cookies")
    else:
        print(f"Exported SORTC column ({len(sortc)} chars)")

    row = {
        "EMAIL": email,
        "PASSWORD": details.password,
        "ZIP": details.postal_code,
        "FIRSTNAME": details.first_name,
        "LASTNAME": details.last_name,
        "NUMBER": phone_digits,
        "PHONE": phone_digits,
        "COUNTRY": details.country.lower(),
        "PROXY": proxy_line,
        "STATUS": "",
        "DATE": datetime.now().strftime("%d/%m/%Y"),
        "COOKIES": cookies_str,
        "PROFILE STATUS": "",
        "SORTC": sortc,
    }

    with interprocess_lock(EXPORT_LOCK_FILE):
        write_header = not EXPORT_FILE.exists() or EXPORT_FILE.stat().st_size == 0
        with EXPORT_FILE.open("a", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(
                file,
                fieldnames=CSV_HEADERS,
                quoting=csv.QUOTE_MINIMAL,
                lineterminator="\n",
            )
            if write_header:
                writer.writeheader()
            writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})


def export_account(
    email: str,
    details: SignupDetails,
    phone_number: str,
    proxy_line: str,
    context: BrowserContext,
    page: Page,
    *,
    skip_navigation: bool = False,
    fallback_cookies: list[dict] | None = None,
) -> None:
    snapshot: list[dict] = list(fallback_cookies or [])
    try:
        snapshot = get_ticketmaster_cookies(context) or snapshot
    except Exception as exc:
        print(f"Live cookie read failed ({exc}) — using snapshot if available")

    try:
        if is_tm_portal_content_error(page):
            print(
                "Exporting account while on my.ticketmaster.com content error page "
                "(503 — cookies still written to CSV)"
            )
    except Exception:
        pass

    tm_cookies = snapshot
    if not skip_navigation:
        try:
            tm_cookies = refresh_export_session_cookies(context, page) or snapshot
        except Exception as exc:
            print(f"Cookie refresh failed ({exc}) — exporting snapshot cookies")
            tm_cookies = snapshot

    if not tm_cookies:
        tm_cookies = snapshot

    write_export_row(email, details, phone_number, proxy_line, tm_cookies)


def run_signup_flow(
    page: Page,
    context: BrowserContext,
    email: str,
    details: SignupDetails,
    aycd: AycdInboxClient,
    phone_sms: PhoneSmsClient,
) -> str:
    submit_email(page, email)
    fill_signup_form(page, details, email=email)
    handle_email_verification(page, aycd, email)
    return handle_phone_verification(page, phone_sms)


def create_account(
    email: str,
    aycd: AycdInboxClient,
    phone_sms: PhoneSmsClient,
    *,
    max_browser_restarts: int = 5,
    worker_slot: int = 0,
    proxy_slot: int | None = None,
) -> bool:
    details = build_signup_details(phone_sms.country_profile())
    session = None
    slot = proxy_slot if proxy_slot is not None else worker_slot
    slot_wait_attempts = 0
    session_restarts = 0
    max_slot_wait_attempts = max(max_browser_restarts + 1, 1)

    if is_email_marked_used(email):
        print(f"Skipping {email} — already marked used in customsinformation.csv")
        return False

    try:
        while slot_wait_attempts < max_slot_wait_attempts:
            proxy_lines = load_proxy_lines()
            if proxy_lines:
                proxy_index = slot % len(proxy_lines)
                proxy, proxy_line = load_proxy_by_index(proxy_index)
            else:
                proxy_index = 0
                proxy, proxy_line = None, ""
            proxy = personalize_proxy_settings(proxy)
            if proxy:
                print(
                    f"Using proxy index {proxy_index} for {email}: {proxy['server']}"
                )
            else:
                print("Launching without proxy (proxy.txt empty)")

            try:
                with browser_session_slot():
                    with browser_launch_gate():
                        session = create_browser_session(
                            proxy=proxy,
                            country=details.country,
                        )
                    page = session.page
                    context = session.context
                    configure_page_timeouts(page)

                    try:
                        phone_number = run_signup_flow(
                            page, context, email, details, aycd, phone_sms
                        )
                        _sync_export_country(details, phone_sms)
                        cookie_snapshot: list[dict] = []
                        try:
                            cookie_snapshot = get_ticketmaster_cookies(context)
                        except Exception as snap_exc:
                            print(f"Pre-export cookie snapshot failed: {snap_exc}")

                        try:
                            confirm_account(page, context)
                            complete_post_signup_navigation(page)
                            settle_ticketmaster_session(page)
                        except (OtpValidationRestart, TimeoutError) as post_exc:
                            print(
                                f"Post-signup navigation did not finish cleanly ({post_exc}) — "
                                "exporting with cookies already captured"
                            )
                        except Exception as post_exc:
                            print(
                                f"Post-signup step warning: {post_exc} — "
                                "exporting with cookies already captured"
                            )

                        try:
                            export_account(
                                email,
                                details,
                                phone_number,
                                proxy_line,
                                context,
                                page,
                                skip_navigation=False,
                                fallback_cookies=cookie_snapshot,
                            )
                        except Exception as export_exc:
                            print(
                                f"Live export failed ({export_exc}) — writing snapshot row"
                            )
                            write_export_row(
                                email,
                                details,
                                phone_number,
                                proxy_line,
                                cookie_snapshot,
                            )

                        cookies_ready = False
                        try:
                            cookies_ready = _export_auth_cookies_ready(context)
                        except Exception:
                            cookies_ready = bool(
                                extract_sortc_token(
                                    build_export_cookie_map(cookie_snapshot)
                                )
                            )
                        if cookies_ready:
                            mark_email_used(email)
                        else:
                            mark_email_used(
                                email,
                                notes="account created; verify export cookies",
                            )
                            print(
                                "Warning: exported with incomplete auth cookies — "
                                "row marked used after successful signup"
                            )
                        print(f"Exported account to {EXPORT_FILE}")
                        notify_account_created(
                            email=email,
                            password=details.password,
                            first_name=details.first_name,
                            last_name=details.last_name,
                            postal_code=details.postal_code,
                            country=details.country,
                            phone=phone_number,
                            proxy_line=proxy_line,
                        )
                        print(f"Email: {email}")
                        print(f"Phone: {phone_number}")
                        print(f"Password: {details.password}")
                        human_pause(3.0, 5.0)
                        destroy_browser_session(session, skip_storage_clear=True)
                        session = None
                        print("Browser closed.")
                        return True
                    except SessionInterruptedRestart as exc:
                        print(exc)
                        session_restarts += 1
                        print(
                            f"Closing browser and starting signup over for {email} "
                            f"(restart {session_restarts}/{max_browser_restarts})"
                        )
                        destroy_browser_session(session, fast=True)
                        session = None
                        if session_restarts >= max_browser_restarts:
                            print(
                                f"Stopped signup for {email} after "
                                f"{max_browser_restarts} interrupted session(s). "
                                "Email left unused."
                            )
                            return False
                        slot += 1
                        human_pause(1.0, 2.0)
                        continue
                    except ExistingTicketmasterAccountError as exc:
                        print(exc)
                        mark_email_used(email, notes="used")
                        destroy_browser_session(session, fast=True)
                        session = None
                        return True
                    except (
                        BrowsingPausedRestart,
                        OtpValidationRestart,
                        PhoneNumberSessionRestart,
                        TimeoutError,
                    ) as exc:
                        print(str(exc))
                        if isinstance(exc, BrowsingPausedRestart):
                            print(
                                "Bot detection — closing browser, removing proxy, "
                                "leaving this email unused for a later run."
                            )
                        elif isinstance(exc, PhoneNumberSessionRestart):
                            print(
                                "Phone session failed — closing browser, removing proxy, "
                                "leaving this email unused for a later run."
                            )
                        else:
                            print(
                                "Signup stalled — closing browser, removing proxy, "
                                "leaving this email unused for a later run."
                            )
                        burn_failed_proxy(proxy_line)
                        destroy_browser_session(session, fast=True)
                        session = None
                        print(
                            f"Stopped signup for {email}. Pool will continue with the "
                            "next email, a new browser, and the next proxy in proxy.txt."
                        )
                        return False
            except (BrowserSlotWaitTimeout, TimeoutError) as slot_exc:
                lock_busy = (
                    isinstance(slot_exc, TimeoutError)
                    and not isinstance(slot_exc, BrowserSlotWaitTimeout)
                    and "acquiring lock" in str(slot_exc)
                )
                if isinstance(slot_exc, TimeoutError) and not isinstance(slot_exc, BrowserSlotWaitTimeout) and not lock_busy:
                    raise
                print(slot_exc)
                slot_wait_attempts += 1
                if slot_wait_attempts >= max_slot_wait_attempts:
                    raise RuntimeError(
                        "Could not acquire a browser slot; "
                        "lower concurrent_browsers or raise max_active_browser_sessions"
                    ) from slot_exc
                human_pause(2.0, 5.0)
                continue
            break
    except Exception as exc:
        print(f"Account creation failed for {email}: {exc}")
        if session is not None:
            try:
                print(f"Closing browser after failure (URL: {session.page.url})")
            except Exception:
                print("Closing browser after failure")
            destroy_browser_session(session, fast=True)
            session = None
        return False
    finally:
        if session is not None:
            print("Force-closing leftover browser session (worker cleanup)...")
            destroy_browser_session(session, fast=True)

    return False


def sustained_pool_worker(
    worker_id: int,
    email_queue: mp.Queue,
    *,
    pool_size: int,
    max_browser_restarts: int,
) -> None:
    """Keep this process alive, pull emails from the queue, and always tear down browsers."""

    load_dotenv()
    config = load_config()
    apply_config(config)
    reconcile_browser_slots()
    ensure_cloakbrowser_ready()
    stagger_worker_start(worker_id, f"pool-worker-{worker_id}")

    aycd = create_aycd_client()
    phone_sms = create_phone_sms_client(provider_ids=SMS_PROVIDER_IDS)
    jobs_started = 0
    try:
        print(
            f"\n=== Browser pool worker {worker_id + 1}/{pool_size} started "
            f"(pid={os.getpid()}) ==="
        )
        while True:
            email = email_queue.get()
            if email is None:
                break

            if is_email_marked_used(email):
                print(
                    f"Pool worker {worker_id}: skipping {email} "
                    "(already marked used in customsinformation.csv)"
                )
                continue

            proxy_slot = worker_id + jobs_started * pool_size
            jobs_started += 1

            print(
                f"\n--- Pool worker {worker_id}: account {jobs_started} for {email} "
                f"(proxy_slot={proxy_slot}) ---"
            )
            try:
                ok = create_account(
                    email,
                    aycd=aycd,
                    phone_sms=phone_sms,
                    max_browser_restarts=max_browser_restarts,
                    worker_slot=worker_id,
                    proxy_slot=proxy_slot,
                )
                if ok:
                    print(f"Pool worker {worker_id}: success for {email}")
                else:
                    if is_email_marked_used(email):
                        print(f"Pool worker {worker_id}: finished for {email}")
                    else:
                        print(
                            f"Pool worker {worker_id}: stopped for {email} "
                            "(email still unused — next job uses next email/proxy)"
                        )
            except Exception as exc:
                print(
                    f"Pool worker {worker_id}: error on {email} ({exc}) — "
                    "continuing with next email"
                )
            finally:
                human_pause(3.0, 5.0)

        print(f"=== Browser pool worker {worker_id} finished ({jobs_started} job(s)) ===")
    finally:
        aycd.close()
        phone_sms.close()
        kill_browser_child_processes()
        reconcile_browser_slots()


def _force_stop_pool_workers(
    processes: list[mp.Process],
    email_queue: mp.Queue,
    *,
    workers: int,
    join_timeout_seconds: int,
) -> None:
    for _ in range(workers):
        try:
            email_queue.put_nowait(None)
        except Exception:
            pass

    for process in processes:
        if not process.is_alive():
            continue
        process.join(timeout=join_timeout_seconds)
        if process.is_alive():
            print(
                f"Worker {process.name} (pid={process.pid}) did not exit in "
                f"{join_timeout_seconds}s — force stopping..."
            )
            shutdown_process_tree(process.pid)


def run_sustained_browser_pool(
    emails: list[str],
    *,
    workers: int,
    max_browser_restarts: int,
    worker_shutdown_timeout_seconds: int,
    worker_spawn_stagger_seconds: float,
) -> None:
    """Maintain ``workers`` long-lived processes until every email is processed."""

    mp_ctx = mp.get_context("spawn")
    email_queue: mp.Queue = mp_ctx.Queue()
    for email in emails:
        email_queue.put(email)
    for _ in range(workers):
        email_queue.put(None)

    processes: list[mp.Process] = []
    for worker_id in range(workers):
        if worker_id > 0 and worker_spawn_stagger_seconds > 0:
            pause = worker_spawn_stagger_seconds + random.uniform(0.0, 2.5)
            print(
                f"Staggering pool worker {worker_id + 1}/{workers} process start "
                f"by {pause:.1f}s..."
            )
            time.sleep(pause)
        process = mp_ctx.Process(
            target=sustained_pool_worker,
            args=(worker_id, email_queue),
            kwargs={
                "pool_size": workers,
                "max_browser_restarts": max_browser_restarts,
            },
            name=f"tm-pool-{worker_id}",
        )
        process.start()
        processes.append(process)

    def _on_interrupt(_signum: int, _frame: object) -> None:
        print("\nInterrupt received — stopping browser pool workers...")
        _force_stop_pool_workers(
            processes,
            email_queue,
            workers=workers,
            join_timeout_seconds=worker_shutdown_timeout_seconds,
        )
        raise KeyboardInterrupt

    previous_handler = signal.signal(signal.SIGINT, _on_interrupt)
    print(
        "Browser pool running until all queued emails are processed "
        f"(Ctrl+C allows up to {worker_shutdown_timeout_seconds}s per worker to exit)..."
    )
    try:
        for process in processes:
            process.join()
    except KeyboardInterrupt:
        _force_stop_pool_workers(
            processes,
            email_queue,
            workers=workers,
            join_timeout_seconds=worker_shutdown_timeout_seconds,
        )
        raise
    finally:
        signal.signal(signal.SIGINT, previous_handler)
        if any(process.is_alive() for process in processes):
            print("Some pool workers still running — requesting graceful stop...")
            _force_stop_pool_workers(
                processes,
                email_queue,
                workers=workers,
                join_timeout_seconds=worker_shutdown_timeout_seconds,
            )

    print("Browser pool shut down — all worker processes exited.")


def process_email_worker(
    worker_slot: int,
    email: str,
    max_browser_restarts: int,
) -> bool:
    """Run one signup in an isolated process (Playwright sync API is not thread-safe)."""

    load_dotenv()
    config = load_config()
    apply_config(config)
    reconcile_browser_slots()
    ensure_cloakbrowser_ready()
    stagger_worker_start(worker_slot, email)

    aycd = create_aycd_client()
    phone_sms = create_phone_sms_client(provider_ids=SMS_PROVIDER_IDS)
    try:
        print(
            f"\n--- Creating account for {email} "
            f"(pid={os.getpid()}, worker_slot={worker_slot}) ---"
        )
        return create_account(
            email,
            aycd=aycd,
            phone_sms=phone_sms,
            max_browser_restarts=max_browser_restarts,
            worker_slot=worker_slot,
        )
    except Exception as exc:
        print(f"Skipped {email} due to error (still unused in CSV): {exc}")
        return False
    finally:
        aycd.close()
        phone_sms.close()
        kill_browser_child_processes()


def process_email(
    email: str,
    *,
    max_browser_restarts: int = 5,
    worker_slot: int = 0,
) -> bool:
    aycd = create_aycd_client()
    phone_sms = create_phone_sms_client(provider_ids=SMS_PROVIDER_IDS)
    try:
        print(f"\n--- Creating account for {email} ---")
        return create_account(
            email,
            aycd=aycd,
            phone_sms=phone_sms,
            max_browser_restarts=max_browser_restarts,
            worker_slot=worker_slot,
        )
    except Exception as exc:
        print(f"Skipped {email} due to error (still unused in CSV): {exc}")
        return False
    finally:
        aycd.close()
        phone_sms.close()
        kill_browser_child_processes()


def apply_config(config: AppConfig) -> None:
    global AUTH_PAGE_TIMEOUT_MS, OTP_WAIT_SECONDS, SMS_OTP_WAIT_SECONDS
    global PHONE_NUMBER_MAX_ROTATIONS, SMS_PROVIDER_IDS

    AUTH_PAGE_TIMEOUT_MS = config.auth_page_timeout_seconds * 1000
    OTP_WAIT_SECONDS = config.otp_wait_seconds
    SMS_OTP_WAIT_SECONDS = config.sms_otp_wait_seconds
    PHONE_NUMBER_MAX_ROTATIONS = config.phone_number_max_rotations
    SMS_PROVIDER_IDS = resolve_sms_provider_ids(config_ids=config.sms_provider_ids)

    if not os.getenv("SMS_PROVIDER", "").strip() and config.sms_provider:
        os.environ["SMS_PROVIDER"] = config.sms_provider
    if not os.getenv("SMS_GET_NUMBER_RETRY_SECONDS", "").strip():
        os.environ["SMS_GET_NUMBER_RETRY_SECONDS"] = str(config.sms_get_number_retry_seconds)
    if not os.getenv("SMS_GET_NUMBER_MAX_WAIT_SECONDS", "").strip():
        os.environ["SMS_GET_NUMBER_MAX_WAIT_SECONDS"] = str(config.sms_get_number_max_wait_seconds)
    os.environ["SMS_WAIT_UNTIL_NUMBER"] = "1" if config.sms_wait_until_number else "0"
    if (
        config.sms_countries
        and not os.getenv("SMS_COUNTRIES", "").strip()
        and not os.getenv("SMSBOWER_COUNTRIES", "").strip()
        and not os.getenv("GRIZZLY_COUNTRIES", "").strip()
    ):
        os.environ["SMS_COUNTRIES"] = ",".join(config.sms_countries)

    configure_step_delays(config.delay_min_seconds, config.delay_max_seconds)
    configure_home_scroll_before_signup(
        enabled=config.scroll_ticketmaster_home_before_signup,
        min_seconds=config.scroll_before_signup_min_seconds,
        max_seconds=config.scroll_before_signup_max_seconds,
    )
    configure_signup_disclaimer_read(
        enabled=config.read_signup_disclaimer_before_check,
        min_seconds=config.read_signup_disclaimer_min_seconds,
        max_seconds=config.read_signup_disclaimer_max_seconds,
    )
    configure_phone_add_number_submits(
        max_attempts=config.phone_add_number_max_attempts,
    )
    configure_spotify_before_ticketmaster(
        enabled=config.visit_spotify_before_ticketmaster,
        url=config.spotify_warmup_url,
        min_seconds=config.spotify_warmup_min_seconds,
        max_seconds=config.spotify_warmup_max_seconds,
    )
    effective_max_sessions = (
        config.max_active_browser_sessions
        if config.max_active_browser_sessions > 0
        else max(1, config.concurrent_browsers)
    )
    effective_max_launches = (
        config.max_simultaneous_browser_launches
        if config.max_simultaneous_browser_launches > 0
        else effective_max_sessions
    )
    configure_browser_pool_limits(
        max_active_sessions=effective_max_sessions,
        max_simultaneous_launches=effective_max_launches,
        launch_spacing_seconds=config.browser_launch_spacing_seconds,
    )
    configure_cloakbrowser(
        humanize=config.cloakbrowser_humanize,
        human_preset=config.cloakbrowser_human_preset,
        geoip=config.cloakbrowser_geoip,
        download_read_timeout_seconds=config.cloakbrowser_download_read_timeout_seconds,
    )


def main() -> None:
    config = load_config()
    apply_config(config)
    reset_browser_slots()
    cleanup_orphan_tm_browsers()

    emails = load_emails()

    print(
        f"Config: delay {config.delay_min_seconds}-{config.delay_max_seconds}s, "
        f"concurrent browsers {config.concurrent_browsers}, "
        f"cloakbrowser humanize={config.cloakbrowser_humanize} "
        f"preset={config.cloakbrowser_human_preset} geoip={config.cloakbrowser_geoip} "
        f"max_browser_restarts={config.max_browser_restarts} "
        f"otp_wait={config.otp_wait_seconds}s "
        f"sms_otp_wait={config.sms_otp_wait_seconds}s "
        f"auth_timeout={config.auth_page_timeout_seconds}s "
        f"phone_rotations={config.phone_number_max_rotations} "
        f"sms_provider={config.sms_provider} "
        f"sms_provider_ids={','.join(SMS_PROVIDER_IDS) or 'any'} "
        f"sms_get_number_wait={config.sms_get_number_max_wait_seconds:.0f}s "
        f"sms_wait_until_number={config.sms_wait_until_number} "
        f"sms_countries={','.join(config.sms_countries) or 'SMS_COUNTRY'} "
        f"sms_get_number_poll={config.sms_get_number_retry_seconds:.0f}s "
        f"browser_pool={config.maintain_active_browser_pool} "
        f"worker_shutdown_timeout={config.worker_shutdown_timeout_seconds}s "
        f"max_active_browsers={max_active_browser_sessions()} "
        f"max_simultaneous_launches={config.max_simultaneous_browser_launches}"
    )
    if config.max_active_browser_sessions == 0:
        print(
            f"Live browser cap follows concurrent_browsers "
            f"({max_active_browser_sessions()}). Set max_active_browser_sessions "
            "if you want extra workers waiting behind fewer Chromium windows."
        )
    sms_country = os.getenv("SMS_COUNTRY", "187").strip().lower()
    selected_countries = [part.strip().lower() for part in config.sms_countries] or [sms_country]
    if not config.sms_provider_ids and any(
        part in {"151", "cl", "chile"} for part in selected_countries
    ):
        print(
            "Warning: SMS provider filter is unset (sms_provider_ids=any). "
            "For Chile, set sms_provider_ids to your SMSBower provider id "
            "(e.g. [\"3419\"]) or SMS_PROVIDER_IDS=3419 in .env so getNumber "
            "matches the provider you pick on the website."
        )
    print("Checking AYCD Inbox API connection...")
    aycd = create_aycd_client()
    try:
        aycd.ensure_connected()
        print("AYCD Inbox API connected")
    finally:
        aycd.close()

    ensure_cloakbrowser_ready()

    proxy_lines = load_proxy_lines()
    total_proxies, distinct_servers = count_distinct_proxy_servers()
    if proxy_lines and distinct_servers < config.concurrent_browsers:
        print(
            f"Warning: proxy.txt has {total_proxies} line(s) but only "
            f"{distinct_servers} distinct proxy server URL(s) for "
            f"{config.concurrent_browsers} concurrent worker(s). "
            "Many workers may share the same gateway (high BAP rate)."
        )
    if config.concurrent_browsers > 1 and len(proxy_lines) < config.concurrent_browsers:
        print(
            f"Warning: only {len(proxy_lines)} proxy line(s) available for "
            f"{config.concurrent_browsers} concurrent browser(s); proxies will be reused."
        )

    print(f"Processing {len(emails)} unused email(s) from customsinformation.csv")
    if not emails:
        return

    stop_sms_number_pool = start_sms_number_pool(provider_ids=SMS_PROVIDER_IDS)
    try:
        _run_signup_jobs(config, emails)
    finally:
        stop_sms_number_pool()


def _run_signup_jobs(config: AppConfig, emails: list[str]) -> None:
    proxy_lines = load_proxy_lines()
    if config.concurrent_browsers == 1:
        for worker_slot, email in enumerate(emails):
            process_email(
                email,
                max_browser_restarts=config.max_browser_restarts,
                worker_slot=worker_slot,
            )
        return

    workers = resolve_parallel_browser_cap(config.concurrent_browsers)
    workers = min(workers, len(emails))
    if proxy_lines and len(emails) > len(proxy_lines):
        print(
            f"Warning: {len(emails)} email(s) queued but only {len(proxy_lines)} "
            "proxy line(s) in proxy.txt (failed proxies are removed automatically)."
        )

    if config.maintain_active_browser_pool:
        print(
            f"Sustained browser pool: {workers} worker process(es) will stay alive, "
            f"pulling {len(emails)} email(s) from the queue and replacing browsers "
            "after each account or failure."
        )
        try:
            run_sustained_browser_pool(
                emails,
                workers=workers,
                max_browser_restarts=config.max_browser_restarts,
                worker_shutdown_timeout_seconds=config.worker_shutdown_timeout_seconds,
                worker_spawn_stagger_seconds=config.worker_spawn_stagger_seconds,
            )
        except KeyboardInterrupt:
            print("Browser pool stopped.")
            raise
        return

    if workers < config.concurrent_browsers:
        print(
            f"Running {workers} one-shot browser process(es) "
            f"(proxies={len(proxy_lines)}, emails={len(emails)})"
        )
    else:
        print(f"Running {workers} one-shot browser processes in parallel")

    mp_ctx = mp.get_context("spawn")

    with ProcessPoolExecutor(max_workers=workers, mp_context=mp_ctx) as executor:
        futures = {
            executor.submit(
                process_email_worker,
                worker_slot,
                email,
                config.max_browser_restarts,
            ): email
            for worker_slot, email in enumerate(emails)
        }
        for future in as_completed(futures):
            email = futures[future]
            try:
                future.result()
            except Exception as exc:
                print(f"Worker failed for {email}: {exc}")


if __name__ == "__main__":
    main()
