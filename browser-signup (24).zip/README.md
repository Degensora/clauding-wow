# Ticketmaster Browser Signup

Automates Ticketmaster US account signup using [CloakBrowser](https://github.com/CloakHQ/cloakbrowser) (stealth Chromium), residential proxies, [AYCD Inbox](https://aycd.io/) for email OTP, and [SMSBower](https://smsbower.app/) for phone OTP. Successful accounts are exported to CSV with cookies.

## Features

- CloakBrowser stealth browser with human-like mouse, keyboard, and scroll behavior
- Proxy support with optional GeoIP alignment
- Email OTP via AYCD Inbox API
- Phone OTP via SMSBower (US numbers)
- Concurrent account creation
- CSV export with session cookies
- Browser stays open on failure for debugging

## Requirements

- Python 3.10+
- Windows (tested; CloakBrowser downloads a Windows Chromium build)
- AYCD Inbox API key
- SMSBower API key with balance
- Residential proxies (recommended)
- Email addresses that can receive Ticketmaster verification emails

## Setup

1. **Clone / open the project** and create a virtual environment:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

2. **Install Playwright browsers** (dependency of CloakBrowser):

```bash
playwright install
```

3. **Copy environment variables**:

```bash
copy .env.example .env
```

Edit `.env` with your API keys:

| Variable | Description |
|---|---|
| `AYCD_API_KEY` | AYCD Inbox API key (starts with `Inbox-`) |
| `SMS_PROVIDER` | `smsbower`, `grizzlysms`, `hero_sms`, `smspool`, or `5sim` |
| `SMS_COUNTRY` | One virtual-number country for every provider. SMS-Activate ids, ISO codes, or names (`187`/`US`, `16`/`UK`, `43`/`DE`, `151`/`CL`, …). SMSBower and GrizzlySMS accept the full country list |
| `SMSBOWER_COUNTRIES` | Optional comma-separated SMSBower countries (`151,16,187` or `CL,UK,US`). Overrides `SMS_COUNTRY` for SMSBower |
| `GRIZZLY_COUNTRIES` | Optional comma-separated GrizzlySMS countries. Falls back to `SMS_COUNTRIES`, then `SMSBOWER_COUNTRIES`, then `SMS_COUNTRY` |
| `SMS_NUMBERS_PER_COUNTRY` | How many unused numbers SMSBower/GrizzlySMS keep ready per selected country (default `3`) |
| `FIVESIM_API_KEY` | 5SIM protocol API key from Profile → Get API key (when `SMS_PROVIDER=5sim`) |
| `FIVESIM_SERVICE` | 5SIM product slug (default: `ticketmaster`) |
| `FIVESIM_OPERATOR` | 5SIM operator (`any` or a named operator) |
| `SMSBOWER_API_KEY` | SMSBower API key (when `SMS_PROVIDER=smsbower`) |
| `SMSBOWER_SERVICE` | Ticketmaster service code (default: `gp`) |
| `SMSBOWER_MAX_PRICE` | Max price per number |
| `SMSBOWER_MIN_PRICE` | Min price per number |
| `CLOAKBROWSER_LICENSE_KEY` | Optional; free tier works without it |
| `DISCORD_WEBHOOK_URL` | Optional; Discord webhook notified on each successful signup (cookies stay in CSV only) |

4. **Add input files**:

- `email.txt` — one email per line
- `proxy.txt` — one proxy per line (see [Proxy format](#proxy-format))

5. **First CloakBrowser run** downloads ~500 MB of Chromium. On slow connections this can take a while. You can pre-install manually:

```bash
python -m cloakbrowser install
```

## Usage

```bash
python main.py
```

The script:

1. Validates AYCD API connectivity
2. Ensures CloakBrowser is installed (downloads if needed)
3. Processes each email in `email.txt` (round-robin proxy assignment)

On success, the browser closes automatically and the account is appended to `export/TicketMasterAccount.csv`.

On failure, the browser stays open until you press **Enter** in the terminal.

## Signup flow

```
Optional Spotify warmup, then ticketmaster.com
  → Submit email
  → Fill signup form (password, name, zip, disclaimer)
  → Email OTP (AYCD)
  → Add phone number (SMS provider)
  → Phone OTP (SMS provider)
  → Confirm account
  → Export CSV + cookies
```

## Configuration

Edit `config.json`:

| Key | Default | Description |
|---|---|---|
| `delay_min_seconds` | `0.2` | Min pause between actions |
| `delay_max_seconds` | `0.5` | Max pause between actions |
| `concurrent_browsers` | `1` | Target number of parallel browser worker processes |
| `maintain_active_browser_pool` | `true` | When `concurrent_browsers` > 1, keep that many long-lived workers pulling emails from a queue; each failure closes the browser and the worker picks the next email (set `false` for legacy one-browser-per-email tasks) |
| `worker_shutdown_timeout_seconds` | `900` | On **Ctrl+C** (or forced pool stop), max seconds to wait for each worker to exit before killing it and its Chromium children. The pool otherwise runs until all emails are processed — this is **not** a max runtime per run |
| `max_active_browser_sessions` | `0` | Max **live** CloakBrowser instances. `0` = same as `concurrent_browsers` |
| `max_simultaneous_browser_launches` | `0` | Max Chromium launches at the same instant. `0` = same as live browser cap; raise launch spacing instead of lowering this to 2 |
| `worker_spawn_stagger_seconds` | `12` | Delay between starting each pool worker process and between worker cold starts |
| `browser_launch_spacing_seconds` | `3` | Extra jitter before each browser launch (reduces CPU/RAM spikes) |
| `browser_slot_wait_seconds` | `600` | How long a worker waits for a free browser slot before failing the attempt |
| `max_browser_restarts` | `5` | Extra attempts to acquire a browser slot when workers are saturated (not same-email retries) |
| `scroll_ticketmaster_home_before_signup` | `true` | Scroll the Ticketmaster home page with the mouse wheel before clicking Sign In/Register |
| `scroll_before_signup_min_seconds` | `6` | Minimum time spent scrolling when the above is enabled |
| `scroll_before_signup_max_seconds` | `18` | Maximum scroll time (random between min and max each run) |
| `read_signup_disclaimer_before_check` | `true` | Pause on the “I acknowledge…” Terms/Privacy checkbox before checking it |
| `read_signup_disclaimer_min_seconds` | `3` | Minimum time spent “reading” the disclaimer |
| `read_signup_disclaimer_max_seconds` | `10` | Maximum read time (random between min and max each run) |
| `phone_add_number_max_attempts` | `5` | Retries **Add Number** / Enter when TM shows “unable to process” / `sendSmsOtp` (common on UK) |
| `visit_spotify_before_ticketmaster` | `false` | Visit Spotify before opening Ticketmaster (more natural referrer path) |
| `spotify_warmup_url` | `https://open.spotify.com/` | First page to load when the above is enabled |
| `spotify_warmup_min_seconds` | `4` | Minimum time on Spotify before going to Ticketmaster |
| `spotify_warmup_max_seconds` | `12` | Maximum Spotify dwell time (random between min and max) |
| `cloakbrowser_humanize` | `true` | Human-like mouse/keyboard/scroll |
| `cloakbrowser_human_preset` | `careful` | `careful` (slower) or `default` |
| `cloakbrowser_geoip` | `true` | Align timezone/locale with proxy IP |
| `cloakbrowser_download_read_timeout_seconds` | `1800` | Download timeout for first CloakBrowser install |
| `sms_provider` | `smsbower` | Virtual SMS backend (`smsbower`, `grizzlysms`, `hero_sms`, `smspool`, `5sim`) |
| `sms_provider_ids` | `[]` | Restrict `getNumber` to specific SMSBower provider ids (e.g. `["3419"]` for Chile). Empty = any provider |
| `sms_get_number_retry_seconds` | `10` | Pause between `getNumber` polls when the API returns `NO_NUMBERS` (provider queue) |
| `sms_get_number_max_wait_seconds` | `120` | Total time to keep polling the queue before failing, unless `sms_wait_until_number` is on |
| `sms_wait_until_number` | `false` | Once a browser reaches the phone step, keep requesting until a number arrives instead of giving up after `sms_get_number_max_wait_seconds` |
| `sms_countries` | `[]` | Countries to run together (`["US", "UK", "CL"]` is United States, United Kingdom, and Chile). Empty uses `SMS_COUNTRY` from `.env` |

Set `SMS_COUNTRY=151` in `.env` for Chile, or `SMSBOWER_COUNTRIES=151,16,187` to rotate several countries. For SMSBower and GrizzlySMS the script keeps about `SMS_NUMBERS_PER_COUNTRY` (default 3) fresh numbers stocked for each selected country and refills as workers claim them. Unused numbers older than 12 minutes are released. Restrict providers with **`SMSBOWER_PROVIDER_IDS=3451,3419`** (or `sms_provider_ids` in `config.json`) — if unset, the script uses **any** provider and you may get $0.07 numbers even when cheaper pools exist on the site. Set **`SMSBOWER_MAX_PRICE=0.065`** (or lower) as a hard cap. SMSBower buys with `getNumber` so `phoneException` is applied (`getNumberV2` ignores it). GrizzlySMS uses the same handler API and `getNumberV2` (`SMS_PROVIDER=grizzlysms`, `GRIZZLY_API_KEY`, `GRIZZLY_SERVICE=gp`).

**Tips:**

- Keep `concurrent_browsers` at `1` until CloakBrowser is fully installed.
- Use `careful` preset for more natural interaction timing.
- Increase `delay_max_seconds` (e.g. `1.0`) for slower, more human pacing.

## Input files

### `email.txt`

One email address per line. Lines starting with `#` are ignored.

```
user1@outlook.com
user2@outlook.com
```

### `proxy.txt`

One proxy per line. When signup fails with bot detection, OTP restart, phone session restart, or a signup timeout, that proxy line is **deleted from `proxy.txt`** so it is never reused. The worker then takes the **next email** from the queue with a **new browser** and the next remaining proxy.

Supported formats:

```
host:port
host:port:username:password
http://username:password@host:port
```

Proxies are assigned round-robin: email index 0 → proxy line 0, index 1 → proxy line 1, etc.

## Output

Accounts are written to:

```
export/TicketMasterAccount.csv
```

Columns: `EMAIL`, `PASSWORD`, `ZIP`, `FIRSTNAME`, `LASTNAME`, `NUMBER`, `PHONE`, `COUNTRY`, `PROXY`, `STATUS`, `DATE`, `COOKIES`, `PROFILE STATUS`, `SORTC`.

## Project structure

```
browser-signup/
├── main.py          # Entry point, signup flow, CSV export
├── browser.py       # CloakBrowser launch, form helpers, human interactions
├── aycd.py          # AYCD Inbox API client
├── smsbower.py      # SMSBower phone OTP client
├── config.py        # config.json loader
├── config.json      # Runtime settings
├── email.txt        # Emails to sign up
├── proxy.txt        # Proxy list
├── .env             # API keys (not committed)
└── export/          # TicketMasterAccount.csv + export lock
```

## Human-like behavior

Interactions go through CloakBrowser's `humanize` pipeline:

- **Mouse** — Bézier curves, aim delay, natural click hold
- **Keyboard** — Per-character typing with variable timing and pauses
- **Scroll** — Smooth wheel-based scrolling into view

The script avoids DOM-injection clicks and instant `fill()` without focus. Use `cloakbrowser_human_preset: "careful"` for the most natural behavior.

## Troubleshooting

| Issue | Fix |
|---|---|
| CloakBrowser download timeout | Increase `cloakbrowser_download_read_timeout_seconds` or run `python -m cloakbrowser install` |
| `Primary download failed, trying GitHub Releases` | Normal on unstable networks; retries resume partial downloads |
| Auth page stuck on "Almost there..." | Wait up to 5 minutes; script polls automatically |
| AYCD OTP not found | Confirm email is in AYCD Inbox; subject filter is `Authentication Code` |
| Phone field fill fails | Ensure a 10-digit US number from SMSBower |
| Blocked / captcha page | Try a different proxy; ensure `cloakbrowser_geoip` is enabled |

## License

For personal use. Ensure compliance with Ticketmaster's Terms of Service and applicable laws in your jurisdiction.
