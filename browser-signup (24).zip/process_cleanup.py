"""Force-stop Playwright/CloakBrowser child processes (prevents orphan Chromium)."""

from __future__ import annotations

import os
import sys

_BROWSER_NAME_HINTS = ("chrome", "chromium", "cloak", "msedge")


def _looks_like_browser_process(name: str) -> bool:
    lowered = (name or "").lower()
    return any(hint in lowered for hint in _BROWSER_NAME_HINTS)


def list_browser_child_pids(parent_pid: int | None = None) -> list[int]:
    try:
        import psutil
    except ImportError:
        return []

    root = parent_pid if parent_pid is not None else os.getpid()
    try:
        process = psutil.Process(root)
    except Exception:
        return []

    pids: list[int] = []
    try:
        children = process.children(recursive=True)
    except Exception:
        return []

    for child in children:
        try:
            if _looks_like_browser_process(child.name()):
                pids.append(child.pid)
        except Exception:
            continue
    return pids


def cleanup_orphan_tm_browsers() -> int:
    """Kill leftover CloakBrowser/Chromium from previous signup runs (not other Chrome)."""

    try:
        import psutil
    except ImportError:
        return 0

    killed = 0
    current = os.getpid()
    for proc in psutil.process_iter(["pid", "name", "cmdline", "cwd"]):
        try:
            pid = int(proc.info.get("pid") or 0)
            if pid <= 0 or pid == current:
                continue
            name = (proc.info.get("name") or "").lower()
            if not _looks_like_browser_process(name):
                continue
            cmdline = " ".join(proc.info.get("cmdline") or [])
            cwd = str(proc.info.get("cwd") or "")
            blob = f"{cmdline} {cwd}".lower()
            if "tm_cloak_" not in blob:
                continue
            proc.kill()
            killed += 1
        except Exception:
            continue
    if killed:
        print(f"Cleaned up {killed} leftover CloakBrowser process(es) from a previous run")
    return killed


def kill_browser_child_processes(parent_pid: int | None = None) -> int:
    """Kill Chromium/CloakBrowser children of ``parent_pid`` (default: current process)."""

    try:
        import psutil
    except ImportError:
        print(
            "Warning: psutil not installed — cannot force-kill orphan browser processes. "
            "Run: pip install psutil"
        )
        return 0

    root = parent_pid if parent_pid is not None else os.getpid()
    killed = 0
    for pid in list_browser_child_pids(root):
        try:
            psutil.Process(pid).kill()
            killed += 1
        except Exception:
            continue
    if killed:
        print(f"Force-killed {killed} browser child process(es) (parent pid={root})")
    return killed


def shutdown_process_tree(process_pid: int, *, grace_seconds: float = 15.0) -> None:
    """Terminate a worker PID and any browser children it spawned."""

    try:
        import psutil
    except ImportError:
        if sys.platform == "win32":
            import subprocess

            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(process_pid)],
                capture_output=True,
                check=False,
            )
        return

    child_pids = list_browser_child_pids(process_pid)
    try:
        worker = psutil.Process(process_pid)
    except Exception:
        worker = None

    if worker is not None and worker.is_running():
        try:
            worker.terminate()
            worker.wait(timeout=grace_seconds)
        except Exception:
            try:
                worker.kill()
            except Exception:
                pass

    for pid in child_pids:
        try:
            psutil.Process(pid).kill()
        except Exception:
            continue
