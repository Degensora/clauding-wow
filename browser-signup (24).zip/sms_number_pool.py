"""Keep a few fresh virtual numbers ready for each selected country.

Workers claim from this inventory instead of each calling getNumber at the
moment the phone form appears. One maintainer in the parent process refills
the pool, so a large browser pool does not stampede the SMS provider.
"""

from __future__ import annotations

import json
import os
import threading
import time
from collections.abc import Callable
from typing import Any

from config import RUNTIME_DIR, interprocess_lock
from phone_sms import (
    activation_seconds_left,
    format_activation_time_left,
    sms_activation_lifetime_seconds,
    sms_min_remaining_seconds,
)
from sms_countries import get_country

POOL_FILE = RUNTIME_DIR / "sms_number_pool.json"
POOL_LOCK = RUNTIME_DIR / "sms_number_pool.lock"
HEARTBEAT_STALE_SECONDS = 45.0
POOL_PROVIDERS = frozenset({"SMSBower", "GrizzlySMS"})
# File locks on Windows are per process. This keeps the maintainer thread and a
# same-process signup from locking the pool file at the same time.
_THREAD_LOCK = threading.Lock()


def sms_number_pool_enabled() -> bool:
    return os.getenv("SMS_NUMBER_POOL", "1").strip().lower() not in {
        "0",
        "false",
        "no",
        "off",
    }


def sms_numbers_per_country() -> int:
    raw = os.getenv("SMS_NUMBERS_PER_COUNTRY", "3").strip()
    try:
        return max(0, int(raw))
    except ValueError:
        return 3


def sms_pool_max_age_seconds() -> float:
    raw = os.getenv("SMS_NUMBER_POOL_MAX_AGE_SECONDS", "720").strip()
    try:
        return max(60.0, float(raw))
    except ValueError:
        return 720.0


def sms_pool_claim_wait_seconds() -> float:
    raw = os.getenv("SMS_POOL_CLAIM_WAIT_SECONDS", "30").strip()
    try:
        return max(0.0, float(raw))
    except ValueError:
        return 30.0


def _empty_state() -> dict[str, Any]:
    return {
        "heartbeat": 0.0,
        "maintainer_pid": 0,
        "rr": 0,
        "exceptions": {},
        "demand_holders": {},
        "items": [],
    }


def _read_state() -> dict[str, Any]:
    try:
        raw = POOL_FILE.read_text(encoding="utf-8")
    except OSError:
        return _empty_state()
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return _empty_state()
    if not isinstance(parsed, dict):
        return _empty_state()
    parsed.setdefault("heartbeat", 0.0)
    parsed.setdefault("maintainer_pid", 0)
    parsed.setdefault("rr", 0)
    if not isinstance(parsed.get("exceptions"), dict):
        parsed["exceptions"] = {}
    if not isinstance(parsed.get("demand_holders"), dict):
        parsed["demand_holders"] = {}
    if not isinstance(parsed.get("items"), list):
        parsed["items"] = []
    return parsed


def _write_state(state: dict[str, Any]) -> None:
    POOL_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = POOL_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, separators=(",", ":")), encoding="utf-8")
    os.replace(tmp, POOL_FILE)


def _locked(mutate: Callable[[dict[str, Any]], Any]) -> Any:
    with _THREAD_LOCK:
        with interprocess_lock(POOL_LOCK, timeout=30):
            state = _read_state()
            result = mutate(state)
            _write_state(state)
            return result


def _heartbeat_fresh(state: dict[str, Any], now: float | None = None) -> bool:
    stamp = float(state.get("heartbeat") or 0.0)
    current = time.time() if now is None else now
    return stamp > 0 and (current - stamp) <= HEARTBEAT_STALE_SECONDS


def _matching_item(item: object, provider: str, service: str) -> bool:
    if not isinstance(item, dict):
        return False
    return str(item.get("provider") or "") == provider and str(item.get("service") or "") == service


def _item_expires_at(item: dict[str, Any]) -> float:
    expires_at = float(item.get("expires_at") or 0.0)
    if expires_at > 0:
        return expires_at
    bought_at = float(item.get("bought_at") or 0.0)
    if bought_at <= 0:
        return 0.0
    return bought_at + sms_activation_lifetime_seconds()


def _item_has_time_left(item: dict[str, Any], now: float) -> bool:
    """True while the provider countdown still has at least 5 minutes."""

    expires_at = _item_expires_at(item)
    if expires_at <= 0:
        return False
    return activation_seconds_left(expires_at, now) >= sms_min_remaining_seconds()


def _item_available(item: dict[str, Any], now: float) -> bool:
    """A number waiting to be typed into Ticketmaster. Cancelling numbers are not offered."""

    if item.get("pending_cancel"):
        return False
    return _item_has_time_left(item, now)


_DEMAND_STALE_SECONDS = 20.0


def _prune_demand(holders: dict[str, Any], now: float | None = None) -> None:
    current = time.time() if now is None else now
    stale = [
        token
        for token, stamp in holders.items()
        if current - float(stamp or 0.0) > _DEMAND_STALE_SECONDS
    ]
    for token in stale:
        holders.pop(token, None)


def _demand_count(state: dict[str, Any], now: float | None = None) -> int:
    holders = state.get("demand_holders")
    if not isinstance(holders, dict):
        state["demand_holders"] = {}
        return 0
    _prune_demand(holders, now)
    return len(holders)


def _begin_phone_demand() -> str:
    token = f"{os.getpid()}-{time.time_ns()}"

    def mutate(state: dict[str, Any]) -> None:
        holders = state.setdefault("demand_holders", {})
        if not isinstance(holders, dict):
            holders = {}
            state["demand_holders"] = holders
        _prune_demand(holders)
        holders[token] = time.time()

    _locked(mutate)
    return token


def _heartbeat_phone_demand(token: str) -> None:
    def mutate(state: dict[str, Any]) -> None:
        holders = state.get("demand_holders")
        if isinstance(holders, dict) and token in holders:
            holders[token] = time.time()

    try:
        _locked(mutate)
    except Exception:
        pass


def _end_phone_demand(token: str) -> None:
    def mutate(state: dict[str, Any]) -> None:
        holders = state.get("demand_holders")
        if isinstance(holders, dict):
            holders.pop(token, None)

    try:
        _locked(mutate)
    except Exception:
        pass


def pooled_phone_exceptions(provider: str, country_id: str) -> list[str]:
    try:
        state = _locked(lambda current: current)
    except Exception:
        return []
    bucket = state.get("exceptions", {}).get(str(country_id), [])
    if not isinstance(bucket, list):
        return []
    return [str(prefix) for prefix in bucket if str(prefix).strip()]


def note_phone_exceptions(provider: str, country_id: str, prefixes: list[str]) -> None:
    del provider  # exceptions are country prefixes, shared by the active handler provider
    clean = [prefix.strip() for prefix in prefixes if prefix and prefix.strip()]
    if not clean:
        return

    def mutate(state: dict[str, Any]) -> None:
        exceptions = state.setdefault("exceptions", {})
        bucket = exceptions.get(str(country_id))
        if not isinstance(bucket, list):
            bucket = []
        for prefix in clean:
            if prefix not in bucket:
                bucket.append(prefix)
        exceptions[str(country_id)] = bucket[-10:]

    try:
        _locked(mutate)
    except Exception as exc:
        print(f"Could not store phone prefix exception: {exc}")


def clear_pooled_phone_exceptions(country_id: str) -> None:
    def mutate(state: dict[str, Any]) -> None:
        exceptions = state.get("exceptions")
        if isinstance(exceptions, dict):
            exceptions.pop(str(country_id), None)

    try:
        _locked(mutate)
    except Exception as exc:
        print(f"Could not clear phone prefix exceptions: {exc}")


def rotate_country(countries: tuple[str, ...]) -> str:
    """Pick the next country in a cross-process rotation so workers spread across the list."""

    if not countries:
        raise ValueError("country list is empty")
    if len(countries) == 1:
        return countries[0]

    def mutate(state: dict[str, Any]) -> str:
        index = int(state.get("rr") or 0) % len(countries)
        state["rr"] = (index + 1) % len(countries)
        return countries[index]

    return str(_locked(mutate))


def claim_pooled_activation(
    provider: str,
    service: str,
    countries: tuple[str, ...],
    *,
    wait_seconds: float | None,
    on_poll: Callable[[], None] | None = None,
):
    """Return a fresh pooled activation, or None when the maintainer has none ready.

    ``wait_seconds=None`` waits until a number appears or the maintainer stops.
    """

    if provider not in POOL_PROVIDERS or not countries:
        return None
    if wait_seconds is not None and wait_seconds < 0:
        return None

    deadline = None if wait_seconds is None else time.monotonic() + wait_seconds
    last_log = 0.0
    last_poll = 0.0
    last_heartbeat = 0.0
    demand_token = _begin_phone_demand()
    try:
        return _claim_pooled_activation(
            provider,
            service,
            countries,
            deadline=deadline,
            last_log=last_log,
            last_poll=last_poll,
            last_heartbeat=last_heartbeat,
            demand_token=demand_token,
            on_poll=on_poll,
        )
    finally:
        _end_phone_demand(demand_token)


def _claim_pooled_activation(
    provider: str,
    service: str,
    countries: tuple[str, ...],
    *,
    deadline: float | None,
    last_log: float,
    last_poll: float,
    last_heartbeat: float,
    demand_token: str,
    on_poll: Callable[[], None] | None,
):
    from phone_sms import PhoneActivation

    while True:
        now_mono = time.monotonic()
        if now_mono - last_heartbeat >= 5:
            _heartbeat_phone_demand(demand_token)
            last_heartbeat = now_mono
        try:
            claimed, keep_waiting = _locked(
                lambda state: _claim_once(state, provider, service, countries)
            )
        except Exception as exc:
            print(f"{provider} number pool claim skipped: {exc}")
            return None
        if claimed is not None:
            expires_at = float(claimed.get("expires_at") or 0.0)
            if expires_at <= 0:
                bought_at = float(claimed.get("bought_at") or 0.0)
                if bought_at > 0:
                    expires_at = bought_at + sms_activation_lifetime_seconds()
            return PhoneActivation(
                activation_id=str(claimed["activation_id"]),
                phone_number=str(claimed["phone_number"]),
                country=str(claimed["country"]),
                expires_at=expires_at,
            )
        now = time.monotonic()
        if deadline is None and now - last_log >= 15:
            print(
                f"{provider} still waiting for a number "
                f"({', '.join(countries)})..."
            )
            last_log = now
        if on_poll is not None and now - last_poll >= 5:
            on_poll()
            last_poll = now
        if not keep_waiting or (deadline is not None and now >= deadline):
            return None
        time.sleep(0.4)


def _claim_once(
    state: dict[str, Any],
    provider: str,
    service: str,
    countries: tuple[str, ...],
) -> tuple[dict[str, Any] | None, bool]:
    """Return (activation, keep_waiting). Waiting is only useful while a maintainer is alive."""

    now = time.time()
    fresh: list[dict[str, Any]] = []
    for item in state.get("items", []):
        if not _matching_item(item, provider, service):
            continue
        if not _item_available(item, now):
            continue
        if str(item.get("country") or "") not in countries:
            continue
        fresh.append(item)
    if not fresh:
        return None, _heartbeat_fresh(state, now)

    start = int(state.get("rr") or 0) % len(countries)
    chosen: dict[str, Any] | None = None
    chosen_offset = 0
    for offset in range(len(countries)):
        country_id = countries[(start + offset) % len(countries)]
        for item in fresh:
            if str(item.get("country") or "") == country_id:
                chosen = item
                chosen_offset = offset
                break
        if chosen is not None:
            break
    if chosen is None:
        return None, _heartbeat_fresh(state, now)

    state["rr"] = (start + chosen_offset + 1) % len(countries)
    activation_id = str(chosen.get("activation_id") or "")
    state["items"] = [
        item
        for item in state.get("items", [])
        if not (
            isinstance(item, dict) and str(item.get("activation_id") or "") == activation_id
        )
    ]
    return chosen, False


class SmsNumberPool:
    def __init__(self, client: Any, countries: tuple[str, ...], target: int, max_age: float) -> None:
        self.client = client
        self.countries = countries
        self.target = target
        self.max_age = max_age
        self.provider = str(getattr(client, "provider_name", ""))
        self.service = str(getattr(client, "service", ""))
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            name="sms-number-pool",
            daemon=True,
        )
        self._last_stock = ""
        self._last_empty_log: dict[str, float] = {}

    def start(self) -> None:
        self._touch_heartbeat()
        labels = []
        for country_id in self.countries:
            country = get_country(country_id)
            labels.append(f"{country_id} {country.name}" if country else country_id)
        print(
            f"{self.provider} number pool: buying for {', '.join(labels)} "
            f"only while a browser is on the phone step (up to {self.target} per country)"
        )
        print(
            "Numbers are not purchased ahead of time. Unused ones are cancelled "
            "when no signup is entering a phone."
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=40)
        if self._thread.is_alive():
            print(f"{self.provider} number pool is still buying — leaving it to finish")
            return
        self._release_unclaimed()
        try:
            self.client.close()
        except Exception:
            pass

    def _touch_heartbeat(self) -> None:
        def mutate(state: dict[str, Any]) -> None:
            state["heartbeat"] = time.time()
            state["maintainer_pid"] = os.getpid()

        _locked(mutate)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._touch_heartbeat()
                self._release_stale()
                self._release_above_demand()
                self._retry_pending_cancels()
                self._fill_for_demand()
                self._log_stock()
            except Exception as exc:
                print(f"{self.provider} number pool error: {exc}")
            self._stop.wait(3.0)
        try:
            self._touch_heartbeat()
        except Exception:
            pass

    def _count_fresh(self, country_id: str) -> int:
        now = time.time()

        def mutate(state: dict[str, Any]) -> int:
            count = 0
            for item in state.get("items", []):
                if not _matching_item(item, self.provider, self.service):
                    continue
                if str(item.get("country") or "") != country_id:
                    continue
                if _item_available(item, now):
                    count += 1
            return count

        return int(_locked(mutate))

    def _fill_for_demand(self) -> None:
        try:
            demand, counts = self._stock_snapshot()
        except Exception as exc:
            print(f"{self.provider} number pool could not read stock: {exc}")
            return
        cap = self.target * max(len(self.countries), 1)
        if sum(counts.values()) >= min(demand, cap):
            return
        country_id: str | None = None
        best: tuple[int, int] | None = None
        for index, candidate in enumerate(self.countries):
            have = counts.get(candidate, 0)
            if have >= self.target:
                continue
            rank = (have, index)
            if best is None or rank < best:
                best = rank
                country_id = candidate
        if country_id is None:
            return
        self._fill_country(country_id, once=True)

    def _stock_snapshot(self) -> tuple[int, dict[str, int]]:
        now = time.time()

        def mutate(state: dict[str, Any]) -> tuple[int, dict[str, int]]:
            counts = {country_id: 0 for country_id in self.countries}
            for item in state.get("items", []):
                if not isinstance(item, dict) or not _matching_item(item, self.provider, self.service):
                    continue
                if not _item_available(item, now):
                    continue
                country_id = str(item.get("country") or "")
                if country_id in counts:
                    counts[country_id] += 1
            return _demand_count(state, now), counts

        demand, counts = _locked(mutate)
        return int(demand), {str(key): int(value) for key, value in counts.items()}

    def _fill_country(self, country_id: str, *, once: bool = False) -> None:
        while not self._stop.is_set():
            try:
                have = self._count_fresh(country_id)
            except Exception as exc:
                print(f"{self.provider} number pool could not read stock: {exc}")
                return
            if have >= self.target:
                return
            self._touch_heartbeat()
            try:
                activation = self.client.buy_number(
                    country=country_id,
                    max_wait_seconds=12,
                    max_attempts=2,
                )
            except Exception as exc:
                self._log_empty(country_id, exc)
                return
            stored = self._store(activation, country_id)
            if stored:
                left = activation_seconds_left(float(getattr(activation, "expires_at", 0.0) or 0.0))
                print(
                    f"{self.provider} pooled {activation.phone_number} "
                    f"({format_activation_time_left(left)} left) for a browser on the phone step"
                )
            if not stored:
                try:
                    self.client.cancel(activation.activation_id)
                except Exception:
                    pass
                return
            if once:
                return

    def _store(self, activation: Any, country_id: str) -> bool:
        def mutate(state: dict[str, Any]) -> bool:
            now = time.time()
            have = 0
            for item in state.get("items", []):
                if not _matching_item(item, self.provider, self.service):
                    continue
                if str(item.get("country") or "") != country_id:
                    continue
                if _item_available(item, now):
                    have += 1
            if have >= self.target:
                return False
            expires_at = float(getattr(activation, "expires_at", 0.0) or 0.0)
            if expires_at <= 0:
                expires_at = now + sms_activation_lifetime_seconds()
            state.setdefault("items", []).append(
                {
                    "provider": self.provider,
                    "service": self.service,
                    "country": country_id,
                    "activation_id": activation.activation_id,
                    "phone_number": activation.phone_number,
                    "bought_at": now,
                    "expires_at": expires_at,
                }
            )
            return True

        return bool(_locked(mutate))

    def _release_stale(self) -> None:
        now = time.time()

        def mutate(state: dict[str, Any]) -> list[str]:
            keep: list[object] = []
            cancel_ids: list[str] = []
            for item in state.get("items", []):
                if not isinstance(item, dict):
                    continue
                provider_name = str(item.get("provider") or "")
                service = str(item.get("service") or "")
                if provider_name == self.provider and (
                    not _item_has_time_left(item, now) or service != self.service
                ):
                    activation_id = str(item.get("activation_id") or "")
                    if activation_id:
                        cancel_ids.append(activation_id)
                    continue
                if provider_name not in {"", self.provider}:
                    continue
                keep.append(item)
            state["items"] = keep
            return cancel_ids

        try:
            cancel_ids = _locked(mutate)
        except Exception as exc:
            print(f"{self.provider} number pool prune failed: {exc}")
            return
        _cancelled, denied_ids = self._cancel_ids(cancel_ids)
        denied = len(denied_ids)
        if cancel_ids:
            floor = format_activation_time_left(sms_min_remaining_seconds())
            print(
                f"{self.provider} released {len(cancel_ids) - denied} pooled number(s) "
                f"with under {floor} left"
            )
        if denied:
            print(
                f"{self.provider} could not cancel {denied} pooled number(s) yet "
                "(provider early-cancel window); they expire on their own"
            )

    def _release_unclaimed(self) -> None:
        def mutate(state: dict[str, Any]) -> list[str]:
            keep: list[object] = []
            cancel_ids: list[str] = []
            for item in state.get("items", []):
                if _matching_item(item, self.provider, self.service):
                    activation_id = str(item.get("activation_id") or "")
                    if activation_id:
                        cancel_ids.append(activation_id)
                    continue
                keep.append(item)
            state["items"] = keep
            state["heartbeat"] = 0.0
            return cancel_ids

        try:
            cancel_ids = _locked(mutate)
        except Exception as exc:
            print(f"{self.provider} number pool shutdown failed: {exc}")
            return
        _cancelled, denied_ids = self._cancel_ids(cancel_ids)
        denied = len(denied_ids)
        if cancel_ids:
            print(
                f"{self.provider} released {len(cancel_ids) - denied} unused pooled number(s)"
            )
        if denied:
            print(
                f"{self.provider} left {denied} pooled number(s) active "
                "(provider refused an early cancel; they expire on their own)"
            )

    def _cancel_ids(self, activation_ids: list[str]) -> tuple[list[str], list[str]]:
        cancelled: list[str] = []
        denied: list[str] = []
        for activation_id in activation_ids:
            requester = getattr(self.client, "request_cancel", None)
            try:
                if callable(requester):
                    text = str(requester(activation_id))
                else:
                    self.client.cancel(activation_id)
                    text = ""
            except Exception:
                text = ""
            if "EARLY_CANCEL_DENIED" in text:
                denied.append(activation_id)
            else:
                cancelled.append(activation_id)
        return cancelled, denied

    def _release_above_demand(self) -> None:
        """Cancel numbers no browser is about to type in. Those sit on SMSBower as waiting for SMS."""

        now = time.time()

        def mutate(state: dict[str, Any]) -> list[str]:
            demand = _demand_count(state, now)
            cap = self.target * max(len(self.countries), 1)
            wanted = min(demand, cap)
            available = [
                item
                for item in state.get("items", [])
                if isinstance(item, dict)
                and _matching_item(item, self.provider, self.service)
                and _item_available(item, now)
            ]
            if len(available) <= wanted:
                return []
            available.sort(key=lambda item: float(item.get("bought_at") or 0.0))
            extras = available[: len(available) - wanted]
            cancel_ids: list[str] = []
            for item in extras:
                item["pending_cancel"] = True
                activation_id = str(item.get("activation_id") or "")
                if activation_id:
                    cancel_ids.append(activation_id)
            return cancel_ids

        try:
            cancel_ids = _locked(mutate)
        except Exception as exc:
            print(f"{self.provider} number pool could not trim unused numbers: {exc}")
            return
        self._finish_cancels(
            list(cancel_ids),
            "no browser is entering that phone number",
        )

    def _retry_pending_cancels(self) -> None:
        now = time.time()

        def mutate(state: dict[str, Any]) -> list[str]:
            cancel_ids: list[str] = []
            for item in state.get("items", []):
                if not isinstance(item, dict) or not item.get("pending_cancel"):
                    continue
                if not _matching_item(item, self.provider, self.service):
                    continue
                if float(item.get("cancel_after") or 0.0) > now:
                    continue
                activation_id = str(item.get("activation_id") or "")
                if activation_id:
                    cancel_ids.append(activation_id)
            return cancel_ids

        try:
            cancel_ids = _locked(mutate)
        except Exception as exc:
            print(f"{self.provider} number pool could not retry cancels: {exc}")
            return
        self._finish_cancels(list(cancel_ids), "the provider cancel window has opened")

    def _finish_cancels(self, activation_ids: list[str], reason: str) -> None:
        if not activation_ids:
            return
        cancelled, denied = self._cancel_ids(activation_ids)
        cancelled_ids = set(cancelled)
        denied_ids = set(denied)

        def mutate(state: dict[str, Any]) -> None:
            now = time.time()
            keep: list[object] = []
            for item in state.get("items", []):
                if not isinstance(item, dict):
                    continue
                activation_id = str(item.get("activation_id") or "")
                if activation_id in cancelled_ids:
                    continue
                if activation_id in denied_ids:
                    item["pending_cancel"] = True
                    item["cancel_after"] = now + 30
                keep.append(item)
            state["items"] = keep

        try:
            _locked(mutate)
        except Exception as exc:
            print(f"{self.provider} number pool could not record cancels: {exc}")
            return
        if cancelled:
            print(
                f"{self.provider} cancelled {len(cancelled)} unused number(s) — {reason}"
            )
        if denied:
            print(
                f"{self.provider} could not cancel {len(denied)} number(s) yet "
                "(provider early-cancel window); will retry"
            )

    def _log_stock(self) -> None:
        now = time.time()

        def mutate(state: dict[str, Any]) -> str:
            parts: list[str] = []
            for country_id in self.countries:
                count = 0
                for item in state.get("items", []):
                    if not _matching_item(item, self.provider, self.service):
                        continue
                    if str(item.get("country") or "") != country_id:
                        continue
                    if _item_available(item, now):
                        count += 1
                parts.append(f"{country_id}:{count}/{self.target}")
            demand = _demand_count(state, now)
            return " ".join(parts) + f" browsers-on-phone={demand}"

        try:
            signature = str(_locked(mutate))
        except Exception:
            return
        if signature != self._last_stock:
            print(f"{self.provider} number pool stock {signature}")
            self._last_stock = signature

    def _log_empty(self, country_id: str, exc: Exception) -> None:
        now = time.time()
        last = self._last_empty_log.get(country_id, 0.0)
        if now - last < 30:
            return
        self._last_empty_log[country_id] = now
        country = get_country(country_id)
        label = country.name if country else country_id
        print(f"{self.provider} pool could not stock {label} ({country_id}): {exc}")


def start_sms_number_pool(provider_ids: tuple[str, ...] | None = None) -> Callable[[], None]:
    """Start the parent-process refill thread. Returns a stop callback."""

    if not sms_number_pool_enabled() or sms_numbers_per_country() <= 0:
        return lambda: None

    from phone_sms import create_phone_sms_client

    client = create_phone_sms_client(provider_ids=provider_ids, pool_enabled=False)
    provider = str(getattr(client, "provider_name", ""))
    countries = tuple(getattr(client, "countries", ()) or ())
    if provider not in POOL_PROVIDERS or not countries:
        try:
            client.close()
        except Exception:
            pass
        return lambda: None

    pool = SmsNumberPool(
        client,
        countries,
        sms_numbers_per_country(),
        sms_pool_max_age_seconds(),
    )
    pool.start()

    def stop() -> None:
        pool.stop()

    return stop
