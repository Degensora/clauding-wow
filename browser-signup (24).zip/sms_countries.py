"""SMS-Activate country ids shared by SMSBower and GrizzlySMS."""

from dataclasses import dataclass


@dataclass(frozen=True)
class SmsCountry:
    country_id: str
    iso: str
    dial: str
    national_min: int
    national_max: int
    name: str
    fivesim: str = ""


COUNTRIES: dict[str, SmsCountry] = {
    "0": SmsCountry("0", "RU", "7", 6, 13, "Russian Federation", ""),
    "1": SmsCountry("1", "UA", "380", 6, 13, "Ukraine", ""),
    "2": SmsCountry("2", "KZ", "7", 6, 13, "Kazakhstan", ""),
    "3": SmsCountry("3", "CN", "86", 6, 13, "China", ""),
    "4": SmsCountry("4", "PH", "63", 6, 13, "Philippines", ""),
    "5": SmsCountry("5", "MM", "95", 6, 13, "Myanmar", ""),
    "6": SmsCountry("6", "ID", "62", 6, 13, "Indonesia", ""),
    "7": SmsCountry("7", "MY", "60", 6, 13, "Malaysia", ""),
    "8": SmsCountry("8", "KE", "254", 6, 13, "Kenya", ""),
    "9": SmsCountry("9", "TZ", "255", 6, 13, "Tanzania", ""),
    "10": SmsCountry("10", "VN", "84", 6, 13, "Viet nam", ""),
    "11": SmsCountry("11", "KG", "996", 6, 13, "Kyrgyzstan", ""),
    "12": SmsCountry("12", "US", "1", 10, 10, "United States (virtual)", ""),
    "13": SmsCountry("13", "IL", "972", 6, 13, "Israel", ""),
    "14": SmsCountry("14", "HK", "852", 6, 13, "Hong Kong", ""),
    "15": SmsCountry("15", "PL", "48", 6, 13, "Poland", ""),
    "16": SmsCountry("16", "GB", "44", 10, 10, "United Kingdom", "england"),
    "17": SmsCountry("17", "MG", "261", 6, 13, "Madagascar", ""),
    "18": SmsCountry("18", "CD", "243", 6, 13, "Congo (Dem. Republic)", ""),
    "19": SmsCountry("19", "NG", "234", 6, 13, "Nigeria", ""),
    "20": SmsCountry("20", "MO", "853", 6, 13, "Macau", ""),
    "21": SmsCountry("21", "EG", "20", 6, 13, "Egypt", ""),
    "22": SmsCountry("22", "IN", "91", 6, 13, "India", ""),
    "23": SmsCountry("23", "IE", "353", 6, 13, "Ireland", ""),
    "24": SmsCountry("24", "KH", "855", 6, 13, "Cambodia", ""),
    "25": SmsCountry("25", "LA", "856", 6, 13, "Lao People`s", ""),
    "26": SmsCountry("26", "HT", "509", 6, 13, "Haiti", ""),
    "27": SmsCountry("27", "CI", "225", 6, 13, "Cote d`Ivoire Ivory Coast", ""),
    "28": SmsCountry("28", "GM", "220", 6, 13, "Gambia", ""),
    "29": SmsCountry("29", "RS", "381", 6, 13, "Serbia", ""),
    "30": SmsCountry("30", "YE", "967", 6, 13, "Yemen", ""),
    "31": SmsCountry("31", "ZA", "27", 6, 13, "South Africa", ""),
    "32": SmsCountry("32", "RO", "40", 6, 13, "Romania", ""),
    "33": SmsCountry("33", "CO", "57", 6, 13, "Colombia", ""),
    "34": SmsCountry("34", "EE", "372", 6, 13, "Estonia", ""),
    "35": SmsCountry("35", "AZ", "994", 6, 13, "Azerbaijan", ""),
    "36": SmsCountry("36", "CA", "1", 10, 10, "Canada", ""),
    "37": SmsCountry("37", "MA", "212", 6, 13, "Morocco", ""),
    "38": SmsCountry("38", "GH", "233", 6, 13, "Ghana", ""),
    "39": SmsCountry("39", "AR", "54", 6, 13, "Argentinas", ""),
    "40": SmsCountry("40", "UZ", "998", 6, 13, "Uzbekistan", ""),
    "41": SmsCountry("41", "CM", "237", 6, 13, "Cameroon", ""),
    "42": SmsCountry("42", "TD", "235", 6, 13, "Chad", ""),
    "43": SmsCountry("43", "DE", "49", 6, 13, "Germany", ""),
    "44": SmsCountry("44", "LT", "370", 6, 13, "Lithuania", ""),
    "45": SmsCountry("45", "HR", "385", 6, 13, "Croatia", ""),
    "46": SmsCountry("46", "SE", "46", 6, 13, "Sweden", ""),
    "47": SmsCountry("47", "IQ", "964", 6, 13, "Iraq", ""),
    "48": SmsCountry("48", "NL", "31", 6, 13, "Netherlands", ""),
    "49": SmsCountry("49", "LV", "371", 6, 13, "Latvia", ""),
    "50": SmsCountry("50", "AT", "43", 6, 13, "Austria", ""),
    "51": SmsCountry("51", "BY", "375", 6, 13, "Belarus", ""),
    "52": SmsCountry("52", "TH", "66", 6, 13, "Thailand", ""),
    "53": SmsCountry("53", "SA", "966", 6, 13, "Saudi Arabia", ""),
    "54": SmsCountry("54", "MX", "52", 6, 13, "Mexico", ""),
    "55": SmsCountry("55", "TW", "886", 6, 13, "Taiwan", ""),
    "56": SmsCountry("56", "ES", "34", 6, 13, "Spain", ""),
    "57": SmsCountry("57", "IR", "98", 6, 13, "Iran", ""),
    "58": SmsCountry("58", "DZ", "213", 6, 13, "Algeria", ""),
    "59": SmsCountry("59", "SI", "386", 6, 13, "Slovenia", ""),
    "60": SmsCountry("60", "BD", "880", 6, 13, "Bangladesh", ""),
    "61": SmsCountry("61", "SN", "221", 6, 13, "Senegal", ""),
    "62": SmsCountry("62", "TR", "90", 6, 13, "Turkey", ""),
    "63": SmsCountry("63", "CZ", "420", 6, 13, "Czech Republic", ""),
    "64": SmsCountry("64", "LK", "94", 6, 13, "Sri Lanka", ""),
    "65": SmsCountry("65", "PE", "51", 6, 13, "Peru", ""),
    "66": SmsCountry("66", "PK", "92", 6, 13, "Pakistan", ""),
    "67": SmsCountry("67", "NZ", "64", 6, 13, "New Zealand", ""),
    "68": SmsCountry("68", "GN", "224", 6, 13, "Guinea", ""),
    "69": SmsCountry("69", "ML", "223", 6, 13, "Mali", ""),
    "70": SmsCountry("70", "VE", "58", 6, 13, "Venezuela", ""),
    "71": SmsCountry("71", "ET", "251", 6, 13, "Ethiopia", ""),
    "72": SmsCountry("72", "MN", "976", 6, 13, "Mongolia", ""),
    "73": SmsCountry("73", "BR", "55", 6, 13, "Brazil", "brazil"),
    "74": SmsCountry("74", "AF", "93", 6, 13, "Afghanistan", ""),
    "75": SmsCountry("75", "UG", "256", 6, 13, "Uganda", ""),
    "76": SmsCountry("76", "AO", "244", 6, 13, "Angola", ""),
    "77": SmsCountry("77", "CY", "357", 6, 13, "Cyprus", ""),
    "78": SmsCountry("78", "FR", "33", 6, 13, "France", ""),
    "79": SmsCountry("79", "PG", "675", 6, 13, "Papua new gvineya", ""),
    "80": SmsCountry("80", "MZ", "258", 6, 13, "Mozambique", ""),
    "81": SmsCountry("81", "NP", "977", 6, 13, "Nepal", ""),
    "82": SmsCountry("82", "BE", "32", 6, 13, "Belgium", ""),
    "83": SmsCountry("83", "BG", "359", 6, 13, "Bulgaria", ""),
    "84": SmsCountry("84", "HU", "36", 6, 13, "Hungary", ""),
    "85": SmsCountry("85", "MD", "373", 6, 13, "Moldova, Republic of", ""),
    "86": SmsCountry("86", "IT", "39", 6, 13, "Italy", ""),
    "87": SmsCountry("87", "PY", "595", 6, 13, "Paraguay", ""),
    "88": SmsCountry("88", "HN", "504", 6, 13, "Honduras", ""),
    "89": SmsCountry("89", "TN", "216", 6, 13, "Tunisia", ""),
    "90": SmsCountry("90", "NI", "505", 6, 13, "Nicaragua", ""),
    "91": SmsCountry("91", "TL", "670", 6, 13, "Timor-Leste", ""),
    "92": SmsCountry("92", "BO", "591", 6, 13, "Bolivia", ""),
    "93": SmsCountry("93", "CR", "506", 6, 13, "Costa Rica", ""),
    "94": SmsCountry("94", "GT", "502", 6, 13, "Guatemala", ""),
    "95": SmsCountry("95", "AE", "971", 6, 13, "United Arab Emirates", ""),
    "96": SmsCountry("96", "ZW", "263", 6, 13, "Zimbabwe", ""),
    "97": SmsCountry("97", "PR", "1", 10, 10, "Puerto Rico", ""),
    "99": SmsCountry("99", "TG", "228", 6, 13, "Togo", ""),
    "100": SmsCountry("100", "KW", "965", 6, 13, "Kuwait", ""),
    "101": SmsCountry("101", "SV", "503", 6, 13, "El Salvador", ""),
    "102": SmsCountry("102", "LY", "218", 6, 13, "Libya", ""),
    "103": SmsCountry("103", "JM", "1", 10, 10, "Jamaica", ""),
    "104": SmsCountry("104", "TT", "1", 10, 10, "Trinidad and Tobago", ""),
    "105": SmsCountry("105", "EC", "593", 6, 13, "Ecuador", ""),
    "106": SmsCountry("106", "SZ", "268", 6, 13, "Swaziland", ""),
    "107": SmsCountry("107", "OM", "968", 6, 13, "Oman", ""),
    "108": SmsCountry("108", "BA", "387", 6, 13, "Bosnia and Herzegovina", ""),
    "109": SmsCountry("109", "DO", "1", 10, 10, "Dominican Republic", ""),
    "111": SmsCountry("111", "QA", "974", 6, 13, "Qatar", ""),
    "112": SmsCountry("112", "PA", "507", 6, 13, "Panama", ""),
    "113": SmsCountry("113", "CU", "53", 6, 13, "Cuba", ""),
    "114": SmsCountry("114", "MR", "222", 6, 13, "Mauritania", ""),
    "115": SmsCountry("115", "SL", "232", 6, 13, "Sierra Leone", ""),
    "116": SmsCountry("116", "JO", "962", 6, 13, "Jordan", ""),
    "117": SmsCountry("117", "PT", "351", 6, 13, "Portugal", ""),
    "118": SmsCountry("118", "BB", "1", 10, 10, "Barbados", ""),
    "119": SmsCountry("119", "BI", "257", 6, 13, "Burundi", ""),
    "120": SmsCountry("120", "BJ", "229", 6, 13, "Benin", ""),
    "121": SmsCountry("121", "BN", "673", 6, 13, "Brunei Darussalam", ""),
    "122": SmsCountry("122", "BS", "1", 10, 10, "Bahamas", ""),
    "123": SmsCountry("123", "BW", "267", 6, 13, "Botswana", ""),
    "124": SmsCountry("124", "BZ", "501", 6, 13, "Belize", ""),
    "125": SmsCountry("125", "CF", "236", 6, 13, "Central African Republic", ""),
    "126": SmsCountry("126", "DM", "1", 10, 10, "Dominica", ""),
    "127": SmsCountry("127", "GD", "1", 10, 10, "Grenada", ""),
    "128": SmsCountry("128", "GE", "995", 6, 13, "Georgia", ""),
    "129": SmsCountry("129", "GR", "30", 6, 13, "Greece", ""),
    "130": SmsCountry("130", "GW", "245", 6, 13, "Guinea-Bissau", ""),
    "131": SmsCountry("131", "GY", "592", 6, 13, "Guyana", ""),
    "132": SmsCountry("132", "IS", "354", 6, 13, "Iceland", ""),
    "133": SmsCountry("133", "KM", "269", 6, 13, "Comoros", ""),
    "134": SmsCountry("134", "KN", "1", 10, 10, "Saint Kitts and Nevis", ""),
    "135": SmsCountry("135", "LR", "231", 6, 13, "Liberia", ""),
    "136": SmsCountry("136", "LS", "266", 6, 13, "Lesotho", ""),
    "137": SmsCountry("137", "MW", "265", 6, 13, "Malawi", ""),
    "138": SmsCountry("138", "NA", "264", 6, 13, "Namibia", ""),
    "139": SmsCountry("139", "NE", "227", 6, 13, "Niger", ""),
    "140": SmsCountry("140", "RW", "250", 6, 13, "Rwanda", ""),
    "141": SmsCountry("141", "SK", "421", 6, 13, "Slovakia", ""),
    "142": SmsCountry("142", "SR", "597", 6, 13, "Suriname", ""),
    "143": SmsCountry("143", "TJ", "992", 6, 13, "Tajikistan", ""),
    "144": SmsCountry("144", "MC", "377", 6, 13, "Monaco", ""),
    "145": SmsCountry("145", "BH", "973", 6, 13, "Bahrain", ""),
    "146": SmsCountry("146", "RE", "262", 6, 13, "Reunion", ""),
    "147": SmsCountry("147", "ZM", "260", 6, 13, "Zambia", ""),
    "148": SmsCountry("148", "AM", "374", 6, 13, "Armenia", ""),
    "149": SmsCountry("149", "SO", "252", 6, 13, "Somalia", ""),
    "150": SmsCountry("150", "CG", "242", 6, 13, "Congo", ""),
    "151": SmsCountry("151", "CL", "56", 9, 9, "Chile", "chile"),
    "152": SmsCountry("152", "BF", "226", 6, 13, "Burkina Faso", ""),
    "153": SmsCountry("153", "LB", "961", 6, 13, "Lebanon", ""),
    "154": SmsCountry("154", "GA", "241", 6, 13, "Gabon", ""),
    "155": SmsCountry("155", "AL", "355", 6, 13, "Albania", ""),
    "156": SmsCountry("156", "UY", "598", 6, 13, "Uruguay", ""),
    "157": SmsCountry("157", "MU", "230", 6, 13, "Mauritius", ""),
    "158": SmsCountry("158", "BT", "975", 6, 13, "Bhutan", ""),
    "159": SmsCountry("159", "MV", "960", 6, 13, "Maldives", ""),
    "160": SmsCountry("160", "GP", "590", 6, 13, "Guadeloupe", ""),
    "161": SmsCountry("161", "TM", "993", 6, 13, "Turkmenistan", ""),
    "162": SmsCountry("162", "GF", "594", 6, 13, "French Guiana", ""),
    "163": SmsCountry("163", "FI", "358", 6, 13, "Finland", ""),
    "164": SmsCountry("164", "LC", "1", 10, 10, "Saint Lucia", ""),
    "165": SmsCountry("165", "LU", "352", 6, 13, "Luxembourg", ""),
    "166": SmsCountry("166", "VC", "1", 10, 10, "Saint Vincent", ""),
    "167": SmsCountry("167", "GQ", "240", 6, 13, "Equatorial Guinea", ""),
    "168": SmsCountry("168", "DJ", "253", 6, 13, "Djibouti", ""),
    "169": SmsCountry("169", "AG", "1", 10, 10, "Antigua and Barbuda", ""),
    "170": SmsCountry("170", "KY", "1", 10, 10, "Cayman islands", ""),
    "171": SmsCountry("171", "ME", "382", 6, 13, "Montenegro", ""),
    "172": SmsCountry("172", "DK", "45", 6, 13, "Denmark", ""),
    "173": SmsCountry("173", "CH", "41", 6, 13, "Switzerland", ""),
    "174": SmsCountry("174", "NO", "47", 6, 13, "Norway", ""),
    "175": SmsCountry("175", "AU", "61", 6, 13, "Australia", ""),
    "176": SmsCountry("176", "ER", "291", 6, 13, "Eritrea", ""),
    "177": SmsCountry("177", "SS", "211", 6, 13, "South Sudan", ""),
    "178": SmsCountry("178", "ST", "239", 6, 13, "Sao Tome and Principe", ""),
    "179": SmsCountry("179", "AW", "297", 6, 13, "Aruba", ""),
    "180": SmsCountry("180", "MS", "1", 10, 10, "Montserrat", ""),
    "181": SmsCountry("181", "AI", "1", 10, 10, "Anguilla", ""),
    "183": SmsCountry("183", "MK", "389", 6, 13, "Macedonia", ""),
    "184": SmsCountry("184", "SC", "248", 6, 13, "Seychelles", ""),
    "185": SmsCountry("185", "NC", "687", 6, 13, "New Caledonia", ""),
    "186": SmsCountry("186", "CV", "238", 6, 13, "Cape Verde", ""),
    "187": SmsCountry("187", "US", "1", 10, 10, "United States", "usa"),
    "188": SmsCountry("188", "PS", "970", 6, 13, "Palestine", ""),
    "189": SmsCountry("189", "FJ", "679", 6, 13, "Fiji", ""),
    "196": SmsCountry("196", "SG", "65", 6, 13, "Singapore", ""),
    "199": SmsCountry("199", "MT", "356", 6, 13, "Malta", ""),
    "201": SmsCountry("201", "GI", "350", 6, 13, "Gibraltar", ""),
    "204": SmsCountry("204", "NU", "683", 4, 4, "Niue", ""),
    "1001": SmsCountry("1001", "JP", "81", 6, 13, "Japan", ""),
    "1002": SmsCountry("1002", "KR", "82", 6, 13, "Korea", ""),
    "1003": SmsCountry("1003", "BM", "1", 10, 10, "Bermuda", ""),
    "1004": SmsCountry("1004", "XK", "383", 6, 13, "Kosovo", ""),
    "1005": SmsCountry("1005", "LI", "423", 6, 13, "Liechtenstein", ""),
    "1006": SmsCountry("1006", "SX", "1", 10, 10, "Sint Maarten", ""),
    "1007": SmsCountry("1007", "VU", "678", 6, 13, "Vanuatu", ""),
    "1008": SmsCountry("1008", "GL", "299", 6, 13, "Greenland", ""),
    "1010": SmsCountry("1010", "SD", "249", 6, 13, "Sudan", ""),
    "1011": SmsCountry("1011", "MQ", "596", 6, 13, "Martinique", ""),
    "1333": SmsCountry("1333", "SY", "963", 6, 13, "Syrian Arab Republic", ""),
}


_PREFERRED_ALIASES = {
    "us": "187",
    "usa": "187",
    "united states": "187",
    "gb": "16",
    "uk": "16",
    "england": "16",
    "united kingdom": "16",
    "ca": "36",
    "canada": "36",
    "cl": "151",
    "chile": "151",
    "vietnam": "10",
    "viet nam": "10",
    "argentina": "39",
    "argentinas": "39",
    "laos": "25",
    "lao": "25",
    "ivory coast": "27",
    "cote divoire": "27",
    "cote d ivoire": "27",
    "czech": "63",
    "czechia": "63",
    "south korea": "1002",
    "korea": "1002",
    "eswatini": "106",
    "swaziland": "106",
    "drc": "18",
    "dr congo": "18",
    "papua new guinea": "79",
    "uk virtual": "12",
    "united states virtual": "12",
}


def _alias_key(value: str) -> str:
    return " ".join(value.strip().lower().replace("_", " ").replace("-", " ").split())


def _build_aliases() -> dict[str, str]:
    aliases: dict[str, str] = {}
    for country_id, country in sorted(COUNTRIES.items(), key=lambda item: int(item[0])):
        aliases[_alias_key(country.name)] = country_id
        aliases[_alias_key(country.iso)] = country_id
        if country.fivesim:
            aliases[_alias_key(country.fivesim)] = country_id
    aliases.update(_PREFERRED_ALIASES)
    return aliases


_ALIASES = _build_aliases()


def get_country(country_id: str) -> SmsCountry | None:
    return COUNTRIES.get(str(country_id).strip())


def normalize_country_id(raw: str) -> str:
    value = (raw or "").strip()
    if not value:
        raise ValueError("SMS country is empty")
    if value in COUNTRIES:
        return value
    key = _alias_key(value)
    found = _ALIASES.get(key)
    if found:
        return found
    raise ValueError(
        f"Unknown SMS country {raw!r}. Use an SMS-Activate country id "
        "(187 US, 16 UK, 151 Chile), an ISO code, or the country name."
    )
