import json
import os
import random
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

CONFIG_FILE = Path(__file__).parent / "config.json"
RUNTIME_DIR = Path(__file__).parent / ".runtime"
CLOAKBROWSER_SETUP_LOCK = RUNTIME_DIR / "cloakbrowser_setup.lock"


def _lock_holder_pid(lock_path: Path) -> int | None:
    try:
        raw = lock_path.read_text(encoding="utf-8").strip()
        if not raw:
            return None
        return int(raw.split()[0])
    except Exception:
        return None


def _lock_holder_alive(lock_path: Path) -> bool:
    pid = _lock_holder_pid(lock_path)
    if pid is None:
        try:
            age = time.time() - lock_path.stat().st_mtime
        except OSError:
            return False
        return age < 90.0
    try:
        import psutil

        return bool(psutil.pid_exists(pid))
    except ImportError:
        try:
            age = time.time() - lock_path.stat().st_mtime
        except OSError:
            return False
        return age < 90.0
    except Exception:
        return False


@contextmanager
def interprocess_lock(lock_path: Path, timeout: float = 120.0):
    """Cross-process mutex.

    On Windows this is a byte-range lock on a handle that stays open. The OS
    drops it when the holder exits, so a crashed worker cannot leave every
    other worker spinning on a leftover lock file. The critical section must
    stay short — callers should not scan the process table while holding it.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        yield from _interprocess_lock_windows(lock_path, timeout)
        return

    deadline = time.time() + timeout
    fd: int | None = None
    while time.time() < deadline:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as lock_file:
                fd = None
                lock_file.write(f"{os.getpid()} {time.time()}\n")
            break
        except FileExistsError:
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
                fd = None
            if not _lock_holder_alive(lock_path):
                lock_path.unlink(missing_ok=True)
                continue
            time.sleep(0.02 + random.random() * 0.03)
    else:
        raise TimeoutError(f"Timed out acquiring lock: {lock_path}")

    try:
        yield
    finally:
        lock_path.unlink(missing_ok=True)


def _interprocess_lock_windows(lock_path: Path, timeout: float):
    import msvcrt

    deadline = time.time() + timeout
    # Do not read the file here. A holder’s byte-range lock makes reads fail
    # with PermissionError, which used to abort every other worker.
    handle = open(lock_path, "a+b")
    try:
        if handle.seek(0, os.SEEK_END) == 0:
            handle.write(b"\0")
            handle.flush()
        while True:
            try:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                if time.time() >= deadline:
                    raise TimeoutError(f"Timed out acquiring lock: {lock_path}") from None
                time.sleep(0.01 + random.random() * 0.04)
        try:
            yield
        finally:
            try:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
    finally:
        handle.close()


MAX_DELAY_SECONDS = 10.0

_SMS_PROVIDER_ID_ENV_VARS = (
    "SMS_PROVIDER_IDS",
    "SMSBOWER_PROVIDER_IDS",
    "SMSPOOL_POOL",
)


def resolve_sms_provider_ids(
    *,
    config_ids: tuple[str, ...] | list[str] = (),
) -> tuple[str, ...]:
    """Env SMS_PROVIDER_IDS / SMSBOWER_PROVIDER_IDS overrides config.json lists."""
    for env_name in _SMS_PROVIDER_ID_ENV_VARS:
        raw = os.getenv(env_name, "").strip()
        if raw:
            return tuple(p.strip() for p in raw.split(",") if p.strip())
    if config_ids:
        return tuple(str(p).strip() for p in config_ids if str(p).strip())
    return ()


@dataclass(frozen=True)
class AppConfig:
    delay_min_seconds: float
    delay_max_seconds: float
    concurrent_browsers: int
    maintain_active_browser_pool: bool
    worker_shutdown_timeout_seconds: int
    max_active_browser_sessions: int
    max_simultaneous_browser_launches: int
    worker_spawn_stagger_seconds: float
    browser_launch_spacing_seconds: float
    browser_slot_wait_seconds: int
    cloakbrowser_humanize: bool
    cloakbrowser_human_preset: str
    cloakbrowser_geoip: bool
    cloakbrowser_download_read_timeout_seconds: int
    max_browser_restarts: int
    otp_wait_seconds: int
    sms_otp_wait_seconds: int
    auth_page_timeout_seconds: int
    phone_number_max_rotations: int
    phone_add_number_max_attempts: int
    scroll_ticketmaster_home_before_signup: bool
    scroll_before_signup_min_seconds: float
    scroll_before_signup_max_seconds: float
    read_signup_disclaimer_before_check: bool
    read_signup_disclaimer_min_seconds: float
    read_signup_disclaimer_max_seconds: float
    visit_spotify_before_ticketmaster: bool
    spotify_warmup_url: str
    spotify_warmup_min_seconds: float
    spotify_warmup_max_seconds: float
    sms_provider: str
    sms_provider_ids: tuple[str, ...]
    sms_get_number_retry_seconds: float
    sms_get_number_max_wait_seconds: float
    sms_wait_until_number: bool
    sms_countries: tuple[str, ...]


def _clamp_delay(value: float) -> float:
    return max(0.0, min(float(value), MAX_DELAY_SECONDS))


def load_config(path: Path = CONFIG_FILE) -> AppConfig:
    defaults = {
        "delay_min_seconds": 0.2,
        "delay_max_seconds": 0.5,
        "concurrent_browsers": 1,
        "maintain_active_browser_pool": True,
        "worker_shutdown_timeout_seconds": 900,
        "max_active_browser_sessions": 0,
        "max_simultaneous_browser_launches": 0,
        "worker_spawn_stagger_seconds": 12.0,
        "browser_launch_spacing_seconds": 3.0,
        "browser_slot_wait_seconds": 600,
        "cloakbrowser_humanize": True,
        "cloakbrowser_human_preset": "careful",
        "cloakbrowser_geoip": True,
        "cloakbrowser_download_read_timeout_seconds": 1800,
        "max_browser_restarts": 5,
        "otp_wait_seconds": 300,
        "sms_otp_wait_seconds": 180,
        "auth_page_timeout_seconds": 360,
        "phone_number_max_rotations": 5,
        "phone_add_number_max_attempts": 5,
        "scroll_ticketmaster_home_before_signup": True,
        "scroll_before_signup_min_seconds": 6.0,
        "scroll_before_signup_max_seconds": 18.0,
        "read_signup_disclaimer_before_check": True,
        "read_signup_disclaimer_min_seconds": 3.0,
        "read_signup_disclaimer_max_seconds": 10.0,
        "visit_spotify_before_ticketmaster": False,
        "spotify_warmup_url": "https://open.spotify.com/",
        "spotify_warmup_min_seconds": 4.0,
        "spotify_warmup_max_seconds": 12.0,
        "sms_provider": "",
        "sms_provider_ids": [],
        "smsbower_provider_ids": [],
        "sms_get_number_retry_seconds": 10.0,
        "sms_get_number_max_wait_seconds": 120.0,
        "sms_wait_until_number": False,
        "sms_countries": [],
    }

    data = defaults.copy()
    if path.exists():
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            raise ValueError(f"{path} must contain a JSON object")
        data.update(loaded)

    delay_min = _clamp_delay(data.get("delay_min_seconds", defaults["delay_min_seconds"]))
    delay_max = _clamp_delay(data.get("delay_max_seconds", defaults["delay_max_seconds"]))
    if delay_min > delay_max:
        delay_min, delay_max = delay_max, delay_min

    concurrent_browsers = int(data.get("concurrent_browsers", defaults["concurrent_browsers"]))
    if concurrent_browsers < 1:
        raise ValueError("concurrent_browsers must be at least 1")

    maintain_active_browser_pool = bool(
        data.get(
            "maintain_active_browser_pool",
            defaults["maintain_active_browser_pool"],
        )
    )

    worker_shutdown_timeout_seconds = int(
        data.get(
            "worker_shutdown_timeout_seconds",
            defaults["worker_shutdown_timeout_seconds"],
        )
    )
    if worker_shutdown_timeout_seconds < 60:
        raise ValueError("worker_shutdown_timeout_seconds must be at least 60")

    max_active_browser_sessions = int(
        data.get("max_active_browser_sessions", defaults["max_active_browser_sessions"])
    )
    if max_active_browser_sessions < 0:
        raise ValueError("max_active_browser_sessions must be 0 or greater")

    max_simultaneous_browser_launches = int(
        data.get(
            "max_simultaneous_browser_launches",
            defaults["max_simultaneous_browser_launches"],
        )
    )
    if max_simultaneous_browser_launches < 0:
        raise ValueError("max_simultaneous_browser_launches must be 0 or greater")
    if max_simultaneous_browser_launches > 20:
        raise ValueError("max_simultaneous_browser_launches must be 20 or less")

    worker_spawn_stagger_seconds = float(
        data.get("worker_spawn_stagger_seconds", defaults["worker_spawn_stagger_seconds"])
    )
    if worker_spawn_stagger_seconds < 0:
        raise ValueError("worker_spawn_stagger_seconds must be 0 or greater")

    browser_launch_spacing_seconds = float(
        data.get(
            "browser_launch_spacing_seconds",
            defaults["browser_launch_spacing_seconds"],
        )
    )
    if browser_launch_spacing_seconds < 0:
        raise ValueError("browser_launch_spacing_seconds must be 0 or greater")

    browser_slot_wait_seconds = int(
        data.get("browser_slot_wait_seconds", defaults["browser_slot_wait_seconds"])
    )
    if browser_slot_wait_seconds < 60:
        raise ValueError("browser_slot_wait_seconds must be at least 60")

    human_preset = str(data.get("cloakbrowser_human_preset", defaults["cloakbrowser_human_preset"]))
    if human_preset not in ("default", "careful"):
        raise ValueError("cloakbrowser_human_preset must be 'default' or 'careful'")

    max_browser_restarts = int(data.get("max_browser_restarts", defaults["max_browser_restarts"]))
    if max_browser_restarts < 0:
        raise ValueError("max_browser_restarts must be 0 or greater")

    otp_wait_seconds = int(data.get("otp_wait_seconds", defaults["otp_wait_seconds"]))
    if otp_wait_seconds < 60:
        raise ValueError("otp_wait_seconds must be at least 60")

    sms_otp_wait_seconds = int(
        data.get("sms_otp_wait_seconds", defaults["sms_otp_wait_seconds"])
    )
    if sms_otp_wait_seconds < 60:
        raise ValueError("sms_otp_wait_seconds must be at least 60")

    auth_page_timeout_seconds = int(
        data.get("auth_page_timeout_seconds", defaults["auth_page_timeout_seconds"])
    )
    if auth_page_timeout_seconds < 120:
        raise ValueError("auth_page_timeout_seconds must be at least 120")

    phone_number_max_rotations = int(
        data.get("phone_number_max_rotations", defaults["phone_number_max_rotations"])
    )
    if phone_number_max_rotations < 1:
        raise ValueError("phone_number_max_rotations must be at least 1")

    phone_add_number_max_attempts = int(
        data.get("phone_add_number_max_attempts", defaults["phone_add_number_max_attempts"])
    )
    if phone_add_number_max_attempts < 1:
        raise ValueError("phone_add_number_max_attempts must be at least 1")
    if phone_add_number_max_attempts > 15:
        raise ValueError("phone_add_number_max_attempts must be 15 or less")

    scroll_ticketmaster_home_before_signup = bool(
        data.get(
            "scroll_ticketmaster_home_before_signup",
            defaults["scroll_ticketmaster_home_before_signup"],
        )
    )
    scroll_before_signup_min_seconds = float(
        data.get(
            "scroll_before_signup_min_seconds",
            defaults["scroll_before_signup_min_seconds"],
        )
    )
    scroll_before_signup_max_seconds = float(
        data.get(
            "scroll_before_signup_max_seconds",
            defaults["scroll_before_signup_max_seconds"],
        )
    )
    if scroll_before_signup_min_seconds < 0:
        raise ValueError("scroll_before_signup_min_seconds must be 0 or greater")
    if scroll_before_signup_max_seconds < 0:
        raise ValueError("scroll_before_signup_max_seconds must be 0 or greater")
    if scroll_before_signup_min_seconds > scroll_before_signup_max_seconds:
        scroll_before_signup_min_seconds, scroll_before_signup_max_seconds = (
            scroll_before_signup_max_seconds,
            scroll_before_signup_min_seconds,
        )

    read_signup_disclaimer_before_check = bool(
        data.get(
            "read_signup_disclaimer_before_check",
            defaults["read_signup_disclaimer_before_check"],
        )
    )
    read_signup_disclaimer_min_seconds = float(
        data.get(
            "read_signup_disclaimer_min_seconds",
            defaults["read_signup_disclaimer_min_seconds"],
        )
    )
    read_signup_disclaimer_max_seconds = float(
        data.get(
            "read_signup_disclaimer_max_seconds",
            defaults["read_signup_disclaimer_max_seconds"],
        )
    )
    if read_signup_disclaimer_min_seconds < 0:
        raise ValueError("read_signup_disclaimer_min_seconds must be 0 or greater")
    if read_signup_disclaimer_max_seconds < 0:
        raise ValueError("read_signup_disclaimer_max_seconds must be 0 or greater")
    if read_signup_disclaimer_min_seconds > read_signup_disclaimer_max_seconds:
        read_signup_disclaimer_min_seconds, read_signup_disclaimer_max_seconds = (
            read_signup_disclaimer_max_seconds,
            read_signup_disclaimer_min_seconds,
        )

    visit_spotify_before_ticketmaster = bool(
        data.get(
            "visit_spotify_before_ticketmaster",
            defaults["visit_spotify_before_ticketmaster"],
        )
    )
    spotify_warmup_url = str(
        data.get("spotify_warmup_url", defaults["spotify_warmup_url"])
    ).strip()
    if not spotify_warmup_url:
        spotify_warmup_url = str(defaults["spotify_warmup_url"])
    spotify_warmup_min_seconds = float(
        data.get("spotify_warmup_min_seconds", defaults["spotify_warmup_min_seconds"])
    )
    spotify_warmup_max_seconds = float(
        data.get("spotify_warmup_max_seconds", defaults["spotify_warmup_max_seconds"])
    )
    if spotify_warmup_min_seconds < 0:
        raise ValueError("spotify_warmup_min_seconds must be 0 or greater")
    if spotify_warmup_max_seconds < 0:
        raise ValueError("spotify_warmup_max_seconds must be 0 or greater")
    if spotify_warmup_min_seconds > spotify_warmup_max_seconds:
        spotify_warmup_min_seconds, spotify_warmup_max_seconds = (
            spotify_warmup_max_seconds,
            spotify_warmup_min_seconds,
        )

    raw_provider_ids = data.get("sms_provider_ids") or data.get(
        "smsbower_provider_ids", defaults["sms_provider_ids"]
    )
    provider_ids: list[str] = []
    if isinstance(raw_provider_ids, str):
        provider_ids = [p.strip() for p in raw_provider_ids.split(",") if p.strip()]
    elif isinstance(raw_provider_ids, list):
        provider_ids = [str(p).strip() for p in raw_provider_ids if str(p).strip()]

    provider_ids = list(
        resolve_sms_provider_ids(config_ids=provider_ids)
    )

    env_provider = os.getenv("SMS_PROVIDER", "").strip()
    sms_provider = env_provider or str(data.get("sms_provider", defaults["sms_provider"])).strip()
    if not sms_provider:
        sms_provider = "smsbower"

    sms_get_number_retry_seconds = float(
        data.get(
            "sms_get_number_retry_seconds",
            defaults["sms_get_number_retry_seconds"],
        )
    )
    if os.getenv("SMS_GET_NUMBER_RETRY_SECONDS", "").strip():
        sms_get_number_retry_seconds = float(os.environ["SMS_GET_NUMBER_RETRY_SECONDS"])
    if sms_get_number_retry_seconds < 1.0:
        raise ValueError("sms_get_number_retry_seconds must be at least 1")

    sms_get_number_max_wait_seconds = float(
        data.get(
            "sms_get_number_max_wait_seconds",
            defaults["sms_get_number_max_wait_seconds"],
        )
    )
    if os.getenv("SMS_GET_NUMBER_MAX_WAIT_SECONDS", "").strip():
        sms_get_number_max_wait_seconds = float(os.environ["SMS_GET_NUMBER_MAX_WAIT_SECONDS"])
    if sms_get_number_max_wait_seconds < 5.0:
        raise ValueError("sms_get_number_max_wait_seconds must be at least 5")

    raw_wait_until = data.get("sms_wait_until_number", defaults["sms_wait_until_number"])
    if isinstance(raw_wait_until, str):
        sms_wait_until_number = raw_wait_until.strip().lower() in {"1", "true", "yes", "on"}
    else:
        sms_wait_until_number = bool(raw_wait_until)

    raw_countries = data.get("sms_countries", defaults["sms_countries"])
    sms_countries: list[str] = []
    if isinstance(raw_countries, str):
        sms_countries = [part.strip() for part in raw_countries.split(",") if part.strip()]
    elif isinstance(raw_countries, list):
        sms_countries = [str(part).strip() for part in raw_countries if str(part).strip()]

    return AppConfig(
        delay_min_seconds=delay_min,
        delay_max_seconds=delay_max,
        concurrent_browsers=concurrent_browsers,
        maintain_active_browser_pool=maintain_active_browser_pool,
        worker_shutdown_timeout_seconds=worker_shutdown_timeout_seconds,
        max_active_browser_sessions=max_active_browser_sessions,
        max_simultaneous_browser_launches=max_simultaneous_browser_launches,
        worker_spawn_stagger_seconds=worker_spawn_stagger_seconds,
        browser_launch_spacing_seconds=browser_launch_spacing_seconds,
        browser_slot_wait_seconds=browser_slot_wait_seconds,
        cloakbrowser_humanize=bool(data.get("cloakbrowser_humanize", defaults["cloakbrowser_humanize"])),
        cloakbrowser_human_preset=human_preset,
        cloakbrowser_geoip=bool(data.get("cloakbrowser_geoip", defaults["cloakbrowser_geoip"])),
        cloakbrowser_download_read_timeout_seconds=max(
            60,
            int(data.get(
                "cloakbrowser_download_read_timeout_seconds",
                defaults["cloakbrowser_download_read_timeout_seconds"],
            )),
        ),
        max_browser_restarts=max_browser_restarts,
        otp_wait_seconds=otp_wait_seconds,
        sms_otp_wait_seconds=sms_otp_wait_seconds,
        auth_page_timeout_seconds=auth_page_timeout_seconds,
        phone_number_max_rotations=phone_number_max_rotations,
        phone_add_number_max_attempts=phone_add_number_max_attempts,
        scroll_ticketmaster_home_before_signup=scroll_ticketmaster_home_before_signup,
        scroll_before_signup_min_seconds=scroll_before_signup_min_seconds,
        scroll_before_signup_max_seconds=scroll_before_signup_max_seconds,
        read_signup_disclaimer_before_check=read_signup_disclaimer_before_check,
        read_signup_disclaimer_min_seconds=read_signup_disclaimer_min_seconds,
        read_signup_disclaimer_max_seconds=read_signup_disclaimer_max_seconds,
        visit_spotify_before_ticketmaster=visit_spotify_before_ticketmaster,
        spotify_warmup_url=spotify_warmup_url,
        spotify_warmup_min_seconds=spotify_warmup_min_seconds,
        spotify_warmup_max_seconds=spotify_warmup_max_seconds,
        sms_provider=sms_provider.lower(),
        sms_provider_ids=tuple(provider_ids),
        sms_get_number_retry_seconds=sms_get_number_retry_seconds,
        sms_get_number_max_wait_seconds=sms_get_number_max_wait_seconds,
        sms_wait_until_number=sms_wait_until_number,
        sms_countries=tuple(sms_countries),
    )
