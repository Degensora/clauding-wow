"""Backward-compatible re-exports; use phone_sms.create_phone_sms_client for all providers."""

from phone_sms import (
    DEFAULT_PHONE_NUMBER_MAX_ROTATIONS,
    HANDLER_COUNTRY_PROFILES as SMSBOWER_COUNTRY_PROFILES,
    HandlerApiSmsClient,
    PhoneActivation,
    PhoneCountryProfile,
    create_phone_sms_client,
    parse_ticketmaster_phone,
)

SmsBowerClient = HandlerApiSmsClient
DEFAULT_UNSUPPORTED_NUMBER_MAX_ATTEMPTS = DEFAULT_PHONE_NUMBER_MAX_ROTATIONS


def create_smsbower_client(
    provider_ids: tuple[str, ...] | None = None,
):
    return create_phone_sms_client(provider_ids=provider_ids)


def format_us_phone_input(phone_number: str) -> str:
    profile = PhoneCountryProfile("187", "US", "1", "United States", 10)
    _, national = parse_ticketmaster_phone(phone_number, profile)
    return national
