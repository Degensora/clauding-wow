from __future__ import annotations

import os

import random

import re

import secrets

import shutil

import subprocess

import sys

import tempfile

import threading

import time

from collections.abc import Callable
from typing import Literal

from dataclasses import dataclass

from pathlib import Path


from cloakbrowser import ensure_binary, launch_persistent_context
from config import CLOAKBROWSER_SETUP_LOCK, RUNTIME_DIR, interprocess_lock
from process_cleanup import kill_browser_child_processes
from playwright.sync_api import BrowserContext, Locator, Page, TimeoutError as PlaywrightTimeoutError, expect

TmPhoneEntryMode = Literal["us", "ca", "other"]

TMPT_WARMUP_URL = "https://www.ticketmaster.com/"
TM_HOME_URL = "https://www.ticketmaster.com/"
DEFAULT_SPOTIFY_WARMUP_URL = "https://open.spotify.com/"

NAVIGATION_TIMEOUT_MS = 120_000
BAP_CLEAR_MAX_ATTEMPTS = 5
_BAP_AUTO_REFRESH_WAIT_SECONDS = (2.0, 3.5)
_AUTH_HOST_RE = re.compile(r"^https://auth\.ticketmaster\.com/", re.I)

_TM_BLOCK_MARKERS = (
    "YOUR BROWSING ACTIVITY HAS BEEN PAUSED",
    "BROWSING ACTIVITY HAS BEEN PAUSED",
    "We've detected unusual behavior",
    "unusual behavior on either your network or your browser",
)

_OTP_VALIDATION_ERROR_MARKERS = (
    "Error when Validating Phone/Email",
    "Unexpected error on OTP process",
    "dualVerification",
)

_TM_STORAGE_ORIGINS = (
    "https://www.ticketmaster.com",
    "https://ticketmaster.com",
    "https://auth.ticketmaster.com",
    "https://identity.ticketmaster.com",
)



class BrowsingPausedRestart(Exception):

    """Raised when Ticketmaster pauses browsing; caller should restart the browser."""



class OtpValidationRestart(Exception):

    """Raised when Ticketmaster OTP validation fails; caller should restart the browser."""



class InvalidOtpCode(Exception):

    """The code was entered and Ticketmaster rejected it. Fetch a different code."""



class SessionInterruptedRestart(Exception):

    """Phone verification session died. Close this browser and start the signup over."""



class PhoneNumberUnsupportedError(Exception):

    """Raised when Ticketmaster rejects the phone number (unsupported type, burned number, etc.)."""


class PhoneVerifyRetry(Exception):

    """Attention dialog was dismissed. Enter the same number and verify again."""



class PhoneNumberSessionRestart(Exception):

    """All phone numbers were rejected; restart browser session with a new proxy."""


class ExistingTicketmasterAccountError(Exception):

    """Email already registered — TM shows sign-in password step, not signup."""


_cloakbrowser_humanize = True

_cloakbrowser_human_preset = "careful"

_cloakbrowser_geoip = True

_cloakbrowser_ready = False

_cloakbrowser_setup_lock = threading.Lock()

_cloakbrowser_download_patched = False

_cloakbrowser_download_read_timeout_seconds = 1800

CLOAKBROWSER_READY_MARKER = RUNTIME_DIR / "cloakbrowser_ready.marker"

_DESKTOP_VIEWPORTS = (
    {"width": 1920, "height": 1080},
    {"width": 1536, "height": 864},
    {"width": 1440, "height": 900},
    {"width": 1366, "height": 768},
    {"width": 1280, "height": 720},
)

_US_TIMEZONES = (
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "America/Phoenix",
)



def configure_cloakbrowser(

    humanize: bool = True,

    human_preset: str = "careful",

    geoip: bool = True,

    download_read_timeout_seconds: int = 1800,

) -> None:

    global _cloakbrowser_humanize, _cloakbrowser_human_preset, _cloakbrowser_geoip

    global _cloakbrowser_download_read_timeout_seconds

    if human_preset not in ("default", "careful"):
        raise ValueError("human_preset must be 'default' or 'careful'")

    _cloakbrowser_humanize = humanize

    _cloakbrowser_human_preset = human_preset

    _cloakbrowser_geoip = geoip

    _cloakbrowser_download_read_timeout_seconds = max(60, download_read_timeout_seconds)



def _patch_cloakbrowser_downloads() -> None:

    """Use longer timeouts and resume partial CloakBrowser downloads."""

    global _cloakbrowser_download_patched

    if _cloakbrowser_download_patched:

        return



    import httpx

    import cloakbrowser.download as cloak_download



    read_timeout = float(_cloakbrowser_download_read_timeout_seconds)

    cloak_download.DOWNLOAD_TIMEOUT = httpx.Timeout(

        connect=30.0,

        read=read_timeout,

        write=30.0,

        pool=30.0,

    )



    _last_download_url: str | None = None



    def _download_file_with_resume(url: str, dest: Path, headers: dict[str, str] | None = None) -> None:

        nonlocal _last_download_url

        destination = Path(dest)



        if _last_download_url != url and destination.exists():

            destination.unlink(missing_ok=True)



        _last_download_url = url

        resume_from = destination.stat().st_size if destination.exists() else 0

        request_headers = dict(headers or {})



        if resume_from > 0:

            request_headers["Range"] = f"bytes={resume_from}-"

            print(
                f"  Resuming CloakBrowser download from {resume_from // (1024 * 1024)} MB...",
                flush=True,
            )



        with httpx.stream(

            "GET",

            url,

            follow_redirects=True,

            timeout=cloak_download.DOWNLOAD_TIMEOUT,

            headers=request_headers,

        ) as response:

            if response.status_code == 416:

                return



            if resume_from > 0 and response.status_code not in (200, 206):

                destination.unlink(missing_ok=True)

                resume_from = 0

                request_headers.pop("Range", None)

                with httpx.stream(

                    "GET",

                    url,

                    follow_redirects=True,

                    timeout=cloak_download.DOWNLOAD_TIMEOUT,

                    headers=request_headers,

                ) as retry_response:

                    retry_response.raise_for_status()

                    total = int(retry_response.headers.get("content-length", 0) or 0)

                    downloaded = 0

                    last_logged_pct = -1

                    with destination.open("wb") as handle:

                        for chunk in retry_response.iter_bytes(chunk_size=8192):

                            handle.write(chunk)

                            downloaded += len(chunk)

                            if total > 0:

                                pct = downloaded * 100 // total

                                if pct >= last_logged_pct + 10:

                                    last_logged_pct = pct

                                    print(
                                        f"  CloakBrowser download: {pct}% "
                                        f"({downloaded // (1024 * 1024)}/{total // (1024 * 1024)} MB)",
                                        flush=True,
                                    )

                return



            response.raise_for_status()



            try:

                total = int(response.headers.get("content-length", 0) or 0)

            except (TypeError, ValueError):

                total = 0



            if response.status_code == 206:

                total += resume_from



            downloaded = resume_from if response.status_code == 206 else 0

            mode = "ab" if downloaded > 0 else "wb"

            last_logged_pct = -1



            with destination.open(mode) as handle:

                for chunk in response.iter_bytes(chunk_size=8192):

                    handle.write(chunk)

                    downloaded += len(chunk)

                    if total > 0:

                        pct = downloaded * 100 // total

                        if pct >= last_logged_pct + 10:

                            last_logged_pct = pct

                            print(
                                f"  CloakBrowser download: {pct}% "
                                f"({downloaded // (1024 * 1024)}/{total // (1024 * 1024)} MB)",
                                flush=True,
                            )



    cloak_download._download_file = _download_file_with_resume

    _cloakbrowser_download_patched = True



def _clear_incomplete_cloakbrowser_cache() -> None:

    try:

        from cloakbrowser import binary_info

        info = binary_info()

        if info.get("installed"):

            return



        cache_dir = info.get("cache_dir")

        if cache_dir and Path(cache_dir).exists():

            shutil.rmtree(cache_dir, ignore_errors=True)

    except Exception:

        pass



def ensure_cloakbrowser_ready(max_attempts: int = 3) -> None:

    """Download and verify the CloakBrowser binary once before any launches."""

    global _cloakbrowser_ready

    if _cloakbrowser_ready or CLOAKBROWSER_READY_MARKER.exists():
        _cloakbrowser_ready = True
        return

    with _cloakbrowser_setup_lock:

        if _cloakbrowser_ready or CLOAKBROWSER_READY_MARKER.exists():
            _cloakbrowser_ready = True
            return

        _patch_cloakbrowser_downloads()

        license_key = os.getenv("CLOAKBROWSER_LICENSE_KEY", "").strip() or None

        last_error: Exception | None = None

        with interprocess_lock(CLOAKBROWSER_SETUP_LOCK, timeout=900.0):
            for attempt in range(1, max_attempts + 1):
                try:
                    if attempt == 1:
                        print(
                            "Preparing CloakBrowser (first run may download ~200MB; please wait)...",
                            flush=True,
                        )
                    else:
                        print(
                            f"Retrying CloakBrowser download ({attempt}/{max_attempts})...",
                            flush=True,
                        )

                    ensure_binary(license_key=license_key)

                    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
                    CLOAKBROWSER_READY_MARKER.write_text("ok", encoding="utf-8")
                    _cloakbrowser_ready = True

                    print("CloakBrowser ready.", flush=True)
                    return

                except Exception as exc:
                    last_error = exc

                    print(f"CloakBrowser download failed: {exc}", flush=True)

                    if attempt < max_attempts:
                        time.sleep(5 * attempt)

        _clear_incomplete_cloakbrowser_cache()



        try:

            print("Trying CloakBrowser installer CLI...", flush=True)

            subprocess.run(

                [sys.executable, "-m", "cloakbrowser", "install"],

                check=True,

                timeout=max(_cloakbrowser_download_read_timeout_seconds + 300, 900),

            )

            ensure_binary(license_key=license_key)

            RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
            CLOAKBROWSER_READY_MARKER.write_text("ok", encoding="utf-8")
            _cloakbrowser_ready = True

            print("CloakBrowser ready.", flush=True)

            return

        except Exception as cli_error:

            if last_error is None:

                last_error = cli_error



        raise RuntimeError(

            "Could not prepare CloakBrowser. Download it manually with: "

            "python -m cloakbrowser install"

        ) from last_error




_step_delay_min = 0.15

_step_delay_max = 0.4

_scroll_home_before_signup = True
_scroll_before_signup_min_seconds = 6.0
_scroll_before_signup_max_seconds = 18.0

_read_signup_disclaimer_before_check = True
_read_signup_disclaimer_min_seconds = 3.0
_read_signup_disclaimer_max_seconds = 10.0

_phone_add_number_max_attempts = 5

_visit_spotify_before_ticketmaster = False
_spotify_warmup_url = DEFAULT_SPOTIFY_WARMUP_URL
_spotify_warmup_min_seconds = 4.0
_spotify_warmup_max_seconds = 12.0



def human_button(page: Page, label: str) -> Locator:

    """Humanize-safe button locator (CloakBrowser isolated-world compatible)."""

    return page.locator(f'button:has-text("{label}")').first



def human_heading(page: Page, text: str) -> Locator:

    return page.locator(f'h1:has-text("{text}"), h2:has-text("{text}"), h3:has-text("{text}")').first



def configure_step_delays(min_seconds: float, max_seconds: float) -> None:

    global _step_delay_min, _step_delay_max

    _step_delay_min = max(0.0, min_seconds)

    _step_delay_max = max(_step_delay_min, max_seconds)


def configure_home_scroll_before_signup(
    *,
    enabled: bool,
    min_seconds: float,
    max_seconds: float,
) -> None:
    global _scroll_home_before_signup
    global _scroll_before_signup_min_seconds, _scroll_before_signup_max_seconds

    _scroll_home_before_signup = enabled
    low = max(0.0, float(min_seconds))
    high = max(0.0, float(max_seconds))
    if low > high:
        low, high = high, low
    _scroll_before_signup_min_seconds = low
    _scroll_before_signup_max_seconds = high


def configure_signup_disclaimer_read(
    *,
    enabled: bool,
    min_seconds: float,
    max_seconds: float,
) -> None:
    global _read_signup_disclaimer_before_check
    global _read_signup_disclaimer_min_seconds, _read_signup_disclaimer_max_seconds

    _read_signup_disclaimer_before_check = enabled
    low = max(0.0, float(min_seconds))
    high = max(0.0, float(max_seconds))
    if low > high:
        low, high = high, low
    _read_signup_disclaimer_min_seconds = low
    _read_signup_disclaimer_max_seconds = high


def configure_phone_add_number_submits(*, max_attempts: int) -> None:
    global _phone_add_number_max_attempts
    _phone_add_number_max_attempts = max(1, min(int(max_attempts), 15))


def configure_spotify_before_ticketmaster(
    *,
    enabled: bool,
    url: str,
    min_seconds: float,
    max_seconds: float,
) -> None:
    global _visit_spotify_before_ticketmaster
    global _spotify_warmup_url, _spotify_warmup_min_seconds, _spotify_warmup_max_seconds

    _visit_spotify_before_ticketmaster = enabled
    cleaned = (url or DEFAULT_SPOTIFY_WARMUP_URL).strip()
    if not cleaned.startswith("http"):
        cleaned = f"https://{cleaned.lstrip('/')}"
    _spotify_warmup_url = cleaned
    low = max(0.0, float(min_seconds))
    high = max(0.0, float(max_seconds))
    if low > high:
        low, high = high, low
    _spotify_warmup_min_seconds = low
    _spotify_warmup_max_seconds = high


def human_pause(min_s: float | None = None, max_s: float | None = None) -> None:

    if min_s is not None and max_s is not None:

        low, high = min(min_s, max_s), max(min_s, max_s)

    elif min_s is not None:

        low, high = min_s, max(min_s, _step_delay_max)

    elif max_s is not None:

        low, high = min(_step_delay_min, max_s), max_s

    else:

        low, high = _step_delay_min, _step_delay_max

    time.sleep(random.uniform(low, high))





def human_click(locator: Locator, *, timeout: int = 10_000, allow_force: bool = True) -> None:

    """Click through CloakBrowser's humanize pipeline (Bezier move + hold timing)."""

    locator.wait_for(state="visible", timeout=timeout)

    locator.scroll_into_view_if_needed()

    human_pause(0.12, 0.28)

    try:

        locator.click(timeout=timeout)

        return

    except Exception:

        if not allow_force:

            raise



    locator.click(force=True, timeout=timeout)


def human_hover(locator: Locator, *, timeout: int = 10_000) -> None:
    locator.wait_for(state="visible", timeout=timeout)
    locator.scroll_into_view_if_needed()
    human_pause(0.18, 0.42)
    locator.hover(timeout=timeout)
    human_pause(0.12, 0.28)


def _cloak_safe_human_click(locator: Locator, *, timeout: int = 20_000) -> None:
    """Human click when CloakBrowser allows the selector; else plain Playwright click."""

    locator.wait_for(state="visible", timeout=timeout)
    locator.scroll_into_view_if_needed()
    human_pause(0.2, 0.45)
    try:
        human_click(locator, timeout=timeout, allow_force=False)
        return
    except Exception as exc:
        message = str(exc)
        if "Humanized selector" not in message and "isolated-world resolver" not in message:
            human_click(locator, timeout=timeout, allow_force=True)
            return
    print("  Using direct Playwright click (humanize-incompatible locator)...")
    human_pause(0.12, 0.28)
    locator.click(timeout=timeout)





def _try_click_targets(

    targets: list[Locator],

    is_success: Callable[[], bool],

    *,

    timeout: int = 10_000,

) -> bool:

    for target in targets:

        if target.count() == 0:

            continue



        element = target.first

        try:

            human_click(element, timeout=timeout)

        except Exception:

            try:

                element.click(force=True, timeout=timeout)

            except Exception:

                continue



        human_pause(0.2, 0.45)

        if is_success():

            return True



    return False





def click_until_visible(
    page: Page,
    click_targets: list[Locator],
    success_locator: Locator,
    *,
    attempts: int = 6,
    success_timeout_ms: int = 30_000,
) -> None:

    """Click targets until success_locator becomes visible."""

    if success_locator.count() > 0 and success_locator.first.is_visible():

        return



    def _success() -> bool:

        return success_locator.count() > 0 and success_locator.first.is_visible()



    for _ in range(attempts):

        ensure_not_blocked(page)

        if _try_click_targets(click_targets, _success, timeout=5_000):

            return



    success_locator.first.wait_for(state="visible", timeout=success_timeout_ms)





def _verify_email_button(page: Page) -> Locator:

    return page.locator('[data-bdd="verify-email-button"], button:has-text("Verify My Email")').first



def _signup_next_button(page: Page) -> Locator:

    return page.locator(

        '[data-bdd="sign-up-next-button"], [data-bdd="next-button"], button:has-text("Next")'

    ).first



def _on_signup_form(page: Page) -> bool:

    password_field = page.locator("#password-input, #password-input-input")

    next_btn = _signup_next_button(page)

    try:

        return (

            password_field.count() > 0

            and password_field.first.is_visible()

            and next_btn.count() > 0

            and next_btn.first.is_visible()

        )

    except Exception:

        return False



def _email_verification_reached(page: Page) -> bool:

    verify_btn = _verify_email_button(page)

    try:

        return (

            verify_btn.count() > 0

            and verify_btn.first.is_visible()

            and not _on_signup_form(page)

        )

    except Exception:

        return False



def verify_tm_field(page: Page, field_id: str, expected: str) -> None:

    """Ensure a Ticketmaster field has the expected value and blur it."""

    locator = resolve_tm_input(page, field_id)

    locator.wait_for(state="visible", timeout=10_000)



    if locator.input_value() != expected:

        fill_tm_field(page, field_id, expected)



    try:

        locator.press("Tab")

    except Exception:

        pass



    human_pause(0.15, 0.25)



def _signup_next_click_targets(page: Page) -> list[Locator]:

    next_btn = _signup_next_button(page)

    return [

        page.locator('[data-bdd="sign-up-next-button"]'),

        page.locator('[data-bdd="next-button"]'),

        page.locator('button[type="submit"]:has-text("Next")'),

        next_btn,

        page.locator('form button:has-text("Next")'),

    ]



def click_signup_next_button(page: Page, timeout_ms: int = 60_000) -> None:

    """Submit the signup form and wait until the email verification step appears."""

    deadline = time.time() + (timeout_ms / 1000)

    verify_btn = _verify_email_button(page)



    while time.time() < deadline:

        if _email_verification_reached(page):

            print("Reached email verification step")

            return



        if not _on_signup_form(page):

            verify_btn.first.wait_for(

                state="visible",

                timeout=max(1_000, int((deadline - time.time()) * 1000)),

            )

            print("Reached email verification step")

            return



        check_signup_disclaimer(page)



        next_btn = _signup_next_button(page)

        expect(next_btn).to_be_enabled(timeout=10_000)

        next_btn.scroll_into_view_if_needed()

        human_pause(0.25, 0.4)



        try:

            click_until_visible(

                page,

                _signup_next_click_targets(page),

                verify_btn,

                attempts=4,

                success_timeout_ms=5_000,

            )

        except Exception:

            pass



        if _email_verification_reached(page):

            print("Reached email verification step")

            return



        try:

            human_click(next_btn, timeout=5_000)

            human_pause(0.5, 0.8)

        except Exception:

            pass



        if _email_verification_reached(page):

            print("Reached email verification step")

            return



        try:

            page.keyboard.press("Enter")

            human_pause(0.5, 0.8)

        except Exception:

            pass



        if _email_verification_reached(page):

            print("Reached email verification step")

            return



        human_pause(0.4, 0.7)



    raise TimeoutError("Timed out waiting for signup form to advance after clicking Next")



def ensure_email_verification_step(page: Page, timeout_ms: int = 60_000) -> None:

    """Advance to the email verification screen if the signup form is still open."""

    dismiss_information_lost_modal(page)

    if _email_verification_reached(page):

        return



    if _on_signup_form(page):

        print("Signup form still visible - clicking Next to reach email verification...")



    click_signup_next_button(page, timeout_ms=timeout_ms)



def click_verify_email_button(page: Page) -> None:

    ensure_email_verification_step(page)



    otp_modal = page.locator('[data-bdd="asvd-otp-input"], #otp-input-input, input[autocomplete="one-time-code"]').first

    verify_btn = _verify_email_button(page)

    verify_btn.scroll_into_view_if_needed()

    human_pause(0.2, 0.3)



    click_until_visible(

        page,

        [

            page.locator('[data-bdd="verify-email-button"]'),

            verify_btn,

            human_button(page, "Verify My Email"),

        ],

        otp_modal,

    )

    print("Clicked Verify My Email - OTP modal opened")





def _add_my_phone_button(page: Page) -> Locator:

    return page.locator('[data-bdd="verify-phone-button"], button:has-text("Add My Phone")').first



def _phone_number_input(page: Page) -> Locator:
    for selector in (
        'input[type="tel"][class*="PhoneNumber__PhoneNumberInput"]',
        'input[type="tel"][pattern]',
        "#phoneNumber-input-input",
        "#phone-input-input",
        '[data-bdd="asvd-phone-input"]',
        'input[type="tel"]',
    ):
        locator = page.locator(selector).first
        try:
            if locator.count() > 0 and locator.is_visible():
                return locator
        except Exception:
            continue

    for field_id in ("phoneNumber-input", "phone-input"):
        try:
            locator = resolve_tm_input(page, field_id)
            if locator.count() > 0:
                return locator.first
        except RuntimeError:
            continue

    return page.locator(
        '#phoneNumber-input-input, #phone-input-input, [data-bdd="asvd-phone-input"], input[type="tel"]'
    ).first


def _phone_country_combobox_candidates(page: Page) -> Locator:
    return page.locator(
        'button[role="combobox"][aria-haspopup="listbox"][class*="DialCodeSelect"], '
        'button[role="combobox"][aria-haspopup="listbox"]'
    )


def _visible_phone_dial_code_combobox(page: Page) -> Locator | None:
    """Country dropdown (+1 / Other) — must be resolved at page level, not inside a nested form scope."""

    candidates = _phone_country_combobox_candidates(page)
    try:
        for idx in range(candidates.count()):
            btn = candidates.nth(idx)
            if btn.is_visible():
                return btn
    except Exception:
        pass
    return None


def _phone_form_ready(page: Page) -> bool:
    if _visible_phone_dial_code_combobox(page) is not None:
        return True
    try:
        phone_input = _phone_number_input(page)
        return phone_input.count() > 0 and phone_input.is_visible()
    except Exception:
        return False


def _phone_entry_is_open(page: Page) -> bool:
    return _phone_form_ready(page)



def ensure_phone_entry_step(page: Page, timeout_ms: int = 60_000) -> Locator:

    """Open the inline phone form and return the phone number input."""

    dismiss_phone_try_later_dialog(page)
    dismiss_information_lost_modal_until_gone(page)
    page.get_by_text("VERIFY YOUR ACCOUNT").wait_for(state="visible", timeout=timeout_ms)



    if _phone_entry_is_open(page):
        return _phone_number_input(page)

    dismiss_information_lost_modal(page)

    print("Phone entry form not open - clicking Add My Phone...")

    add_phone_btn = _add_my_phone_button(page)
    add_phone_btn.wait_for(state="visible", timeout=timeout_ms)
    add_phone_btn.scroll_into_view_if_needed()
    human_pause(0.2, 0.3)

    form_ready = page.locator(
        'button[role="combobox"][aria-haspopup="listbox"], '
        'input[type="tel"][class*="PhoneNumber__PhoneNumberInput"], '
        'input[type="tel"]'
    ).first

    click_until_visible(
        page,
        [
            page.locator('[data-bdd="verify-phone-button"]'),
            add_phone_btn,
            human_button(page, "Add My Phone"),
        ],
        form_ready,
        success_timeout_ms=timeout_ms,
    )
    print("Clicked Add My Phone - phone form opened")

    _wait_for_phone_dial_code_ui(page, timeout_ms=timeout_ms)
    combobox = _visible_phone_dial_code_combobox(page)
    if combobox is not None:
        print("Phone country combobox (+1 / Other) is visible")
    return _phone_number_input(page)



def click_add_phone_button(page: Page) -> Locator:

    return ensure_phone_entry_step(page)


def reset_phone_entry_for_next_attempt(
    page: Page,
    *,
    entry_mode: TmPhoneEntryMode | None = None,
) -> Locator:
    """Keep the phone form open; clear tel input when rotating to another number."""

    del entry_mode  # same tel field for US/CA/Other; kept for call-site clarity
    dismiss_information_lost_modal_until_gone(page)
    ensure_phone_entry_step(page)
    _wait_for_phone_dial_code_ui(page)

    phone_input = _phone_tel_input_in_form(page)
    try:
        phone_input.wait_for(state="visible", timeout=20_000)
        _clear_tel_input(phone_input)
        remaining = _read_phone_input_digits(phone_input)
        if remaining:
            print(
                f"  Phone field still has digits after clear ({remaining!r}) — clearing again..."
            )
            _clear_tel_input(phone_input)
            try:
                phone_input.fill("")
            except Exception:
                pass
        try:
            phone_input.evaluate("el => el.blur()")
        except Exception:
            pass
        print("Cleared phone field for next number rotation")
    except Exception as exc:
        print(f"  Phone field clear warning during rotation: {exc}")

    human_pause(0.35, 0.55)
    return _phone_number_input(page)





def resolve_tm_input(page: Page, field_id: str) -> Locator:

    """Resolve Ticketmaster field wrapper to the real input element."""

    for selector in (

        f"#{field_id}-input",

        f"#{field_id} input",

        f"input#{field_id}",

        f"#{field_id}",

    ):

        locator = page.locator(selector)

        if locator.count() == 0:

            continue



        target = locator.first

        tag_name = target.evaluate("el => el.tagName.toLowerCase()")

        if tag_name in ("input", "textarea"):

            return target



        inner = target.locator("input, textarea")

        if inner.count() > 0:

            return inner.first



    raise RuntimeError(f"Could not find input for #{field_id}")





def _digits_only(value: str) -> str:

    return re.sub(r"\D", "", value)



def fill_field(locator: Locator, text: str) -> None:

    locator.wait_for(state="visible")

    locator.scroll_into_view_if_needed()

    human_pause(0.15, 0.35)

    locator.click()

    human_pause(0.1, 0.25)

    locator.fill(text)

    human_pause(0.1, 0.25)



    if locator.input_value() != text:

        locator.clear()

        human_pause(0.1, 0.2)

        locator.press_sequentially(text)

        human_pause(0.15, 0.3)



    if locator.input_value() != text:

        raise RuntimeError(

            f"Failed to fill field (got {len(locator.input_value())} chars, expected {len(text)})"

        )




_OTP_INPUT_SELECTOR = (
    '[data-bdd="asvd-otp-input"], #otp-input-input, input[autocomplete="one-time-code"]'
)


def normalize_otp_code(code: str) -> str:
    digits = _digits_only(code or "")
    if len(digits) >= 6:
        return digits[:6]
    match = re.search(r"\d{6}", code or "")
    if match:
        return match.group(0)
    raise ValueError(f"Could not parse a 6-digit OTP from: {code!r}")


def otp_input_locator(page: Page) -> Locator:
    return page.locator(_OTP_INPUT_SELECTOR)


def is_otp_modal_visible(page: Page) -> bool:
    try:
        locator = otp_input_locator(page)
        return locator.count() > 0 and locator.first.is_visible()
    except Exception:
        return False


def is_phone_session_interrupted(page: Page) -> bool:
    """True for 'Your session was interrupted, please wait 60 seconds...'."""

    try:
        body_text = page.locator("body").inner_text(timeout=2_000).lower()
    except Exception:
        return False
    return "session was interrupted" in body_text


def poll_page_during_otp_wait(page: Page) -> None:
    """Keep the live browser session healthy while waiting on AYCD/SMSBower."""

    dismiss_information_lost_modal_until_gone(page)
    if is_phone_session_interrupted(page):
        raise SessionInterruptedRestart(
            "Ticketmaster phone session was interrupted — restarting browser"
        )
    _raise_if_session_blocked(page)
    if is_otp_validation_error(page):
        raise OtpValidationRestart(
            "Ticketmaster OTP validation error while waiting for the code"
        )


def _fill_otp_input(otp_input: Locator, code: str) -> None:
    otp_input.wait_for(state="visible", timeout=30_000)
    otp_input.scroll_into_view_if_needed()
    human_pause(0.15, 0.3)
    otp_input.click()
    human_pause(0.1, 0.2)
    try:
        otp_input.clear()
    except Exception:
        pass
    human_pause(0.1, 0.2)
    otp_input.press_sequentially(code, delay=random.randint(60, 120))
    human_pause(0.25, 0.45)

    entered = _digits_only(otp_input.input_value())
    if entered != code:
        otp_input.click()
        try:
            otp_input.clear()
        except Exception:
            pass
        fill_field(otp_input, code)
        entered = _digits_only(otp_input.input_value())

    if entered != code:
        raise RuntimeError(
            f"OTP field mismatch (expected {code}, got {entered or 'empty'})"
        )


def submit_otp_code(
    page: Page,
    code: str,
    modal_title: str,
    *,
    is_email: bool = True,
) -> None:
    """Enter a 6-digit OTP and confirm, reopening the modal if TM closed it."""

    normalized = normalize_otp_code(code)
    print(f"Submitting {modal_title} OTP ({len(normalized)} digits)...")

    for attempt in range(1, 4):
        poll_page_during_otp_wait(page)
        dismiss_information_lost_modal(page)
        if not is_email and attempt > 1:
            _raise_if_phone_code_must_restart(page)
            raise SessionInterruptedRestart(
                "Ticketmaster asked for the phone code again — "
                "closing this browser and starting signup over"
            )

        if not is_otp_modal_visible(page):
            if is_email:
                print("Email OTP modal not visible — reopening Verify My Email...")
                click_verify_email_button(page)
            else:
                print("Phone OTP modal not visible — waiting for Verify Your Phone...")
                wait_for_phone_otp_modal(page, timeout_ms=90_000)

        otp_input = otp_input_locator(page).first
        _fill_otp_input(otp_input, normalized)
        print(f"Entered {modal_title} OTP: {normalized}")

        confirm_btn = human_button(page, "Confirm Code")
        expect(confirm_btn).to_be_enabled(timeout=45_000)
        human_pause(0.25, 0.45)
        human_click(confirm_btn)

        try:
            page.wait_for_load_state("domcontentloaded", timeout=45_000)
        except Exception:
            pass
        human_pause(0.6, 1.0)
        if is_otp_code_invalid(page):
            raise InvalidOtpCode(
                f"{modal_title} rejected OTP {normalized}"
            )
        if not is_email:
            _raise_if_phone_code_must_restart(page)
        poll_page_during_otp_wait(page)

        if not is_otp_modal_visible(page):
            print(f"Clicked Confirm Code for {modal_title}")
            return

        if is_confirm_account_page(page) or is_verify_account_page(page):
            print(f"Clicked Confirm Code for {modal_title}")
            return

        print(
            f"OTP modal still open after Confirm Code "
            f"(attempt {attempt}/3) — retrying entry..."
        )
        human_pause(1.0, 1.5)

    raise TimeoutError(f"Failed to submit OTP for {modal_title}")


def fill_phone_field(
    locator: Locator, local_number: str, *, expected_digits: int = 10
) -> None:

    """Fill Ticketmaster's masked phone input and verify local digits."""

    local_digits = _digits_only(local_number)

    if len(local_digits) != expected_digits:

        raise ValueError(
            f"Expected a {expected_digits}-digit local phone number, got: {local_number}"
        )



    locator.wait_for(state="visible")

    human_pause(0.15, 0.35)

    _plain_tel_input_click(locator)

    human_pause(0.1, 0.25)

    locator.clear()

    human_pause(0.1, 0.2)

    locator.fill(local_digits)

    human_pause(0.2, 0.4)



    actual_digits = _digits_only(locator.input_value())

    if actual_digits.endswith(local_digits):

        return



    _plain_tel_input_click(locator)

    human_pause(0.1, 0.2)

    locator.clear()

    human_pause(0.1, 0.2)

    locator.press_sequentially(local_digits)

    human_pause(0.2, 0.4)



    actual_digits = _digits_only(locator.input_value())

    if not actual_digits.endswith(local_digits):

        raise RuntimeError(

            "Failed to fill phone field "

            f"(got {len(actual_digits)} digits, expected 10 ending with {local_digits[-4:]})"

        )





def fill_tm_field(page: Page, field_id: str, text: str) -> None:

    fill_field(resolve_tm_input(page, field_id), text)





def _disclaimer_is_checked(page: Page) -> bool:

    for selector in (

        "#opted-in-checkbox",

        "#privacyPolicyCheckbox-checkbox-input",

        '[data-bdd="create-account-disclaimer-checkbox"]',

    ):

        locator = page.locator(selector)

        if locator.count() == 0:

            continue

        target = locator.first

        try:

            if target.get_attribute("type") == "checkbox":

                return target.is_checked()

        except Exception:

            pass

    return False





def simulate_read_signup_disclaimer(page: Page, terms_anchor: Locator) -> None:
    """Pause on the Terms/Privacy acknowledgement like a user reading before checking."""

    if not _read_signup_disclaimer_before_check:
        return

    min_s = _read_signup_disclaimer_min_seconds
    max_s = _read_signup_disclaimer_max_seconds
    if max_s <= 0:
        return

    duration = random.uniform(min_s, max_s) if max_s > min_s else max_s
    print(
        f"Reading signup disclaimer before acknowledging "
        f"({duration:.1f}s, config range {min_s:.0f}–{max_s:.0f}s)..."
    )

    try:
        box = terms_anchor.bounding_box()
        if box:
            pointer_x = int(box["x"] + box["width"] * random.uniform(0.15, 0.85))
            pointer_y = int(box["y"] + box["height"] * random.uniform(0.2, 0.8))
            page.mouse.move(pointer_x, pointer_y)
    except Exception:
        pass

    deadline = time.time() + duration
    while time.time() < deadline:
        if random.random() < 0.35:
            try:
                terms_anchor.scroll_into_view_if_needed()
            except Exception:
                pass
        if random.random() < 0.4:
            delta = random.randint(40, 160) * random.choice((1, 1, -1))
            try:
                page.mouse.wheel(0, delta)
            except Exception:
                pass
        human_pause(0.45, 1.2)

    human_pause(0.25, 0.55)
    print("Finished reading disclaimer — checking acknowledgement box.")


def check_signup_disclaimer(page: Page) -> None:

    """Click the Terms of Use disclaimer checkbox and confirm it is checked."""

    terms_anchor = page.locator(

        '[data-bdd="create-account-disclaimer-checkbox"], '

        "#opted-in-checkbox-input, "

        "#privacyPolicyCheckbox-checkbox-input"

    ).first

    terms_anchor.wait_for(state="visible", timeout=10_000)

    terms_anchor.scroll_into_view_if_needed()

    simulate_read_signup_disclaimer(page, terms_anchor)

    human_pause(0.2, 0.3)



    if _disclaimer_is_checked(page):

        print("Terms checkbox already checked")

        return



    click_targets = [

        page.locator('[data-bdd="create-account-disclaimer-checkbox"]'),

        page.locator("#opted-in-checkbox"),

        page.locator("#privacyPolicyCheckbox-checkbox-input"),

        page.locator('label[for="privacyPolicyCheckbox-checkbox-input"] span[class*="CustomCheckbox"]'),

        page.locator('label[for="privacyPolicyCheckbox-checkbox-input"]'),

    ]



    if _try_click_targets(click_targets, lambda: _disclaimer_is_checked(page)):

        print("Clicked Terms of Use checkbox")



    next_btn = _signup_next_button(page)

    expect(next_btn).to_be_enabled(timeout=10_000)

    print("Confirmed Terms of Use checkbox is checked (Next button enabled)")





def _phone_form_scope(page: Page) -> Locator:

    scoped = page.locator("div, section, form, [role='dialog']").filter(

        has_text=re.compile(r"Add Your Phone Number", re.I)

    ).filter(

        has_text=re.compile(r"I agree to receive", re.I)

    )

    if scoped.count() > 0:

        return scoped.last

    return page.locator("body")



def _phone_marketing_is_checked(page: Page) -> bool:
    for selector in (
        "#opted-in-checkbox-input",
        '[data-bdd="asvd-checkbox-privacy"]',
        "#opted-in-checkbox",
    ):
        locator = page.locator(selector)
        try:
            if locator.count() == 0:
                continue
            target = locator.first
            if target.get_attribute("type") == "checkbox":
                return target.is_checked()
        except Exception:
            continue
    return False





def check_phone_marketing_consent(page: Page) -> None:
    """Check SMS marketing consent via the opted-in label / checkbox on the phone form."""

    dismiss_information_lost_modal_until_gone(page)
    human_pause(0.35, 0.55)

    page.locator(
        '#opted-in-checkbox-input, [data-bdd="asvd-checkbox-privacy"]'
    ).first.wait_for(state="attached", timeout=15_000)

    if _phone_marketing_is_checked(page):
        print("Phone marketing checkbox already checked")
    else:
        print("Checking phone marketing consent checkbox...")
        checkbox = page.locator("#opted-in-checkbox-input").first
        try:
            if checkbox.count() > 0 and checkbox.is_visible():
                checkbox.check(force=True, timeout=15_000)
                human_pause(0.35, 0.55)
        except Exception:
            pass

        if not _phone_marketing_is_checked(page):
            for locator in (
                page.locator('[data-bdd="asvd-checkbox-privacy"]'),
                page.locator('label[for="opted-in-checkbox-input"] span[class*="CustomCheckbox"]'),
                page.locator('label[for="opted-in-checkbox-input"]'),
            ):
                try:
                    if locator.count() == 0 or not locator.first.is_visible():
                        continue
                    _cloak_safe_human_click(locator.first, timeout=15_000)
                    human_pause(0.35, 0.55)
                    if _phone_marketing_is_checked(page):
                        print("Phone marketing consent checkbox checked")
                        break
                except Exception:
                    continue

    if not _phone_marketing_is_checked(page):
        raise RuntimeError("Failed to check the phone marketing consent checkbox")

    human_pause(0.25, 0.4)
    tel_after_consent = _visible_other_phone_digits(page)
    if tel_after_consent:
        print(f"Phone field after marketing consent: {_digits_only(tel_after_consent)} digit(s)")
    else:
        print("Phone field empty after marketing consent (will re-enter before submit)")

    add_number_btn = page.locator('[data-bdd="asvd-submit-button"]').first
    expect(add_number_btn).to_be_enabled(timeout=15_000)
    print("Phone marketing checkbox checked — Add Number is enabled")


_PHONE_SEND_SMS_OTP_ERROR_RE = re.compile(
    r"unable to process your request|sendSmsOtp|try again later",
    re.I,
)

_PHONE_VERIFICATION_LIMIT_RE = re.compile(
    r"reached the limit for verification attempts|limit for verification attempts",
    re.I,
)


def is_phone_verification_limit_error(page: Page) -> bool:
    """Ticketmaster burned this number: verification attempts are used up."""

    try:
        alert = page.locator('[role="alert"]').filter(has_text=_PHONE_VERIFICATION_LIMIT_RE)
        if alert.count() > 0 and alert.first.is_visible():
            return True
    except Exception:
        pass

    try:
        body = page.locator("body").inner_text(timeout=1_500)
        if _PHONE_VERIFICATION_LIMIT_RE.search(body):
            return True
    except Exception:
        pass
    return False


def is_phone_send_sms_otp_transient_error(page: Page) -> bool:
    """Red banner after Add Number when TM failed to send SMS OTP (retry confirm/Enter)."""

    try:
        alerts = page.locator('[role="alert"], [class*="Error"], [class*="error"]').filter(
            has_text=_PHONE_SEND_SMS_OTP_ERROR_RE
        )
        if alerts.count() > 0 and alerts.first.is_visible():
            return True
    except Exception:
        pass

    for marker in (
        "unable to process your request",
        "sendSmsOtp",
        "asvd-w-",
    ):
        try:
            locator = page.get_by_text(marker, exact=False)
            if locator.count() > 0 and locator.first.is_visible():
                body = page.locator("body").inner_text(timeout=1_500).lower()
                if "phone" in body or "add your phone" in body or "sendSmsOtp" in body:
                    return True
        except Exception:
            pass

    try:
        body = page.locator("body").inner_text(timeout=2_000)
        if _PHONE_SEND_SMS_OTP_ERROR_RE.search(body) and re.search(
            r"add your phone|phone number|asvd",
            body,
            re.I,
        ):
            return True
    except Exception:
        pass

    return False


def _phone_add_number_button(page: Page) -> Locator:
    return page.locator('[data-bdd="asvd-submit-button"]').first


def _submit_phone_add_number_confirm(page: Page, *, use_enter: bool) -> None:
    dismiss_information_lost_modal_until_gone(page)
    phone_input = _phone_tel_input_in_form(page)
    add_number_btn = _phone_add_number_button(page)

    if use_enter:
        print("  Confirming phone with Enter...")
        phone_input.scroll_into_view_if_needed()
        try:
            phone_input.focus()
        except Exception:
            pass
        human_pause(0.25, 0.45)
        page.keyboard.press("Enter")
        return

    add_number_btn.wait_for(state="visible", timeout=20_000)
    expect(add_number_btn).to_be_enabled(timeout=20_000)
    add_number_btn.scroll_into_view_if_needed()
    human_pause(0.3, 0.5)
    _cloak_safe_human_click(add_number_btn, timeout=20_000)


_PHONE_TRY_LATER_RE = re.compile(r"please try after sometime", re.I)


def is_phone_try_later_dialog(page: Page) -> bool:
    """Attention: Something went wrong. Please try after sometime!"""

    try:
        dialog = page.locator('[role="dialog"], [role="alertdialog"]').filter(
            has_text=_PHONE_TRY_LATER_RE
        )
        if dialog.count() > 0 and dialog.first.is_visible():
            return True
    except Exception:
        pass
    try:
        body = page.locator("body").inner_text(timeout=1_500)
    except Exception:
        return False
    return bool(
        re.search(r"something went wrong", body, re.I)
        and _PHONE_TRY_LATER_RE.search(body)
    )


def _raise_if_phone_code_must_restart(page: Page) -> None:
    """After the phone code is submitted, this dialog means the signup is stuck."""

    if not is_phone_try_later_dialog(page):
        return
    raise SessionInterruptedRestart(
        "Ticketmaster failed after the phone code (Something went wrong) — "
        "closing this browser and starting signup over"
    )


def dismiss_phone_try_later_dialog(page: Page) -> bool:
    """Click OK. Caller retries phone verification after this returns True."""

    if not is_phone_try_later_dialog(page):
        return False

    print(
        "Ticketmaster Attention: Something went wrong — clicking OK "
        "and trying phone verification again"
    )
    dialog = page.locator('[role="dialog"], [role="alertdialog"]').filter(
        has_text=_PHONE_TRY_LATER_RE
    )
    scope = dialog.first if dialog.count() > 0 else page.locator("body")
    ok = scope.get_by_role("button", name=re.compile(r"^ok$", re.I))
    try:
        if ok.count() == 0:
            ok = page.get_by_role("button", name=re.compile(r"^ok$", re.I))
        target = ok.first
        target.scroll_into_view_if_needed()
        human_pause(0.2, 0.4)
        target.click(timeout=8_000)
    except Exception as exc:
        print(f"  Could not click OK on the Attention dialog: {exc}")
        return False
    human_pause(0.5, 0.9)
    return True


def _wait_after_phone_add_number_submit(page: Page) -> None:
    for _ in range(10):
        if _phone_otp_ready(page):
            return
        if is_phone_number_unsupported(page):
            return
        if is_phone_send_sms_otp_transient_error(page):
            return
        if not _auth_loading_visible(page):
            return
        human_pause(0.35, 0.6)


def click_phone_add_number_button(page: Page, *, max_attempts: int | None = None) -> None:
    """Submit phone number (data-bdd=asvd-submit-button). Retries on sendSmsOtp errors."""

    attempts = (
        _phone_add_number_max_attempts
        if max_attempts is None
        else max(1, max_attempts)
    )

    dismiss_information_lost_modal_until_gone(page)

    phone_input = _phone_tel_input_in_form(page)
    digits = _read_phone_input_digits(phone_input)
    if not digits:
        raise RuntimeError(
            "Phone number field is empty before Add Number — cannot submit"
        )

    for attempt in range(1, attempts + 1):
        if dismiss_phone_try_later_dialog(page) and not _phone_form_ready(page):
            raise PhoneVerifyRetry(
                "Something went wrong. Please try after sometime"
            )
        dismiss_information_lost_modal_until_gone(page)
        phone_input = _phone_tel_input_in_form(page)
        if not _read_phone_input_digits(phone_input):
            raise RuntimeError(
                "Phone number field empty before Add Number confirm — cannot submit"
            )

        use_enter = attempt % 2 == 0
        method = "Enter" if use_enter else "Add Number click"
        print(
            f"Confirming phone submit ({method}) — "
            f"attempt {attempt}/{attempts}"
        )
        _submit_phone_add_number_confirm(page, use_enter=use_enter)
        _wait_after_phone_add_number_submit(page)

        if is_phone_verification_limit_error(page):
            print(
                "Ticketmaster: this phone number has reached the verification "
                "limit — not retrying Add Number"
            )
            raise PhoneNumberUnsupportedError(
                "Phone number reached the limit for verification attempts"
            )
        if _phone_otp_ready(page):
            return
        if is_phone_number_unsupported(page):
            return
        if _auth_loading_visible(page):
            return

        if is_phone_send_sms_otp_transient_error(page):
            print(
                "  Ticketmaster could not send SMS OTP yet "
                "(unable to process / sendSmsOtp) — retrying..."
            )
            human_pause(0.9, 1.5)
            if attempt < attempts:
                continue
            return

        if attempt < attempts and _phone_form_ready(page):
            print(
                "  Add Number did not open phone OTP yet — "
                "retrying confirm..."
            )
            human_pause(0.5, 0.9)
            continue
        return





_AUTH_EMAIL_INPUT_SELECTORS: tuple[str, ...] = (
    '[data-bdd="email-address-field"]',
    'input#email-input[name="email"]',
    "input#email-input",
    "#email-input-input",
    "#email-input input",
    '[data-bdd="email-input"] input',
    '[data-bdd="email-input"]',
    'input[type="email"]',
    'input[name="email"]',
    'input[autocomplete="email"]',
    'input[autocomplete="username"]',
    'input[aria-label*="Email" i]',
    'input[aria-labelledby*="email" i]',
    'input[placeholder*="email" i]',
    "form input[type=\"text\"]",
)


def find_visible_auth_email_input(page: Page) -> Locator | None:
    """Resolve TM auth email field (label-based lookup often fails under CloakBrowser)."""

    for field_id in ("email-input", "email"):
        try:
            resolved = resolve_tm_input(page, field_id)
            if resolved.is_visible():
                return resolved
        except RuntimeError:
            continue

    for selector in _AUTH_EMAIL_INPUT_SELECTORS:
        locator = page.locator(selector).first
        try:
            if locator.count() > 0 and locator.is_visible():
                return locator
        except Exception:
            continue

    try:
        labeled = page.get_by_label("Email Address", exact=False).first
        if labeled.count() > 0 and labeled.is_visible():
            return labeled
    except Exception:
        pass

    return None


def _auth_entry_reached(page: Page) -> bool:
    """True when SIGN IN OR CREATE ACCOUNT email step is ready."""

    if find_visible_auth_email_input(page) is not None:
        return True

    if not _AUTH_HOST_RE.match(page.url or ""):
        return False

    try:
        heading = page.get_by_text(re.compile(r"SIGN IN OR CREATE ACCOUNT", re.I))
        continue_btn = page.get_by_role("button", name=re.compile(r"^continue$", re.I))
        if (
            heading.count() > 0
            and heading.first.is_visible()
            and continue_btn.count() > 0
            and continue_btn.first.is_visible()
        ):
            return True
    except Exception:
        pass

    return False


def _auth_loading_visible(page: Page) -> bool:

    if _auth_entry_reached(page):
        return False

    loading_text = page.get_by_text(

        re.compile(r"Almost there|Don'?t refresh the page", re.I)

    )

    try:

        if loading_text.count() > 0 and loading_text.first.is_visible():

            return True

    except Exception:

        pass



    for selector in (

        '[class*="spinner"]',

        '[class*="Spinner"]',

        '[role="progressbar"]',

        'button[aria-busy="true"]',

        'button:has([class*="spinner"])',

        'button:has([class*="Spinner"])',

    ):

        loader = page.locator(selector)

        try:

            if loader.count() > 0 and loader.first.is_visible():

                return True

        except Exception:

            continue



    return False





def is_phone_number_unsupported(page: Page) -> bool:

    if is_phone_verification_limit_error(page):
        return True

    markers = (

        "phone number you've entered is not supported",

        "type of phone number you've entered",

        "not supported. Please try a mobile or landline",

        "Please try a mobile or landline phone number",

        "reached the limit for verification attempts",

        "limit for verification attempts",

        "not unique enough",

        "phone number is not unique",

        "number is not unique",

        "already been used",

        "already in use",

    )

    for marker in markers:

        try:

            locator = page.get_by_text(marker, exact=False)

            if locator.count() > 0 and locator.first.is_visible():

                return True

        except Exception:

            pass



    try:

        body_text = page.locator("body").inner_text(timeout=2_000).lower()

        if "not supported" in body_text and "phone" in body_text:
            return True
        if "phone" in body_text and "limit" in body_text and "verification" in body_text:
            return True
        if "phone" in body_text and "not unique" in body_text:
            return True
        if "phone" in body_text and "not supported" in body_text:
            return True

    except Exception:

        return False

    return False





_VERIFY_ACCOUNT_STUCK_SECONDS = 45
_WELCOME_STUCK_SECONDS = 45


def is_verify_account_page(page: Page) -> bool:
    try:
        heading = human_heading(page, "VERIFY YOUR ACCOUNT")
        return heading.count() > 0 and heading.is_visible()
    except Exception:
        return False


def is_confirm_account_page(page: Page) -> bool:
    try:
        heading = human_heading(page, "CONFIRM YOUR ACCOUNT")
        return heading.count() > 0 and heading.is_visible()
    except Exception:
        return False


def is_welcome_page(page: Page) -> bool:
    # Auth OAuth layout also shows a marketing "WELCOME" column — not post-signup WELCOME.
    if _AUTH_HOST_RE.match(page.url or ""):
        return False

    try:
        back_heading = human_heading(page, "WELCOME BACK")
        if back_heading.count() > 0 and back_heading.is_visible():
            return False
    except Exception:
        pass

    try:
        heading = human_heading(page, "WELCOME")
        if heading.count() == 0 or not heading.is_visible():
            return False
    except Exception:
        return False

    try:
        body_text = page.locator("body").inner_text(timeout=2_000).lower()
        return (
            "millions of live events" in body_text
            or "always safe, secure ticketing" in body_text
        )
    except Exception:
        return True


def is_session_export_ready_page(page: Page) -> bool:
    """Signup likely finished on an auth landing page — export from here."""

    return is_passkey_prompt_page(page) or is_welcome_page(page)


_TM_PORTAL_ERROR_MARKERS = (
    "we couldn't load your content",
    "couldn't load your content",
    "code: 503",
    "server is unavailable",
    "u2vydmvyig",
)


def is_tm_portal_content_error(page: Page) -> bool:
    """Ticketmaster account portal failed to render (common after signup redirect)."""

    try:
        url = (page.url or "").lower()
    except Exception:
        url = ""

    try:
        body = page.locator("body").inner_text(timeout=4_000).lower()
    except Exception:
        body = ""

    if any(marker in body for marker in _TM_PORTAL_ERROR_MARKERS):
        return True

    if "my.ticketmaster.com" in url and "couldn't load" in body:
        return True

    try:
        title = page.title().lower()
        if "couldn't load your content" in title:
            return True
    except Exception:
        pass

    return False


def recover_tm_session_for_export(page: Page) -> bool:
    """Leave my.ticketmaster 503 / error pages and refresh auth cookies for CSV export."""

    if not is_tm_portal_content_error(page):
        try:
            url = (page.url or "").lower()
            if "my.ticketmaster.com" not in url:
                return True
        except Exception:
            return True

    print("Recovering Ticketmaster session after account portal load error...")
    for locator in (
        page.get_by_role("link", name=re.compile(r"homepage", re.I)),
        page.get_by_role("button", name=re.compile(r"homepage", re.I)),
        page.get_by_text(re.compile(r"return to the homepage", re.I)),
        page.get_by_text(re.compile(r"refresh your browser", re.I)),
    ):
        try:
            if locator.count() > 0 and locator.first.is_visible():
                human_click(locator.first)
                human_pause(2.0, 3.0)
                if not is_tm_portal_content_error(page):
                    print(f"Session recovered via error-page link (now at {page.url})")
                    return True
        except Exception:
            continue

    targets = (
        "https://www.ticketmaster.com/",
    )
    for target in targets:
        try:
            page.goto(
                target,
                wait_until="domcontentloaded",
                timeout=NAVIGATION_TIMEOUT_MS,
            )
            human_pause(2.0, 3.0)
            dismiss_home_page_overlays(page)
            if not is_tm_portal_content_error(page):
                print(f"Session recovered via {target} (now at {page.url})")
                return True
        except Exception as exc:
            print(f"  Recovery navigation warning ({target}): {exc}")

    try:
        page.reload(wait_until="domcontentloaded", timeout=NAVIGATION_TIMEOUT_MS)
        human_pause(1.5, 2.5)
    except Exception as exc:
        print(f"  Recovery reload warning: {exc}")

    if is_tm_portal_content_error(page):
        print(f"Session recovery incomplete (still on {page.url})")
        return False
    print(f"Session recovered after reload ({page.url})")
    return True


_POST_SIGNUP_HOME_RE = re.compile(r"^https://(?:www\.)?ticketmaster\.com(?:/|$|\?)")


def is_post_signup_ticketmaster_home(page: Page) -> bool:
    if _POST_SIGNUP_HOME_RE.match(page.url):
        return True
    try:
        url = (page.url or "").lower()
        if "my.ticketmaster.com" in url and not is_tm_portal_content_error(page):
            return True
    except Exception:
        pass
    return _account_link_ready(page)


def _click_post_signup_primary_action(page: Page) -> bool:
    """Advance passkey or WELCOME screens. Returns True if a click was performed."""

    if is_passkey_prompt_page(page):
        return dismiss_passkey_prompt(page)

    if is_welcome_page(page):
        for locator in (
            human_button(page, "Continue"),
            page.get_by_role("button", name=re.compile(r"^continue$", re.I)),
            page.get_by_role("link", name=re.compile(r"^continue$", re.I)),
        ):
            try:
                if locator.count() > 0 and locator.first.is_visible():
                    human_click(locator.first)
                    print("Clicked Continue on WELCOME page")
                    return True
            except Exception:
                continue
        return False

    return False


def complete_post_signup_navigation(page: Page, timeout_ms: int = 120_000) -> None:
    """Click through passkey/WELCOME and wait for Ticketmaster home to finish loading."""

    print("Finishing signup — Continue / Not Right Now, then waiting for last page...")
    deadline = time.time() + (timeout_ms / 1000)
    portal_recovery_attempted = False

    while time.time() < deadline:
        dismiss_information_lost_modal(page)

        if is_passkey_prompt_page(page):
            dismiss_passkey_prompt_if_present(page, max_attempts=2)

        if is_tm_portal_content_error(page):
            if not portal_recovery_attempted:
                portal_recovery_attempted = True
                recover_tm_session_for_export(page)
                continue
            try:
                url = (page.url or "").lower()
            except Exception:
                url = ""
            if "my.ticketmaster.com" in url:
                print(
                    "my.ticketmaster.com content error (503) persists — "
                    "stopping navigation; cookie export will run next"
                )
                return

        if is_post_signup_ticketmaster_home(page):
            try:
                page.wait_for_load_state("domcontentloaded", timeout=20_000)
            except Exception:
                pass
            try:
                page.wait_for_load_state("networkidle", timeout=45_000)
            except Exception:
                pass
            dismiss_home_page_overlays(page)
            human_pause(2.0, 3.5)
            print(f"Post-signup page loaded: {page.url}")
            return

        if _click_post_signup_primary_action(page):
            human_pause(1.0, 1.8)
            try:
                page.wait_for_load_state("domcontentloaded", timeout=30_000)
            except Exception:
                pass
            time.sleep(0.5)
            continue

        time.sleep(0.5)

    if is_post_signup_ticketmaster_home(page):
        dismiss_home_page_overlays(page)
        human_pause(1.5, 2.5)
        print(f"Post-signup page loaded: {page.url}")
        return

    if is_tm_portal_content_error(page):
        print(
            "Post-signup ended on portal content error (503) — "
            f"continuing to export cookies ({page.url})"
        )
        return

    print(
        "Warning: post-signup navigation did not reach ticketmaster.com home "
        f"(last URL: {page.url})"
    )


def is_passkey_prompt_page(page: Page) -> bool:
    try:
        heading = human_heading(page, "ADD A PASSKEY")
        if heading.count() > 0 and heading.is_visible():
            return True
    except Exception:
        pass

    for marker in (
        "Sign in quickly and securely without a password",
        "Not Right Now",
        "Add Passkey",
    ):
        try:
            locator = page.get_by_text(marker, exact=False)
            if locator.count() > 0 and locator.first.is_visible():
                return True
        except Exception:
            pass

    try:
        body_text = page.locator("body").inner_text(timeout=2_000).lower()
        if "add a passkey" not in body_text:
            return False
        return (
            "not right now" in body_text
            or "not now" in body_text
            or ("welcome back" in body_text and _AUTH_HOST_RE.match(page.url or ""))
        )
    except Exception:
        return False


def dismiss_passkey_prompt(page: Page) -> bool:
    """Click Not Right Now / Skip on the ADD A PASSKEY interstitial."""

    if not is_passkey_prompt_page(page):
        return False

    dismiss_information_lost_modal_until_gone(page, max_attempts=2)

    def _try_click(target: Locator) -> bool:
        try:
            if target.count() == 0 or not target.first.is_visible():
                return False
            button = target.first
            button.scroll_into_view_if_needed()
            human_pause(0.25, 0.45)
            try:
                human_click(button, timeout=15_000, allow_force=True)
            except Exception:
                button.click(force=True, timeout=12_000)
            print("Clicked Not Right Now / Skip on passkey prompt")
            human_pause(0.85, 1.35)
            return True
        except Exception:
            return False

    skip_locators: list[Locator] = [
        page.locator('[data-bdd*="passkey"][data-bdd*="skip"]'),
        page.locator('[data-bdd*="skip-passkey"]'),
        page.locator('button:has-text("Not Right Now")'),
        page.locator('button:has-text("Not now")'),
        page.get_by_role("button", name=re.compile(r"not\s*right\s*now", re.I)),
        page.get_by_role("link", name=re.compile(r"not\s*right\s*now", re.I)),
        page.get_by_role("button", name=re.compile(r"^not\s*now$", re.I)),
        page.get_by_role("button", name=re.compile(r"^skip$", re.I)),
        page.get_by_text(re.compile(r"not\s*right\s*now", re.I)),
    ]

    for locator in skip_locators:
        if _try_click(locator):
            return True

    for _ in range(2):
        try:
            page.mouse.wheel(0, random.randint(280, 520))
        except Exception:
            pass
        human_pause(0.35, 0.55)
        for locator in skip_locators:
            if _try_click(locator):
                return True

    print("Passkey prompt visible but Not Right Now / Skip could not be clicked")
    return False


def dismiss_passkey_prompt_if_present(page: Page, *, max_attempts: int = 4) -> bool:
    """Repeatedly dismiss passkey until it is gone or attempts are exhausted."""

    dismissed = False
    for _ in range(max_attempts):
        if not is_passkey_prompt_page(page):
            return dismissed
        if dismiss_passkey_prompt(page):
            dismissed = True
            human_pause(0.6, 1.0)
        else:
            human_pause(0.4, 0.7)
    return dismissed


def is_email_verified_on_verify_page(page: Page) -> bool:
    try:
        verified = page.get_by_text("Email Verified", exact=False)
        if verified.count() > 0 and verified.first.is_visible():
            return True
    except Exception:
        pass

    try:
        body_text = page.locator("body").inner_text(timeout=2_000).lower()
        return "email verified" in body_text
    except Exception:
        return False


def is_phone_verification_pending(page: Page) -> bool:
    try:
        add_phone_btn = _add_my_phone_button(page)
        return add_phone_btn.count() > 0 and add_phone_btn.is_visible()
    except Exception:
        return False


def is_verify_account_stuck(page: Page) -> bool:
    """Email is verified but the phone step still shows Add My Phone."""

    return (
        is_verify_account_page(page)
        and is_email_verified_on_verify_page(page)
        and is_phone_verification_pending(page)
        and not _auth_loading_visible(page)
        and not _phone_entry_is_open(page)
    )


def init_bap_recovery_budget(context: BrowserContext) -> None:
    context._tm_bap_clears_remaining = BAP_CLEAR_MAX_ATTEMPTS  # type: ignore[attr-defined]


def bap_clears_remaining(context: BrowserContext) -> int:
    return int(getattr(context, "_tm_bap_clears_remaining", BAP_CLEAR_MAX_ATTEMPTS))


def _refresh_page_once(page: Page) -> bool:
    try:
        page.reload(wait_until="domcontentloaded", timeout=NAVIGATION_TIMEOUT_MS)
    except Exception as exc:
        print(f"  Page refresh failed: {exc}")
        return False

    try:
        page.wait_for_load_state("domcontentloaded", timeout=30_000)
    except Exception:
        pass
    return True


def attempt_bap_recovery(page: Page) -> bool:
    """Clear sessions/cookies, refresh once, return True if BAP is gone."""

    if not is_browsing_paused(page):
        return True

    context = page.context
    remaining = bap_clears_remaining(context)
    if remaining <= 0:
        return False

    attempt_num = BAP_CLEAR_MAX_ATTEMPTS - remaining + 1
    context._tm_bap_clears_remaining = remaining - 1  # type: ignore[attr-defined]
    print(
        f"BAP — clearing sessions/cookies, then refreshing once "
        f"(attempt {attempt_num}/{BAP_CLEAR_MAX_ATTEMPTS}, "
        f"{remaining - 1} left this browser)..."
    )
    _clear_all_storage(context, page)
    if not _refresh_page_once(page):
        return False
    human_pause(*_BAP_AUTO_REFRESH_WAIT_SECONDS)

    if is_browsing_paused(page):
        print("BAP still visible — will retry clear if attempts remain")
        return False

    if _auth_entry_reached(page):
        print("BAP cleared — auth sign-in page ready, continuing signup")
    else:
        print("BAP cleared after session/cookie wipe + refresh")
    return True


def _raise_if_session_blocked(page: Page) -> None:
    if is_phone_session_interrupted(page):
        raise SessionInterruptedRestart(
            "Ticketmaster phone session was interrupted — restarting browser"
        )
    if is_otp_validation_error(page):
        raise OtpValidationRestart(
            "Ticketmaster OTP validation error (phone/email verification failed)"
        )
    while is_browsing_paused(page):
        if bap_clears_remaining(page.context) <= 0:
            raise BrowsingPausedRestart(
                "Ticketmaster BAP persisted after "
                f"{BAP_CLEAR_MAX_ATTEMPTS} session/cookie clears; switching proxy"
            )
        if attempt_bap_recovery(page):
            return


def wait_for_confirm_account_step(page: Page, timeout_ms: int = 120_000) -> None:
    """Wait to leave VERIFY YOUR ACCOUNT for CONFIRM YOUR ACCOUNT."""

    print("Waiting for CONFIRM YOUR ACCOUNT step...")
    deadline = time.time() + (timeout_ms / 1000)
    stuck_since: float | None = None
    phone_code_again_since: float | None = None

    while time.time() < deadline:
        dismiss_information_lost_modal(page)
        _raise_if_phone_code_must_restart(page)
        if _phone_otp_ready(page):
            if phone_code_again_since is None:
                phone_code_again_since = time.time()
            elif time.time() - phone_code_again_since >= 2.0:
                raise SessionInterruptedRestart(
                    "Ticketmaster asked for the phone code again — "
                    "closing this browser and starting signup over"
                )
        else:
            phone_code_again_since = None
        _raise_if_session_blocked(page)

        if is_session_export_ready_page(page):
            if is_welcome_page(page):
                print("Reached WELCOME page (signup verification complete)")
            else:
                print("Reached passkey prompt (signup verification complete)")
            return

        if is_confirm_account_page(page):
            print("Reached confirm account step")
            return

        if is_verify_account_stuck(page):
            if stuck_since is None:
                stuck_since = time.time()
                print(
                    "Still on VERIFY YOUR ACCOUNT with phone verification pending..."
                )
            elif time.time() - stuck_since >= _VERIFY_ACCOUNT_STUCK_SECONDS:
                raise OtpValidationRestart(
                    "Stuck on VERIFY YOUR ACCOUNT after OTP submission "
                    "(phone verification did not complete)"
                )
        else:
            stuck_since = None

        time.sleep(1.0)

    if is_session_export_ready_page(page):
        if is_welcome_page(page):
            print("Reached WELCOME page (signup verification complete)")
        else:
            print("Reached passkey prompt (signup verification complete)")
        return

    if is_confirm_account_page(page):
        print("Reached confirm account step")
        return

    if is_verify_account_stuck(page):
        raise OtpValidationRestart(
            "Timed out on VERIFY YOUR ACCOUNT with phone verification still pending"
        )

    if is_session_export_ready_page(page):
        if is_welcome_page(page):
            print("Reached WELCOME page after email/phone verification")
        else:
            print("Reached passkey prompt after email/phone verification")
        return

    raise TimeoutError(
        f"Timed out waiting for CONFIRM YOUR ACCOUNT, passkey, or WELCOME "
        f"(last URL: {page.url})"
    )


def _phone_otp_ready(page: Page) -> bool:

    otp_input = page.locator(

        '[role="dialog"] [data-bdd="asvd-otp-input"], '

        '[role="dialog"] #otp-input-input, '

        '[role="dialog"] input[autocomplete="one-time-code"]'

    )

    try:

        if otp_input.count() > 0 and otp_input.first.is_visible():

            return True

    except Exception:

        pass



    phone_modal = page.locator('[role="dialog"]').filter(

        has_text=re.compile(r"Verify Your Phone", re.I)

    )

    try:

        if phone_modal.count() > 0 and phone_modal.first.is_visible():

            return True

    except Exception:

        pass



    heading = page.locator('h1:has-text("Verify Your Phone"), h2:has-text("Verify Your Phone")').first

    try:

        return heading.count() > 0 and heading.is_visible()

    except Exception:

        return False





def wait_for_phone_otp_modal(page: Page, timeout_ms: int = 300_000) -> None:

    """Wait through post-submit loading until the phone OTP modal appears."""

    deadline = time.time() + (timeout_ms / 1000)

    last_log = 0.0
    verify_stuck_since: float | None = None
    sms_send_retries = 0
    max_sms_send_retries = _phone_add_number_max_attempts



    while time.time() < deadline:

        dismiss_information_lost_modal_until_gone(page, max_attempts=2)
        if dismiss_phone_try_later_dialog(page):
            raise PhoneVerifyRetry(
                "Something went wrong. Please try after sometime"
            )
        poll_page_during_otp_wait(page)

        if is_phone_verification_limit_error(page):
            raise PhoneNumberUnsupportedError(
                "Phone number reached the limit for verification attempts"
            )

        if is_phone_number_unsupported(page):

            raise PhoneNumberUnsupportedError(

                "Ticketmaster rejected the phone number (unsupported, over limit, etc.)"

            )



        if _phone_otp_ready(page):

            print("Verify Your Phone modal opened")

            return

        submit_btn_visible = False
        try:
            submit_btn = _phone_add_number_button(page)
            submit_btn_visible = submit_btn.count() > 0 and submit_btn.is_visible()
        except Exception:
            pass

        if (
            sms_send_retries < max_sms_send_retries
            and is_phone_send_sms_otp_transient_error(page)
            and (_phone_form_ready(page) or submit_btn_visible)
        ):
            sms_send_retries += 1
            use_enter = sms_send_retries % 2 == 0
            print(
                f"Phone SMS send failed — retrying Confirm/Enter "
                f"({sms_send_retries}/{max_sms_send_retries})..."
            )
            try:
                _submit_phone_add_number_confirm(page, use_enter=use_enter)
                _wait_after_phone_add_number_submit(page)
            except Exception as exc:
                print(f"  Phone confirm retry failed: {exc}")
            human_pause(0.8, 1.4)
            continue

        if is_verify_account_stuck(page):
            if verify_stuck_since is None:
                verify_stuck_since = time.time()
            elif time.time() - verify_stuck_since >= 30:
                raise OtpValidationRestart(
                    "Returned to VERIFY YOUR ACCOUNT while waiting for phone OTP modal"
                )
        else:
            verify_stuck_since = None



        now = time.time()

        if now - last_log >= 15:

            remaining = max(0, int(deadline - now))

            if _auth_loading_visible(page):

                print(f"  Phone submit still loading ({remaining}s left)...")

            elif is_verify_account_stuck(page):

                print(f"  VERIFY YOUR ACCOUNT still pending phone step ({remaining}s left)...")

            else:

                print(f"  Waiting for phone OTP modal ({remaining}s left)...")

            last_log = now



        time.sleep(1.0)



    if _phone_otp_ready(page):

        print("Verify Your Phone modal opened")

        return



    raise TimeoutError("Timed out waiting for Verify Your Phone modal")





def is_browsing_paused(page: Page) -> bool:

    for marker in _TM_BLOCK_MARKERS:

        try:

            locator = page.get_by_text(marker, exact=False)

            if locator.count() > 0 and locator.first.is_visible():

                return True

        except Exception:

            pass



    try:

        body_text = page.locator("body").inner_text(timeout=3_000)

        lowered = body_text.lower()

        if any(marker.lower() in lowered for marker in _TM_BLOCK_MARKERS):

            return True

    except Exception:

        pass



    try:

        html = page.content()

        if any(marker in html for marker in _TM_BLOCK_MARKERS):

            return True

    except Exception:

        pass



    try:

        return bool(

            page.evaluate(

                """() => {

                    const text = document.body?.innerText || '';

                    return (

                        text.includes('BROWSING ACTIVITY HAS BEEN PAUSED')

                        || text.includes('unusual behavior on either your network')

                    );

                }"""

            )

        )

    except Exception:

        return False



_OTP_CODE_INVALID_RE = re.compile(
    r"code you entered is invalid|double-check your entry",
    re.I,
)


def is_otp_code_invalid(page: Page) -> bool:
    """Verify modal: the digits we typed are not the code Ticketmaster sent."""

    try:
        alert = page.locator('[role="alert"]').filter(has_text=_OTP_CODE_INVALID_RE)
        if alert.count() > 0 and alert.first.is_visible():
            return True
    except Exception:
        pass
    try:
        body = page.locator("body").inner_text(timeout=1_500)
    except Exception:
        return False
    return _OTP_CODE_INVALID_RE.search(body) is not None


def click_request_new_otp_code(page: Page) -> bool:
    """Click 'Request a new code' after a rejected OTP. Not used for session-interrupted."""

    if is_phone_session_interrupted(page):
        return False
    link = page.get_by_role("link", name=re.compile(r"request a new code", re.I))
    try:
        if link.count() == 0 or not link.first.is_visible():
            link = page.get_by_text(re.compile(r"request a new code", re.I))
        if link.count() == 0 or not link.first.is_visible():
            return False
        print("Requesting a new code from Ticketmaster...")
        human_click(link.first)
        human_pause(0.6, 1.0)
        return True
    except Exception as exc:
        print(f"  Could not click Request a new code: {exc}")
        return False


def is_otp_validation_error(page: Page) -> bool:
    for marker in _OTP_VALIDATION_ERROR_MARKERS:
        try:
            locator = page.get_by_text(marker, exact=False)
            if locator.count() > 0 and locator.first.is_visible():
                return True
        except Exception:
            pass

    try:
        body_text = page.locator("body").inner_text(timeout=3_000).lower()
        if "error when validating phone/email" in body_text:
            return True
        if "unexpected error on otp process" in body_text:
            return True
    except Exception:
        pass

    try:
        html = page.content().lower()
        if (
            "confirm your account" in html
            and "error when validating phone/email" in html
        ):
            return True
    except Exception:
        pass

    return False


_INFORMATION_LOST_MARKERS = (
    re.compile(r"Your information will be lost", re.I),
    re.compile(r"information will be lost", re.I),
    re.compile(r"cancel now you will be returned", re.I),
)


def _information_lost_back_button(page: Page, scope: Locator | None = None) -> Locator | None:
    """Back on the 'Your information will be lost' modal (data-bdd=success-done-button)."""

    roots: tuple[Locator, ...]
    if scope is not None:
        roots = (scope, page)
    else:
        roots = (page,)

    for root in roots:
        locator = root.locator('[data-bdd="success-done-button"]').filter(
            has_text=re.compile(r"Back", re.I)
        )
        try:
            if locator.count() > 0 and locator.first.is_visible():
                return locator.first
        except Exception:
            continue
    return None


def is_information_lost_modal_visible(page: Page) -> bool:
    try:
        if _information_lost_back_button(page) is not None:
            body = page.locator("body").inner_text(timeout=2_000).lower()
            if (
                "information will be lost" in body
                or "cancel now you will be returned" in body
            ):
                return True
    except Exception:
        pass

    for pattern in _INFORMATION_LOST_MARKERS:
        try:
            modal = page.locator('[role="dialog"]').filter(has_text=pattern)
            if modal.count() > 0 and modal.first.is_visible():
                return True
        except Exception:
            pass
        try:
            if page.get_by_text(pattern).count() > 0 and page.get_by_text(pattern).first.is_visible():
                return True
        except Exception:
            pass
    try:
        body = page.locator("body").inner_text(timeout=2_000)
        lowered = body.lower()
        return (
            "information will be lost" in lowered
            or "cancel now you will be returned" in lowered
        )
    except Exception:
        return False


def _information_lost_modal_scope(page: Page) -> Locator:
    for pattern in _INFORMATION_LOST_MARKERS:
        dialog = page.locator('[role="dialog"]').filter(has_text=pattern)
        try:
            if dialog.count() > 0 and dialog.first.is_visible():
                return dialog.first
        except Exception:
            continue

    try:
        heading = page.get_by_text(re.compile(r"Your information will be lost", re.I)).first
        if heading.count() > 0 and heading.is_visible():
            container = heading.locator("xpath=ancestor::*[@role='dialog'][1]")
            if container.count() > 0:
                return container.first
    except Exception:
        pass

    return page.locator("body")


def dismiss_information_lost_modal(page: Page) -> bool:
    """Dismiss the cancel confirmation modal by clicking Back (never Yes, Cancel)."""

    if not is_information_lost_modal_visible(page):
        return False

    scope = _information_lost_modal_scope(page)
    bdd_back = _information_lost_back_button(page, scope)
    if bdd_back is not None:
        try:
            bdd_back.scroll_into_view_if_needed()
            human_pause(0.15, 0.3)
            print("Clicking Back on 'Your information will be lost' (success-done-button)...")
            _cloak_safe_human_click(bdd_back, timeout=12_000)
            human_pause(0.4, 0.7)
            if not is_information_lost_modal_visible(page):
                print("Dismissed 'Your information will be lost' modal (clicked Back)")
                return True
        except Exception as exc:
            print(f"  success-done-button Back click failed: {exc}")

    back_targets = (
        scope.locator('[data-bdd="success-done-button"]').filter(
            has_text=re.compile(r"Back", re.I)
        ),
        scope.get_by_role("button", name="Back", exact=True),
        scope.get_by_role("button", name=re.compile(r"^back$", re.I)),
        scope.locator('button:has-text("Back"):not(:has-text("Cancel"))'),
        page.locator('[data-bdd="success-done-button"]').filter(
            has_text=re.compile(r"Back", re.I)
        ),
        page.get_by_role("button", name="Back", exact=True),
        page.locator('button:has-text("Back"):not(:has-text("Yes"))'),
    )

    for back_btn in back_targets:
        try:
            if back_btn.count() == 0 or not back_btn.first.is_visible():
                continue
            target = back_btn.first
            target.scroll_into_view_if_needed()
            human_pause(0.15, 0.3)
            try:
                _cloak_safe_human_click(target, timeout=10_000)
            except Exception:
                target.click(force=True, timeout=10_000)
            print("Dismissed 'Your information will be lost' modal (clicked Back)")
            human_pause(0.4, 0.7)
            return True
        except Exception:
            continue

    print("Warning: 'Your information will be lost' modal visible but Back button not clicked")
    return False


def dismiss_information_lost_modal_until_gone(page: Page, *, max_attempts: int = 5) -> None:
    for _ in range(max_attempts):
        if not is_information_lost_modal_visible(page):
            return
        if not dismiss_information_lost_modal(page):
            return
        human_pause(0.3, 0.5)


def ensure_not_blocked(page: Page) -> None:

    dismiss_information_lost_modal_until_gone(page)
    _raise_if_session_blocked(page)





def _clear_all_storage(context: BrowserContext, page: Page) -> None:

    """Wipe cookies (including tmpt), cache, and web storage across TM domains."""

    try:

        context.clear_cookies()

    except Exception:

        pass



    try:

        context.clear_cookies(name="tmpt")

    except Exception:

        pass



    try:

        cdp = context.new_cdp_session(page)

        cdp.send("Network.clearBrowserCookies")

        cdp.send("Network.clearBrowserCache")

        for origin in _TM_STORAGE_ORIGINS:

            try:

                cdp.send(

                    "Storage.clearDataForOrigin",

                    {

                        "origin": origin,

                        "storageTypes": (

                            "cookies,local_storage,session_storage,"

                            "indexeddb,cache_storage,service_workers"

                        ),

                    },

                )

            except Exception:

                pass

    except Exception:

        pass



    for target in context.pages:

        try:

            target.evaluate(

                """() => {

                    try { localStorage.clear(); } catch (e) {}

                    try { sessionStorage.clear(); } catch (e) {}

                }"""

            )

        except Exception:

            pass





@dataclass

class BrowserSession:

    context: BrowserContext

    page: Page

    user_data_dir: Path

    session_tag: str = ""





def destroy_browser_session(
    session: BrowserSession,
    *,
    fast: bool = False,
    skip_storage_clear: bool = False,
) -> None:

    """Fully wipe tmpt, cookies, storage, and delete the browser profile."""

    user_data_dir = session.user_data_dir

    if fast:

        print("Closing blocked browser immediately...")

    elif skip_storage_clear:

        print("Closing browser after successful signup...")

    else:

        print("Clearing all sessions (tmpt, cookies, storage) and closing browser...")

        try:

            _clear_all_storage(session.context, session.page)

        except Exception as exc:

            print(f"  Pre-close storage clear skipped: {exc}")



    try:
        session.context.close()
    except Exception as exc:
        print(f"  Browser close warning: {exc}")

    human_pause(0.35, 0.6)
    kill_browser_child_processes()
    human_pause(0.2, 0.4)

    for attempt in range(6):

        try:

            if user_data_dir.exists():

                shutil.rmtree(user_data_dir)

            break

        except Exception:

            time.sleep(0.4 * (attempt + 1))



    print("Browser profile wiped — next launch starts from scratch.")





def wait_for_page_content(

    page: Page,

    success_locator: Locator,

    *,

    timeout_ms: int = 300_000,

    label: str = "page content",

) -> Locator:

    """Wait through Ticketmaster auth loading screens until content appears."""

    deadline = time.time() + (timeout_ms / 1000)

    last_log = 0.0
    welcome_stuck_since: float | None = None



    while time.time() < deadline:

        try:

            if success_locator.count() > 0 and success_locator.first.is_visible():

                return success_locator.first

        except Exception:

            pass



        dismiss_information_lost_modal(page)
        _raise_if_session_blocked(page)

        if is_welcome_page(page):
            if welcome_stuck_since is None:
                welcome_stuck_since = time.time()
                print(f"  WELCOME page visible while waiting for {label}...")
            elif time.time() - welcome_stuck_since >= _WELCOME_STUCK_SECONDS:
                raise OtpValidationRestart(
                    f"Stuck on WELCOME page while waiting for {label}"
                )
        else:
            welcome_stuck_since = None



        now = time.time()

        if now - last_log >= 15:

            remaining = max(0, int(deadline - now))

            if _auth_loading_visible(page):

                print(f"  Ticketmaster verification in progress ({remaining}s left)...")

            elif is_welcome_page(page):

                print(f"  WELCOME page still visible ({remaining}s left)...")

            else:

                print(f"  Waiting for {label} ({remaining}s left)...")

            last_log = now



        time.sleep(1.0)



    try:
        success_locator.first.wait_for(state="visible", timeout=5_000)
    except Exception as exc:
        raise TimeoutError(f"Timed out waiting for {label}") from exc

    return success_locator.first





def wait_for_auth_email_form(page: Page, timeout_ms: int = 300_000) -> Locator:
    """Wait for TM auth email field; continues signup after BAP refresh lands here."""

    deadline = time.time() + (timeout_ms / 1000)
    last_log = 0.0

    while time.time() < deadline:
        dismiss_information_lost_modal(page)
        _raise_if_session_blocked(page)

        email_input = find_visible_auth_email_input(page)
        if email_input is not None:
            print("Auth email field ready — continuing signup")
            return email_input

        if _auth_entry_reached(page):
            email_input = find_visible_auth_email_input(page)
            if email_input is not None:
                print("Auth email field ready — continuing signup")
                return email_input

        now = time.time()
        if now - last_log >= 15:
            remaining = max(0, int(deadline - now))
            if _auth_loading_visible(page):
                print(f"  Ticketmaster verification in progress ({remaining}s left)...")
            elif _AUTH_HOST_RE.match(page.url or ""):
                print(
                    f"  On auth.ticketmaster.com, waiting for email field ({remaining}s left)..."
                )
            else:
                print(f"  Waiting for email form ({remaining}s left)...")
            last_log = now

        time.sleep(1.0)

    raise TimeoutError(
        f"Timed out waiting for auth email form (last URL: {page.url})"
    )


def _auth_email_continue_button(page: Page) -> Locator:
    return page.locator(
        '[data-bdd="sign-in-button"], '
        'button[type="submit"]:has-text("Continue"), '
        'button:has-text("Continue")'
    ).first


def _signup_password_locator(page: Page) -> Locator:
    return page.locator("#password-input, #password-input-input").first


def _existing_account_login_indicators(page: Page) -> bool:
    for pattern in (
        r"ENTER YOUR PASSWORD",
        r"Sign in to your Ticketmaster account",
    ):
        try:
            loc = page.get_by_text(re.compile(pattern, re.I)).first
            if loc.count() > 0 and loc.is_visible():
                return True
        except Exception:
            continue

    try:
        sign_in = page.locator(
            '[data-bdd="sign-in-button"]:has-text("Sign in"), '
            'button[type="submit"]:has-text("Sign in")'
        ).first
        first_name = page.locator("#firstName-input, #firstName-input-input").first
        has_sign_in = sign_in.count() > 0 and sign_in.is_visible()
        has_first = first_name.count() > 0 and first_name.is_visible()
        if has_sign_in and not has_first:
            return True
    except Exception:
        pass

    return False


def is_existing_account_login_step(page: Page) -> bool:
    """True when auth shows login for an existing user after email, not new signup."""

    password_field = _signup_password_locator(page)
    try:
        if password_field.count() == 0 or not password_field.first.is_visible():
            return False
    except Exception:
        return False

    if _on_signup_form(page):
        return False

    if _existing_account_login_indicators(page):
        return True

    deadline = time.time() + 12.0
    while time.time() < deadline:
        dismiss_information_lost_modal_until_gone(page)
        if _on_signup_form(page):
            return False
        if _existing_account_login_indicators(page):
            return True
        try:
            first_name = page.locator("#firstName-input, #firstName-input-input").first
            if first_name.count() > 0 and first_name.is_visible():
                return False
        except Exception:
            pass
        time.sleep(0.4)

    return _on_signup_form(page) is False and _existing_account_login_indicators(page)


def raise_if_existing_account_login(page: Page, email: str = "") -> None:
    if not is_existing_account_login_step(page):
        return
    label = email.strip() or "This email"
    raise ExistingTicketmasterAccountError(
        f"{label} already has a Ticketmaster account (sign-in password step)"
    )


def _auth_email_value(page: Page, email_input: Locator) -> str:
    try:
        return email_input.input_value().strip()
    except Exception:
        return ""


def submit_auth_email_address(page: Page, email: str, *, timeout_ms: int = 360_000) -> None:
    """Fill TM auth email and click Continue; re-enter email after BAP refresh."""

    deadline = time.time() + (timeout_ms / 1000)
    last_log = 0.0
    print(f"Submitting email on auth page: {email}")

    while time.time() < deadline:
        dismiss_information_lost_modal_until_gone(page)
        ensure_not_blocked(page)

        password_field = _signup_password_locator(page)
        try:
            if password_field.count() > 0 and password_field.first.is_visible():
                raise_if_existing_account_login(page, email)
                print("Reached signup password step after email Continue")
                return
        except ExistingTicketmasterAccountError:
            raise
        except Exception:
            pass

        email_input = find_visible_auth_email_input(page)
        if email_input is None:
            try:
                email_input = wait_for_auth_email_form(
                    page,
                    timeout_ms=max(5_000, int((deadline - time.time()) * 1000)),
                )
            except TimeoutError:
                email_input = None

        if email_input is not None:
            current = _auth_email_value(page, email_input)
            if current.lower() != email.strip().lower():
                fill_field(email_input, email)
                human_pause(0.35, 0.55)
                print(f"Entered email on auth page: {email}")
            else:
                print("Auth email field already filled — clicking Continue")

            continue_btn = _auth_email_continue_button(page)
            try:
                expect(continue_btn).to_be_enabled(timeout=20_000)
                human_pause(0.2, 0.35)
                human_click(continue_btn)
                print("Clicked Continue on auth email step")
                human_pause(0.6, 1.0)
            except Exception as exc:
                print(f"  Continue click pending ({exc})")

        now = time.time()
        if now - last_log >= 15:
            remaining = max(0, int(deadline - now))
            if find_visible_auth_email_input(page) is not None:
                print(f"  Auth email step — waiting for password form ({remaining}s left)...")
            else:
                print(f"  Waiting to complete auth email step ({remaining}s left)...")
            last_log = now

        time.sleep(0.6)

    raise TimeoutError(
        f"Timed out after auth email step (last URL: {page.url})"
    )


def wait_for_signup_password_form(
    page: Page,
    timeout_ms: int = 300_000,
    *,
    email: str = "",
) -> Locator:

    password_input = page.locator("#password-input, #password-input-input").first

    locator = wait_for_page_content(
        page,
        password_input,
        timeout_ms=timeout_ms,
        label="signup form",
    )
    raise_if_existing_account_login(page, email)
    return locator





_HOME_LOAD_TIMEOUT_MS = 180_000
_HOME_SIGNUP_WAIT_SECONDS = 120
_AUTH_AFTER_ACCOUNT_LINK_SECONDS = 180
_BAP_AUTH_DEADLINE_EXTENSION_SECONDS = 90


def _ticketmaster_account_link(page: Page) -> Locator:
    return page.get_by_test_id("accountLink")


def _account_link_ready(page: Page) -> bool:
    link = _ticketmaster_account_link(page)
    try:
        return link.count() > 0 and link.first.is_visible()
    except Exception:
        return False


def dismiss_home_page_overlays(page: Page) -> None:
    """Close cookie banners and promo modals that hide the header."""

    if is_information_lost_modal_visible(page):
        dismiss_information_lost_modal(page)
        return

    cookie_selectors = (
        "#onetrust-accept-btn-handler",
        'button[id*="accept"]',
        'button[id*="Accept"]',
        'button[data-testid*="accept"]',
    )
    for selector in cookie_selectors:
        try:
            button = page.locator(selector).first
            if button.count() > 0 and button.is_visible():
                human_click(button)
                human_pause(0.4, 0.7)
                break
        except Exception:
            continue

    for pattern in (
        re.compile(r"accept all cookies", re.I),
        re.compile(r"accept all", re.I),
        re.compile(r"^accept$", re.I),
        re.compile(r"^got it$", re.I),
        re.compile(r"^continue$", re.I),
    ):
        try:
            button = page.get_by_role("button", name=pattern)
            if button.count() > 0 and button.first.is_visible():
                human_click(button.first)
                human_pause(0.4, 0.7)
        except Exception:
            pass


def _home_shell_ready(page: Page) -> bool:
    if _account_link_ready(page):
        return True

    markers = (
        page.locator("header"),
        page.locator("nav"),
        page.get_by_role("link", name=re.compile(r"sign\s*in", re.I)),
        page.locator('[data-bdd*="sign"]'),
    )
    for marker in markers:
        try:
            if marker.count() > 0 and marker.first.is_visible():
                return True
        except Exception:
            continue
    return False


def _signup_entry_visible(page: Page) -> bool:
    if _account_link_ready(page):
        return True

    entry_points = (
        page.get_by_role("link", name=re.compile(r"sign\s*in\s*/\s*register", re.I)),
        page.get_by_role("button", name=re.compile(r"sign\s*in\s*/\s*register", re.I)),
    )
    for target in entry_points:
        try:
            if target.count() > 0 and target.first.is_visible():
                return True
        except Exception:
            continue
    return False


def _on_auth_host(page: Page) -> bool:
    return bool(_AUTH_HOST_RE.match(page.url or ""))


def _on_ticketmaster_home_url(page: Page) -> bool:
    return bool(_POST_SIGNUP_HOME_RE.match(page.url or ""))


def click_ticketmaster_account_link(page: Page) -> None:
    """Click the header Sign In/Register control (data-testid=accountLink)."""

    account_link = _ticketmaster_account_link(page).first
    account_link.wait_for(state="visible", timeout=_HOME_LOAD_TIMEOUT_MS)
    human_pause(0.8, 1.5)
    dismiss_home_page_overlays(page)
    account_link.wait_for(state="visible", timeout=30_000)

    last_error: Exception | None = None
    for attempt in range(1, 6):
        dismiss_home_page_overlays(page)
        try:
            account_link.scroll_into_view_if_needed()
            human_pause(0.25, 0.5)
            human_click(account_link, timeout=30_000)
            print('Clicked Sign In/Register (data-testid="accountLink").')
            return
        except Exception as exc:
            last_error = exc
            try:
                account_link.click(force=True, timeout=15_000)
                print(
                    'Clicked Sign In/Register (data-testid="accountLink", force).'
                )
                return
            except Exception as force_exc:
                last_error = force_exc
                print(
                    f"  accountLink click attempt {attempt}/5 failed: {force_exc}"
                )
                human_pause(1.0, 2.0)

    raise RuntimeError(
        'Could not click Sign In/Register (data-testid="accountLink")'
    ) from last_error


def visit_spotify_before_ticketmaster(page: Page) -> None:
    """Open Spotify (or configured URL) before navigating to Ticketmaster."""

    if not _visit_spotify_before_ticketmaster:
        return

    min_s = _spotify_warmup_min_seconds
    max_s = _spotify_warmup_max_seconds
    dwell = random.uniform(min_s, max_s) if max_s > min_s else max_s

    print(
        f"Opening Spotify warmup at {_spotify_warmup_url} "
        f"({dwell:.1f}s, config range {min_s:.0f}–{max_s:.0f}s)..."
    )
    _goto_with_proxy_sign_in(
        page,
        _spotify_warmup_url,
        wait_until="domcontentloaded",
        timeout=NAVIGATION_TIMEOUT_MS,
    )
    try:
        page.wait_for_load_state("load", timeout=45_000)
    except Exception:
        pass

    viewport = page.viewport_size or {"width": 1280, "height": 720}
    pointer_x = viewport["width"] // 2 + random.randint(-120, 120)
    pointer_y = viewport["height"] // 2 + random.randint(-80, 80)
    try:
        page.mouse.move(pointer_x, pointer_y)
    except Exception:
        pass

    deadline = time.time() + dwell
    while time.time() < deadline:
        if random.random() < 0.45:
            try:
                page.mouse.wheel(0, random.randint(120, 380))
            except Exception:
                pass
        human_pause(0.5, 1.25)

    human_pause(0.4, 0.85)
    print("Spotify warmup finished — navigating to Ticketmaster.")


def wait_for_ticketmaster_home(page: Page) -> None:
    jitter = random.uniform(2.0, 5.0)
    print(f"Loading Ticketmaster home (startup jitter {jitter:.1f}s)...")
    time.sleep(jitter)

    visit_spotify_before_ticketmaster(page)
    if not _visit_spotify_before_ticketmaster:
        print("Spotify warmup is off — opening Ticketmaster directly")

    goto_kwargs: dict = {
        "wait_until": "domcontentloaded",
        "timeout": NAVIGATION_TIMEOUT_MS,
    }
    # A cold visit with no previous site is the case that was staying blank.
    if not _visit_spotify_before_ticketmaster:
        goto_kwargs["referer"] = "https://www.google.com/"

    last_nav_error: Exception | None = None
    for attempt in range(1, 4):
        try:
            _goto_with_proxy_sign_in(page, TM_HOME_URL, **goto_kwargs)
        except Exception as exc:
            last_nav_error = exc
            print(f"Ticketmaster home did not open (attempt {attempt}/3): {exc}")
            human_pause(1.0, 2.0)
            continue
        if _page_never_left_blank(page):
            print(
                f"Ticketmaster stayed blank (attempt {attempt}/3, url={page.url!r}) "
                "— trying the proxy Sign-in again"
            )
            _submit_proxy_sign_in_dialog(page)
            human_pause(1.0, 2.0)
            continue
        print(f"Ticketmaster navigation reached {page.url}")
        break
    else:
        raise RuntimeError(
            "Ticketmaster home never left a blank page after 3 attempts"
        ) from last_nav_error

    try:
        page.wait_for_load_state("load", timeout=60_000)
    except Exception:
        pass

    print('Waiting for Sign In/Register (data-testid="accountLink") on home...')
    deadline = time.time() + (_HOME_LOAD_TIMEOUT_MS / 1000)
    last_log = 0.0
    account_link = _ticketmaster_account_link(page).first

    while time.time() < deadline:
        dismiss_home_page_overlays(page)

        try:
            if account_link.is_visible():
                human_pause(1.5, 2.5)
                dismiss_home_page_overlays(page)
                if account_link.is_visible():
                    print(
                        'Ticketmaster home ready — Sign In/Register '
                        '(data-testid="accountLink") is visible.'
                    )
                    return
        except Exception:
            pass

        now = time.time()
        if now - last_log >= 15:
            remaining = max(0, int(deadline - now))
            print(f"  Waiting for accountLink on home ({remaining}s left)...")
            last_log = now

        human_pause(1.0, 1.5)

    account_link.wait_for(state="visible", timeout=5_000)
    print("Ticketmaster home ready (accountLink appeared at deadline).")


def scroll_ticketmaster_home_before_signup_click(page: Page) -> None:
    """Wheel-scroll the home page like a visitor before opening Sign In/Register."""

    if not _scroll_home_before_signup:
        return

    min_s = _scroll_before_signup_min_seconds
    max_s = _scroll_before_signup_max_seconds
    if max_s <= 0:
        return

    duration = random.uniform(min_s, max_s) if max_s > min_s else max_s
    print(
        f"Scrolling Ticketmaster home before Sign In/Register "
        f"({duration:.1f}s, config range {min_s:.0f}–{max_s:.0f}s)..."
    )

    viewport = page.viewport_size or {"width": 1280, "height": 720}
    pointer_x = viewport["width"] // 2 + random.randint(-90, 90)
    pointer_y = viewport["height"] // 2 + random.randint(-70, 70)
    try:
        page.mouse.move(pointer_x, pointer_y)
    except Exception:
        pass

    deadline = time.time() + duration
    while time.time() < deadline:
        dismiss_home_page_overlays(page)
        delta = random.randint(140, 420) * random.choice((1, 1, 1, -1))
        try:
            page.mouse.wheel(0, delta)
        except Exception:
            pass
        human_pause(0.35, 1.15)
        if random.random() < 0.12:
            try:
                page.mouse.wheel(0, -random.randint(90, 240))
            except Exception:
                pass
            human_pause(0.35, 0.85)
        if random.random() < 0.1:
            pointer_x = max(
                40,
                min(viewport["width"] - 40, pointer_x + random.randint(-140, 140)),
            )
            pointer_y = max(
                40,
                min(viewport["height"] - 40, pointer_y + random.randint(-90, 90)),
            )
            try:
                page.mouse.move(pointer_x, pointer_y)
            except Exception:
                pass

    for _ in range(random.randint(2, 5)):
        try:
            page.mouse.wheel(0, -random.randint(220, 520))
        except Exception:
            pass
        human_pause(0.18, 0.42)

    dismiss_home_page_overlays(page)
    human_pause(0.45, 0.95)
    print("Finished home scroll — opening Sign In/Register.")


def click_signup_from_home(page: Page) -> None:
    """Open auth signup via the site UI (no direct auth URL navigation)."""

    wait_for_ticketmaster_home(page)
    scroll_ticketmaster_home_before_signup_click(page)
    click_ticketmaster_account_link(page)

    auth_deadline = time.time() + _AUTH_AFTER_ACCOUNT_LINK_SECONDS
    last_log = 0.0
    last_account_link_click = time.time()

    while time.time() < auth_deadline:
        if is_browsing_paused(page):
            auth_deadline += _BAP_AUTH_DEADLINE_EXTENSION_SECONDS
            print(
                f"  Extending auth wait by {_BAP_AUTH_DEADLINE_EXTENSION_SECONDS}s "
                "while handling BAP..."
            )

        ensure_not_blocked(page)
        if _auth_entry_reached(page):
            print("Ticketmaster auth / email step opened.")
            return

        if _on_auth_host(page):
            remaining_ms = max(int((auth_deadline - time.time()) * 1000), 15_000)
            try:
                wait_for_auth_email_form(page, timeout_ms=remaining_ms)
                print("Ticketmaster auth / email step opened.")
                return
            except TimeoutError:
                pass

        if (
            _on_ticketmaster_home_url(page)
            and not _auth_entry_reached(page)
            and time.time() - last_account_link_click >= 25
        ):
            print("Still on home after accountLink — clicking Sign In/Register again...")
            try:
                click_ticketmaster_account_link(page)
                last_account_link_click = time.time()
                auth_deadline += 30
            except Exception as exc:
                print(f"  accountLink re-click skipped: {exc}")

        now = time.time()
        if now - last_log >= 15:
            remaining = max(0, int(auth_deadline - now))
            print(f"  Waiting for auth page after accountLink ({remaining}s left)...")
            last_log = now

        human_pause(0.8, 1.2)

    if bap_clears_remaining(page.context) <= 0 and not _auth_entry_reached(page):
        raise BrowsingPausedRestart(
            "Valid auth page not reached after "
            f"{BAP_CLEAR_MAX_ATTEMPTS} BAP session/cookie clears; switching proxy"
        )

    raise TimeoutError(
        "Auth page did not open after clicking Sign In/Register (accountLink) "
        f"(last URL: {page.url})"
    )


def _phone_modal_scope(page: Page) -> Locator:
    for hint in (
        r"add your phone number",
        r"add & verify your phone",
        r"verify your account",
        r"phone number",
    ):
        dialog = page.locator('[role="dialog"]').filter(
            has_text=re.compile(hint, re.I)
        )
        try:
            if dialog.count() > 0 and dialog.first.is_visible():
                return dialog.first
        except Exception:
            continue
        inline = page.locator("section, div, main").filter(
            has_text=re.compile(hint, re.I)
        )
        try:
            if inline.count() > 0 and inline.last.is_visible():
                return inline.last
        except Exception:
            continue
    tel_form = page.locator("form").filter(has=page.locator('input[type="tel"]'))
    if tel_form.count() > 0:
        return tel_form.first
    return page.locator("body")


def _phone_dial_code_combobox(page: Page) -> Locator:
    visible = _visible_phone_dial_code_combobox(page)
    if visible is not None:
        return visible
    return _phone_country_combobox_candidates(page).first


def _dial_code_listbox_open(page: Page) -> bool:
    combobox = _phone_dial_code_combobox(page)
    try:
        if combobox.count() > 0 and combobox.is_visible():
            if combobox.get_attribute("aria-expanded") == "true":
                return True
    except Exception:
        pass

    menu = page.locator("#phone-number-dialCode-menu")
    try:
        if menu.count() > 0 and menu.first.is_visible():
            return True
    except Exception:
        pass

    try:
        options = page.locator('[role="listbox"] [role="option"]')
        if options.count() > 0 and options.first.is_visible():
            return True
    except Exception:
        pass

    try:
        options = page.locator('[role="option"]')
        for idx in range(min(options.count(), 8)):
            if options.nth(idx).is_visible():
                return True
    except Exception:
        pass

    return False


def _wait_for_phone_dial_code_ui(page: Page, timeout_ms: int = 30_000) -> None:
    """Wait for country combobox (+1/Other) or legacy dial-code UI."""

    deadline = time.time() + (timeout_ms / 1000)
    while time.time() < deadline:
        dismiss_information_lost_modal_until_gone(page)

        if _visible_phone_dial_code_combobox(page) is not None:
            human_pause(0.25, 0.45)
            return

        for locator in (
            page.locator("#phone-number-dialCode-label"),
            page.locator('[aria-labelledby="phone-number-dialCode-label"]'),
            page.locator('input[type="tel"][class*="PhoneNumber__PhoneNumberInput"]'),
        ):
            try:
                if locator.count() > 0 and locator.first.is_visible():
                    human_pause(0.25, 0.45)
                    return
            except Exception:
                continue

        time.sleep(0.4)

    raise TimeoutError(
        "Phone country combobox (+1 / Other) not visible on VERIFY YOUR ACCOUNT"
    )


def _dial_code_option_selected(page: Page, aria_label: str) -> bool:
    option = page.locator(f'[role="option"][aria-label="{aria_label}"]')
    try:
        if option.count() > 0:
            return option.first.get_attribute("aria-selected") == "true"
    except Exception:
        pass

    if re.search(r"other", aria_label, re.I):
        return _is_other_dial_code_selected(page)

    combobox = _phone_dial_code_combobox(page)
    try:
        if combobox.count() == 0 or not combobox.is_visible():
            return False
        text = combobox.inner_text()
        if "United States" in aria_label and re.search(r"United States|\+1", text, re.I):
            return True
        if "Canada" in aria_label and re.search(r"Canada", text, re.I):
            return True
    except Exception:
        pass

    return False


def _is_other_dial_code_selected(page: Page) -> bool:
    try:
        selected = page.locator('[role="option"][aria-selected="true"]').filter(
            has_text=re.compile(r"\bOther\b", re.I)
        )
        if selected.count() > 0:
            return True
    except Exception:
        pass

    combobox = _phone_dial_code_combobox(page)
    try:
        if combobox.count() == 0:
            return False
        text = combobox.inner_text()
        if re.search(r"\bOther\b", text, re.I):
            return True
        if "United States" not in text and "Canada" not in text and re.search(r"\+", text):
            return True
    except Exception:
        pass

    return False


def _human_open_phone_country_combobox(page: Page) -> None:
    """Human-like click on the +1 country combobox to open US / Canada / Other."""

    dismiss_information_lost_modal_until_gone(page)
    _wait_for_phone_dial_code_ui(page)
    if _dial_code_listbox_open(page):
        return

    human_pause(0.45, 0.85)
    combobox = _visible_phone_dial_code_combobox(page)
    if combobox is None:
        combobox = _phone_dial_code_combobox(page)
    combobox.wait_for(state="visible", timeout=20_000)
    combobox.scroll_into_view_if_needed()
    human_pause(0.35, 0.65)
    print("Clicking phone country combobox (+1 / Other dropdown)...")
    try:
        human_hover(combobox)
    except Exception:
        pass
    _cloak_safe_human_click(combobox, timeout=20_000)
    human_pause(0.55, 1.05)

    if not _dial_code_listbox_open(page):
        human_pause(0.35, 0.55)
        _cloak_safe_human_click(combobox, timeout=15_000)
        human_pause(0.5, 0.95)

    if not _dial_code_listbox_open(page):
        raise RuntimeError(
            "Could not open phone country dropdown after clicking the combobox"
        )
    print("Phone country dropdown opened")


def _locator_other_phone_country_option(page: Page) -> Locator:
    """Other (+) row — single CSS/xpath/get_by_text only (CloakBrowser humanize)."""

    for selector in (
        'xpath=//div[@role="option"][contains(@class,"StyledSelectItem")][contains(.,"Other")]',
        'xpath=//div[@role="option"][contains(@class,"SelectItem")][.//div[contains(@class,"SelectItemContent")][contains(.,"Other")]]',
        '[role="option"][class*="StyledSelectItem"]',
    ):
        locator = page.locator(selector)
        try:
            count = locator.count()
            for idx in range(count):
                candidate = locator.nth(idx)
                if not candidate.is_visible():
                    continue
                try:
                    text = candidate.inner_text(timeout=2_000)
                except Exception:
                    text = ""
                if re.search(r"\bOther\b", text, re.I):
                    return candidate
        except Exception:
            continue

    return page.get_by_text("Other", exact=True).first


def _locator_dial_code_option(page: Page, *, aria_label: str, fallback_name: str) -> Locator:
    if re.search(r"other", fallback_name, re.I) or re.search(r"other", aria_label, re.I):
        return _locator_other_phone_country_option(page)

    if "United States" in aria_label:
        return page.locator(
            'xpath=//div[@role="option"][contains(@class,"StyledSelectItem")][contains(.,"United States")]'
        ).first

    if "Canada" in aria_label:
        return page.locator(
            'xpath=//div[@role="option"][contains(@class,"StyledSelectItem")][contains(.,"Canada")]'
        ).first

    return page.locator(f'[role="option"][aria-label="{aria_label}"]').first


def _human_pick_dial_code_option(
    page: Page,
    *,
    aria_label: str,
    fallback_name: str,
) -> None:
    """Human-like click on United States, Canada, or Other in the open listbox."""

    human_pause(0.25, 0.5)
    is_other = bool(
        re.search(r"other", fallback_name, re.I) or re.search(r"other", aria_label, re.I)
    )
    if is_other:
        print("Selecting 'Other' in phone country dropdown (human click)...")
    else:
        print(f"Selecting dial-code option ({fallback_name}) with human click...")

    option = _locator_dial_code_option(
        page,
        aria_label=aria_label,
        fallback_name=fallback_name,
    )
    option.wait_for(state="visible", timeout=20_000)
    _cloak_safe_human_click(option, timeout=20_000)
    human_pause(0.45, 0.85)

    if is_other and not _is_other_dial_code_selected(page):
        try:
            inner = page.locator(
                'xpath=//div[contains(@class,"SelectItemContent")][contains(.,"Other")]'
            ).first
            inner.wait_for(state="visible", timeout=5_000)
            _cloak_safe_human_click(inner, timeout=15_000)
            human_pause(0.35, 0.6)
        except Exception:
            pass


def _open_phone_dial_code_listbox(page: Page) -> None:
    _human_open_phone_country_combobox(page)


def _click_dial_code_list_option(page: Page, *, aria_label: str, fallback_name: str) -> None:
    _human_pick_dial_code_option(
        page,
        aria_label=aria_label,
        fallback_name=fallback_name,
    )


def _first_visible_locator(page: Page, selectors: tuple[str, ...]) -> Locator | None:
    """Pick first visible match using page-level CSS only (CloakBrowser humanize-safe)."""

    for selector in selectors:
        locator = page.locator(selector)
        try:
            count = locator.count()
        except Exception:
            continue
        for index in range(count):
            candidate = locator.nth(index)
            try:
                if candidate.is_visible():
                    return candidate
            except Exception:
                continue
    return None


_PHONE_TEL_INPUT_SELECTORS: tuple[str, ...] = (
    'input[type="tel"][class*="PhoneNumber__PhoneNumberInput"]',
    '[data-bdd="asvd-phone-input"]',
    "#phoneNumber-input-input",
    "#phone-input-input",
    'input[type="tel"][pattern]',
    'input[aria-label="Phone number"]',
    'input[type="tel"]',
)


def _phone_tel_input_in_form(page: Page) -> Locator:
    """Visible phone tel input — page-level CSS/xpath only (no dialog >> input chains)."""

    xpath_candidates = (
        'xpath=//input[@type="tel" and contains(@class,"PhoneNumber__PhoneNumberInput")]',
        'xpath=//input[@type="tel" and @inputmode="tel" and contains(@class,"PhoneNumber")]',
    )
    for xpath in xpath_candidates:
        locator = page.locator(xpath)
        try:
            for index in range(locator.count()):
                candidate = locator.nth(index)
                if candidate.is_visible():
                    return candidate
        except Exception:
            continue

    found = _first_visible_locator(page, _PHONE_TEL_INPUT_SELECTORS)
    if found is not None:
        return found
    return page.locator('input[type="tel"][class*="PhoneNumber__PhoneNumberInput"]').first


def _visible_other_phone_digits(page: Page) -> str:
    phone_input = _phone_tel_input_in_form(page)
    return _read_phone_input_digits(phone_input)


def _other_mode_phone_input(page: Page) -> Locator:
    return _phone_tel_input_in_form(page)


def _expected_phone_digits(
    *,
    dial_code: str,
    national_number: str,
    mode: TmPhoneEntryMode,
    expected_digits: int,
) -> str:
    local = _digits_only(national_number)
    if mode == "other":
        return f"{dial_code}{local}"
    if len(local) != expected_digits:
        raise ValueError(
            f"Expected a {expected_digits}-digit local phone number, got: {national_number}"
        )
    return local


def _read_phone_input_digits(phone_input: Locator) -> str:
    try:
        return _digits_only(phone_input.input_value())
    except Exception:
        return ""


def _sync_tel_input_value(phone_input: Locator, digits: str) -> None:
    """Set tel value and dispatch input/change so React-controlled fields keep it."""

    phone_input.evaluate(
        """(el, value) => {
            const proto = window.HTMLInputElement.prototype;
            const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
            const setter = descriptor && descriptor.set;
            if (setter) {
                setter.call(el, value);
            } else {
                el.value = value;
            }
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }""",
        digits,
    )


def _plain_tel_input_click(phone_input: Locator) -> None:
    """Focus tel input without CloakBrowser humanized click (chained locators break humanize)."""

    phone_input.scroll_into_view_if_needed()
    human_pause(0.08, 0.15)
    try:
        phone_input.click(timeout=10_000)
    except Exception:
        phone_input.click(force=True, timeout=10_000)


def _clear_tel_input(phone_input: Locator) -> None:
    _plain_tel_input_click(phone_input)
    human_pause(0.08, 0.15)
    phone_input.press("Control+A")
    human_pause(0.05, 0.1)
    phone_input.press("Backspace")
    human_pause(0.08, 0.15)


def configure_ticketmaster_phone_country(
    page: Page,
    *,
    country_name: str,
    dial_code: str,
    iso: str = "",
) -> TmPhoneEntryMode:
    """Pick US / Canada / Other in TM dial-code list. Non-US/CA uses Other (+)."""

    dismiss_information_lost_modal_until_gone(page)
    _wait_for_phone_dial_code_ui(page)

    if iso == "US":
        mode: TmPhoneEntryMode = "us"
        aria_label = "United States, +1"
        fallback = r"United States"
    elif iso == "CA":
        mode = "ca"
        aria_label = "Canada, +1"
        fallback = r"Canada"
    else:
        mode = "other"
        aria_label = "Other, +"
        fallback = r"^Other"

    if not _dial_code_option_selected(page, aria_label):
        _human_open_phone_country_combobox(page)
        _human_pick_dial_code_option(
            page,
            aria_label=aria_label,
            fallback_name=fallback,
        )
        human_pause(0.5, 0.95)
    else:
        print(f"Dial-code list already set to {aria_label}")

    if mode == "other":
        intl_input = _other_mode_phone_input(page)
        intl_input.wait_for(state="visible", timeout=20_000)
        intl_input.scroll_into_view_if_needed()
        human_pause(0.35, 0.6)
        print(
            f"Selected 'Other' for {country_name} (+{dial_code}) — "
            "will enter full international number"
        )
    else:
        print(f"Selected dial-code list option: {aria_label}")

    return mode


def _phone_digits_exact(actual: str, expected: str) -> bool:
    a = _digits_only(actual)
    e = _digits_only(expected)
    return bool(e) and a == e


def _phone_digits_match(actual: str, expected: str) -> bool:
    """Exact match only — partial/endswith caused false 'already filled' skips."""

    return _phone_digits_exact(actual, expected)


def format_tm_other_phone_display(
    dial_code: str,
    national_number: str,
    *,
    iso: str = "",
) -> str:
    """Display value for TM Other (+) tel mask (e.g. Chile: ``56 9 6213 9832``)."""

    dial = _digits_only(dial_code)
    national = _digits_only(national_number)

    if iso == "CL" or (dial == "56" and len(national) == 9):
        return f"{dial} {national[0]} {national[1:5]} {national[5:]}"

    body: list[str] = []
    index = 0
    while index < len(national):
        body.append(national[index : index + 4])
        index += 4
    return f"{dial} {' '.join(body)}"


def _type_into_other_phone_input(phone_input: Locator, text: str) -> None:
    _clear_tel_input(phone_input)
    human_pause(0.12, 0.22)
    phone_input.press_sequentially(text, delay=random.randint(85, 125))
    human_pause(0.35, 0.55)


def fill_other_country_phone_input(
    page: Page,
    dial_code: str,
    national_number: str,
    *,
    iso: str = "",
) -> None:
    """Enter full international number in Other (+) mode (masked spacing, no leading +)."""

    phone_input = _phone_tel_input_in_form(page)
    national = _digits_only(national_number)
    dial = _digits_only(dial_code)
    digits = f"{dial}{national}"
    display = format_tm_other_phone_display(dial_code, national_number, iso=iso)

    phone_input.wait_for(state="visible", timeout=30_000)
    human_pause(0.25, 0.45)

    for attempt, payload in enumerate((digits, display), start=1):
        phone_input = _phone_tel_input_in_form(page)
        _plain_tel_input_click(phone_input)
        human_pause(0.12, 0.22)
        _type_into_other_phone_input(phone_input, payload)
        current = _read_phone_input_digits(phone_input)
        if _phone_digits_match(current, digits):
            break
        if attempt == 1:
            print(
                f"  Digit-only entry did not stick (field={current!r}) — "
                f"retrying with spaced mask {display!r}..."
            )

    current = _read_phone_input_digits(phone_input)
    if not _phone_digits_match(current, digits):
        _plain_tel_input_click(phone_input)
        human_pause(0.1, 0.2)
        _sync_tel_input_value(phone_input, display)
        human_pause(0.25, 0.4)
        current = _read_phone_input_digits(phone_input)

    if not _phone_digits_match(current, digits):
        raise RuntimeError(
            f"Failed to enter international phone "
            f"(expected digits {digits}, display {display!r}, got {current!r})"
        )

    try:
        phone_input.evaluate("el => el.blur()")
    except Exception:
        pass
    human_pause(0.2, 0.35)

    current = _read_phone_input_digits(phone_input)
    if not _phone_digits_match(current, digits):
        raise RuntimeError(
            f"Phone cleared after blur (expected {digits}, got {current!r})"
        )

    try:
        shown = phone_input.input_value()
    except Exception:
        shown = display
    print(f"Entered international phone: {shown!r} ({digits})")


def fill_ticketmaster_phone_number(
    page: Page,
    *,
    dial_code: str,
    national_number: str,
    mode: TmPhoneEntryMode,
    expected_digits: int,
    iso: str = "",
) -> None:
    if mode == "other":
        fill_other_country_phone_input(
            page, dial_code, national_number, iso=iso
        )
        return

    phone_input = _phone_tel_input_in_form(page)
    if phone_input.count() == 0 or not phone_input.is_visible():
        phone_input = _phone_number_input(page)
    fill_phone_field(phone_input, national_number, expected_digits=expected_digits)


def ensure_ticketmaster_phone_number(
    page: Page,
    *,
    dial_code: str,
    national_number: str,
    mode: TmPhoneEntryMode,
    expected_digits: int,
    iso: str = "",
) -> None:
    """Verify phone digits are still in the field; re-enter if the UI cleared them."""

    dismiss_information_lost_modal_until_gone(page)

    expected = _expected_phone_digits(
        dial_code=dial_code,
        national_number=national_number,
        mode=mode,
        expected_digits=expected_digits,
    )
    actual = _visible_other_phone_digits(page) if mode == "other" else _read_phone_input_digits(
        _phone_tel_input_in_form(page)
    )
    if _phone_digits_exact(actual, expected):
        print(f"Verified phone digits in field: {expected}")
        return

    print(
        f"Phone field empty or wrong (expected {expected}, got {actual!r}) — re-entering..."
    )
    fill_ticketmaster_phone_number(
        page,
        dial_code=dial_code,
        national_number=national_number,
        mode=mode,
        expected_digits=expected_digits,
        iso=iso,
    )
    actual = _visible_other_phone_digits(page) if mode == "other" else _read_phone_input_digits(
        _phone_tel_input_in_form(page)
    )
    if not _phone_digits_exact(actual, expected):
        raise RuntimeError(
            f"Phone number not held in field after re-entry "
            f"(expected {expected}, got {actual!r})"
        )
    print(f"Verified phone digits in field: {expected}")


def warm_up_session(page: Page) -> None:
    """Legacy alias — signup now starts from the home page Sign Up button."""

    wait_for_ticketmaster_home(page)





def _clone_proxy_settings(proxy: dict[str, str] | None) -> dict[str, str] | None:
    if not proxy:
        return None
    return dict(proxy)


def _proxy_auth_creds(page: Page) -> tuple[str, str]:
    context = page.context
    username = str(getattr(context, "_tm_proxy_username", "") or "")
    password = str(getattr(context, "_tm_proxy_password", "") or "")
    return username, password


def _submit_proxy_sign_in_dialog(page: Page) -> None:
    """Fill Chromium's native proxy Sign-in prompt. Never Cancel — that freezes the page."""
    username, password = _proxy_auth_creds(page)
    if not username:
        return
    print("Submitting Chromium proxy Sign-in dialog (Sign in, not Cancel)")
    try:
        page.keyboard.type(username, delay=12)
        page.keyboard.press("Tab")
        page.keyboard.type(password, delay=12)
        page.keyboard.press("Enter")
    except Exception as exc:
        print(f"Could not type into proxy Sign-in dialog: {exc}")


def _install_proxy_auth_on_page(page: Page, username: str, password: str) -> None:
    if not username:
        return
    try:
        cdp = page.context.new_cdp_session(page)
    except Exception as exc:
        print(f"Could not open CDP session for proxy auth: {exc}")
        return

    sessions = getattr(page.context, "_tm_proxy_cdp_sessions", None)
    if sessions is None:
        sessions = []
        page.context._tm_proxy_cdp_sessions = sessions
    sessions.append(cdp)

    def on_auth(*args, **kwargs) -> None:
        event = args[0] if args else kwargs
        if not isinstance(event, dict):
            return
        if "requestId" not in event and isinstance(event.get("params"), dict):
            event = event["params"]
        request_id = event.get("requestId")
        if not request_id:
            return
        challenge = event.get("authChallenge") or {}
        source = str(challenge.get("source") or "")
        if source.lower() == "server":
            response = {"response": "Default"}
        else:
            print(
                f"Chromium proxy auth challenge (source={source or 'Proxy'}) "
                "— providing credentials via Sign in"
            )
            response = {
                "response": "ProvideCredentials",
                "username": username,
                "password": password,
            }
        try:
            cdp.send(
                "Fetch.continueWithAuth",
                {"requestId": request_id, "authChallengeResponse": response},
            )
        except Exception as exc:
            print(f"Fetch.continueWithAuth failed: {exc}")

    try:
        # Empty patterns: answer the proxy login only. Omitting patterns pauses
        # every request on some Chromium builds, and Ticketmaster never paints.
        cdp.send(
            "Fetch.enable",
            {"handleAuthRequests": True, "patterns": []},
        )
        cdp.on("Fetch.authRequired", on_auth)
    except Exception as exc:
        print(f"Could not enable Chromium proxy auth interceptor: {exc}")


def install_chromium_proxy_auth(
    context: BrowserContext,
    page: Page,
    proxy: dict[str, str] | None,
) -> None:
    """Answer Chromium's HTTP proxy username/password prompt automatically."""
    if not proxy:
        return
    username = str(proxy.get("username") or "")
    password = str(proxy.get("password") or "")
    context._tm_proxy_username = username
    context._tm_proxy_password = password
    if not username:
        return

    print(f"Chromium proxy Sign-in handler ready (user={username})")
    _install_proxy_auth_on_page(page, username, password)

    def on_new_page(new_page: Page) -> None:
        _install_proxy_auth_on_page(new_page, username, password)

    try:
        context.on("page", on_new_page)
    except Exception:
        pass


def _page_never_left_blank(page: Page) -> bool:
    url = (page.url or "").strip().lower()
    return url in {
        "",
        "about:blank",
        "chrome://new-tab-page/",
        "chrome://newtab/",
    } or url.startswith("chrome-error://") or "chromewebdata" in url


def _goto_with_proxy_sign_in(page: Page, url: str, **kwargs) -> None:
    """Navigate, and if Chromium's proxy Sign-in dialog blocks, click Sign in.

    A cold proxy plus Ticketmaster often needs the full timeout. Cutting the
    navigation every 25s was aborting a load that was still in progress, so the
    window stayed blank whenever Spotify warmup was turned off.
    """
    username, _password = _proxy_auth_creds(page)
    timeout_ms = int(kwargs.pop("timeout", NAVIGATION_TIMEOUT_MS))
    if not username:
        page.goto(url, timeout=timeout_ms, **kwargs)
        return

    try:
        page.goto(url, timeout=timeout_ms, **kwargs)
        return
    except PlaywrightTimeoutError as exc:
        last_error: Exception | None = exc
    except Exception as exc:
        last_error = exc
        message = str(exc).lower()
        if "timeout" not in message and "net::" not in message:
            raise

    if _page_never_left_blank(page):
        print(
            "Navigation still on a blank page — submitting proxy Sign in "
            "and opening the page again"
        )
        _submit_proxy_sign_in_dialog(page)
        human_pause(0.4, 0.8)
        page.goto(url, timeout=timeout_ms, **kwargs)
        return

    print(
        f"Navigation passed the timeout but already reached {page.url} — "
        "waiting for the document instead of starting over"
    )
    try:
        page.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
    except Exception:
        if last_error:
            raise last_error
        raise


def create_browser_session(

    proxy: dict[str, str] | None,

    country: str = "US",

) -> BrowserSession:

    ensure_cloakbrowser_ready()

    session_tag = secrets.token_hex(4)
    user_data_dir = Path(tempfile.mkdtemp(prefix=f"tm_cloak_{session_tag}_"))
    viewport = random.choice(_DESKTOP_VIEWPORTS)
    proxy_settings = _clone_proxy_settings(proxy)

    launch_kwargs: dict = {

        "headless": False,

        "viewport": dict(viewport),

        "color_scheme": random.choice(("light", "dark")),

        "has_touch": False,

        "is_mobile": False,

        "humanize": _cloakbrowser_humanize,

        "human_preset": _cloakbrowser_human_preset,

    }

    if proxy_settings:
        launch_kwargs["proxy"] = proxy_settings

    if _cloakbrowser_geoip and proxy_settings:
        # Let CloakBrowser derive timezone/locale from each proxy exit IP.
        launch_kwargs["geoip"] = True
    else:
        launch_kwargs["locale"] = "en-US" if country == "US" else "en-GB"
        launch_kwargs["timezone"] = (
            random.choice(_US_TIMEZONES) if country == "US" else "Europe/London"
        )

    proxy_label = proxy_settings["server"] if proxy_settings else "direct"
    print(
        f"Launching CloakBrowser [{session_tag}] pid={os.getpid()} "
        f"viewport={viewport['width']}x{viewport['height']} proxy={proxy_label}"
    )

    last_error: Exception | None = None
    for launch_attempt in range(1, 4):
        try:
            context = launch_persistent_context(str(user_data_dir), **launch_kwargs)
            init_bap_recovery_budget(context)
            page = context.pages[0] if context.pages else context.new_page()
            install_chromium_proxy_auth(context, page, proxy_settings)
            return BrowserSession(
                context=context,
                page=page,
                user_data_dir=user_data_dir,
                session_tag=session_tag,
            )
        except Exception as exc:
            last_error = exc
            kill_browser_child_processes()
            if launch_attempt < 3:
                backoff = random.uniform(2.5, 5.0) * launch_attempt
                print(
                    f"CloakBrowser launch failed (attempt {launch_attempt}/3): {exc} "
                    f"— retrying in {backoff:.1f}s..."
                )
                time.sleep(backoff)
            else:
                print(f"CloakBrowser launch failed (attempt {launch_attempt}/3): {exc}")

    raise RuntimeError(
        f"Could not launch CloakBrowser after 3 attempts (pid={os.getpid()})"
    ) from last_error

