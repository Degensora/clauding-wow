"""Randomized signup identity fields (names and postal codes)."""

import random

FIRST_NAMES = [
    "James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda",
    "David", "Elizabeth", "William", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
    "Thomas", "Sarah", "Christopher", "Karen", "Charles", "Lisa", "Daniel", "Nancy",
    "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra", "Donald", "Ashley",
    "Steven", "Kimberly", "Paul", "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    "Kenneth", "Dorothy", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
    "Timothy", "Deborah", "Ronald", "Stephanie", "Edward", "Rebecca", "Jason", "Sharon",
    "Jeffrey", "Laura", "Ryan", "Cynthia", "Jacob", "Kathleen", "Gary", "Amy",
    "Nicholas", "Angela", "Eric", "Shirley", "Jonathan", "Anna", "Stephen", "Brenda",
    "Larry", "Pamela", "Justin", "Emma", "Scott", "Nicole", "Brandon", "Helen",
    "Benjamin", "Samantha", "Samuel", "Katherine", "Gregory", "Christine", "Frank", "Debra",
    "Alexander", "Rachel", "Raymond", "Carolyn", "Patrick", "Janet", "Jack", "Catherine",
    "Dennis", "Maria", "Jerry", "Heather", "Tyler", "Diane", "Aaron", "Ruth",
    "Jose", "Julie", "Adam", "Olivia", "Nathan", "Joyce", "Henry", "Evelyn",
    "Douglas", "Lauren", "Zachary", "Victoria", "Peter", "Kelly", "Kyle", "Christina",
    "Noah", "Joan", "Ethan", "Eva", "Jeremy", "Judith", "Walter", "Megan",
    "Christian", "Cheryl", "Keith", "Andrea", "Roger", "Hannah", "Terry", "Jacqueline",
    "Austin", "Martha", "Sean", "Gloria", "Gerald", "Teresa", "Carl", "Ann",
    "Dylan", "Sara", "Harold", "Madison", "Jordan", "Frances", "Bryan", "Kathryn",
    "Jesse", "Janice", "Gabriel", "Jean", "Logan", "Abigail", "Alan", "Alice",
    "Juan", "Julia", "Wayne", "Judy", "Roy", "Sophia", "Ralph", "Grace",
    "Randy", "Denise", "Eugene", "Amber", "Vincent", "Doris", "Russell", "Marilyn",
    "Elijah", "Danielle", "Louis", "Beverly", "Bobby", "Isabella", "Philip", "Theresa",
    "Johnny", "Diana", "Bradley", "Natalie", "Liam", "Charlotte", "Mason", "Ava",
    "Lucas", "Mia", "Oliver", "Ella", "Elijah", "Scarlett", "Mateo", "Aria",
    "Sebastian", "Penelope", "Jack", "Layla", "Owen", "Chloe", "Theodore", "Camila",
    "Hudson", "Luna", "Lincoln", "Zoey", "Ezra", "Nora", "Thomas", "Hazel",
    "Charles", "Violet", "Caleb", "Aurora", "Isaiah", "Savannah", "Connor", "Audrey",
    "Cameron", "Brooklyn", "Leo", "Bella", "Ian", "Claire", "Colton", "Skylar",
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas",
    "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White",
    "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young",
    "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
    "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell",
    "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker",
    "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales", "Murphy",
    "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson", "Bailey",
    "Reed", "Kelly", "Howard", "Ramos", "Kim", "Cox", "Ward", "Richardson",
    "Watson", "Brooks", "Chavez", "Wood", "James", "Bennett", "Gray", "Mendoza",
    "Ruiz", "Hughes", "Price", "Alvarez", "Castillo", "Sanders", "Patel", "Myers",
    "Long", "Ross", "Foster", "Jimenez", "Powell", "Jenkins", "Perry", "Russell",
    "Sullivan", "Bell", "Coleman", "Butler", "Henderson", "Barnes", "Gonzales", "Fisher",
    "Vasquez", "Simmons", "Romero", "Jordan", "Patterson", "Alexander", "Hamilton", "Graham",
    "Reynolds", "Griffin", "Wallace", "Moreno", "West", "Cole", "Hayes", "Bryant",
    "Herrera", "Gibson", "Ellis", "Tran", "Medina", "Aguilar", "Stevens", "Murray",
    "Ford", "Castro", "Marshall", "Owens", "Harrison", "Fernandez", "McDonald", "Woods",
    "Washington", "Kennedy", "Wells", "Vargas", "Henry", "Chen", "Freeman", "Webb",
    "Tucker", "Guzman", "Burns", "Crawford", "Olson", "Simpson", "Porter", "Hunter",
    "Gordon", "Mendez", "Silva", "Shaw", "Snyder", "Mason", "Dixon", "Munoz",
    "Hunt", "Hicks", "Holmes", "Palmer", "Wagner", "Black", "Robertson", "Boyd",
    "Rose", "Stone", "Salazar", "Fox", "Warren", "Mills", "Meyer", "Rice",
    "Schmidt", "Garza", "Daniels", "Ferguson", "Nichols", "Stephens", "Soto", "Weaver",
    "Ryan", "Gardner", "Payne", "Grant", "Dunn", "Kelley", "Spencer", "Hawkins",
    "Arnold", "Pierce", "Vazquez", "Hansen", "Peters", "Santos", "Hart", "Bradley",
    "Knight", "Elliott", "Cunningham", "Duncan", "Armstrong", "Hudson", "Carroll", "Lane",
    "Riley", "Andrews", "Alvarado", "Ray", "Delgado", "Berry", "Perkins", "Hoffman",
    "Johnston", "Matthews", "Pena", "Richards", "Wheeler", "Larson", "George", "Burke",
    "Williamson", "Reed", "Carr", "Duncan", "Sutton", "Lawson", "Franklin", "Fields",
]

def random_first_name() -> str:
    return random.choice(FIRST_NAMES)


def random_last_name() -> str:
    return random.choice(LAST_NAMES)


def random_us_zip() -> str:
    while True:
        zip_code = f"{random.randint(1000, 99999):05d}"
        suffix = zip_code[0:2]
        if suffix in {"00", "96", "97", "98", "99"}:
            continue
        return zip_code


def random_postal_for_country(iso: str = "US") -> str:
    """Ticketmaster signup ZIP — always a US 5-digit postal code."""

    del iso  # phone/SMS country may differ; ZIP stays US
    return random_us_zip()
